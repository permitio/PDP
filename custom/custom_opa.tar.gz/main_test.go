package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime/debug"
	"runtime/pprof"
	"strings"
	"testing"
	"time"

	"github.com/google/go-cmp/cmp"
	"github.com/google/go-cmp/cmp/cmpopts"
	"github.com/open-policy-agent/opa/rego"
	"github.com/open-policy-agent/opa/topdown/cache"
	"github.com/permitio/permit-opa/types"
	"github.com/permitio/permit-opa/types/input"
	"github.com/samber/lo"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

const (
	examplesDir                       = "examples"
	dataFileName                      = "data.json"
	inputFileName                     = "input.json"
	expectedResultFileName            = "expected_result.json"
	expectedAllRolesResultFileName    = "expected_all_roles_result.json"
	expectedLinkedUsersResultFileName = "expected_linked_users_result.json"
)

func prepareForEval(ctx context.Context, cache cache.InterQueryCache, rawData string) error {
	r := rego.New(
		rego.Query(fmt.Sprintf(`%s(%s)`, rebacUpdateCacheFuncName, rawData)),
		rego.InterQueryBuiltinCache(cache),
		rego.Function1(permitUpdateDataFunc()),
	)
	_, err := r.Eval(ctx)
	return err
}

func eval(t *testing.T, rawData, rawInput string, isLegacy bool) (rego.ResultSet, error) {
	var funcName string
	var query, impl func(r *rego.Rego)
	if isLegacy {
		funcName = legacyRebacRolesFuncName
		query = rego.Query(fmt.Sprintf(`%s(%s,%s)`, funcName, rawData, rawInput))
		impl = rego.Function2(permitLegacyReBACRolesFunc())

	} else {
		funcName = rebacRolesFuncName
		query = rego.Query(fmt.Sprintf(`%s(%s)`, funcName, rawInput))
		impl = rego.Function1(permitReBACRolesFunc())
	}

	dataCache := cache.NewInterQueryCache(nil)
	r := rego.New(
		query,
		rego.InterQueryBuiltinCache(dataCache),
		impl,
	)
	ctx := context.Background()
	if !isLegacy {
		if err := prepareForEval(ctx, dataCache, rawData); err != nil {
			return nil, err
		}
	}
	defer timeTrack(t, time.Now(), fmt.Sprintf("eval %s", funcName), 1000)
	return r.Eval(ctx)
}

func evalAllRoles(t *testing.T, rawData, rawInput string) (rego.ResultSet, error) {
	query := rego.Query(fmt.Sprintf(`%s(%s)`, rebacAllRolesFuncName, rawInput))
	impl := rego.Function1(permitReBACAllRolesFunc())
	dataCache := cache.NewInterQueryCache(nil)
	r := rego.New(
		query,
		rego.InterQueryBuiltinCache(dataCache),
		impl,
	)
	ctx := context.Background()
	if err := prepareForEval(ctx, dataCache, rawData); err != nil {
		return nil, err
	}
	_, _ = timeTrackDecorator(t, fmt.Sprintf("1st eval %s", rebacAllRolesFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
	return timeTrackDecorator(t, fmt.Sprintf("2nd eval %s", rebacAllRolesFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
}

func evalLinkedUsers(t *testing.T, rawData, rawInput string) (rego.ResultSet, error) {
	query := rego.Query(fmt.Sprintf(`%s(%s)`, rebacLinkedUsersFuncName, rawInput))
	impl := rego.Function1(permitReBACLinkedUsersFunc())
	dataCache := cache.NewInterQueryCache(nil)
	r := rego.New(
		query,
		rego.InterQueryBuiltinCache(dataCache),
		impl,
	)
	ctx := context.Background()
	if err := prepareForEval(ctx, dataCache, rawData); err != nil {
		return nil, err
	}
	_, _ = timeTrackDecorator(t, fmt.Sprintf("1st eval %s", rebacLinkedUsersFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
	return timeTrackDecorator(t, fmt.Sprintf("2nd eval %s", rebacLinkedUsersFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
}

func evalInlineLinkedUsers(t *testing.T, rawData, rawInput string) (rego.ResultSet, error) {
	query := rego.Query(fmt.Sprintf(`%s(%s, %s)`, rebacInlineLinkedUsersFuncName, rawData, rawInput))
	impl := rego.Function2(permitReBACInlineLinkedUsersFunc())
	dataCache := cache.NewInterQueryCache(nil)
	r := rego.New(
		query,
		rego.InterQueryBuiltinCache(dataCache),
		impl,
	)
	ctx := context.Background()
	_, _ = timeTrackDecorator(t, fmt.Sprintf("1st eval %s", rebacInlineLinkedUsersFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
	return timeTrackDecorator(t, fmt.Sprintf("2nd eval %s", rebacInlineLinkedUsersFuncName), 1000, func() (rs rego.ResultSet, e error) {
		return r.Eval(ctx)
	})
}

func race(t *testing.T) bool {
	b, ok := debug.ReadBuildInfo()
	if !ok {
		t.Log("could not read build info")
		return false
	}

	for _, s := range b.Settings {
		if s.Key == "-race" {
			t.Log("-race=" + s.Value)
			return true
		}
	}
	return false
}

func timeTrack(t *testing.T, start time.Time, name string, timeout int) {
	elapsed := time.Since(start)
	log.Printf("%s took %s", name, elapsed)
	if race(t) {
		// If race detector is enabled the performance is extremely slow
		// so we need to increase the timeout
		timeout *= 10
		t.Logf("race detector is enabled, increased timeout x10 to %d", timeout*10)
	}
	assert.LessOrEqual(t, elapsed.Milliseconds(), int64(timeout), "eval took too long")
}

func timeTrackDecorator(t *testing.T, name string, timeout int, callback func() (rego.ResultSet, error)) (rego.ResultSet, error) {
	defer timeTrack(t, time.Now(), name, timeout)
	return callback()
}

func fileExists(filename string) bool {
	info, err := os.Stat(filename)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}

func sortFunc(a, b string) bool {
	return a < b
}

func unwrapResultSet(t *testing.T, resultSet rego.ResultSet, err error) (interface{}, []byte) {
	require.NoError(t, err)
	require.True(t, len(resultSet) > 0, "no results returned")
	result := resultSet[0].Expressions[0].Value
	bs, err := json.MarshalIndent(result, "", "  ")
	require.NoError(t, err)
	return result, bs
}

func evalAllRolesAndGetResult(t *testing.T, rawData, rawInput string, entry os.DirEntry) (map[string][]string, []byte) {
	rs, err := evalAllRoles(t, rawData, rawInput)
	_, bs := unwrapResultSet(t, rs, err)
	var resultRoles map[string][]string
	err = json.Unmarshal(bs, &resultRoles)
	require.NoErrorf(t, err, "error %s ,result does not match []string : \n%s", err, string(bs))

	if expectedResultFilePath := filepath.Join(examplesDir, entry.Name(), expectedAllRolesResultFileName); fileExists(expectedResultFilePath) {
		rawExpectedResult, err := os.ReadFile(expectedResultFilePath)
		var expectedResultRoles map[string][]string
		if err := json.Unmarshal(rawExpectedResult, &expectedResultRoles); err != nil {
			require.NoErrorf(t, err, "error %s ,expected result does not match []string : \n%s", err, string(bs))
		}
		require.NoErrorf(t, err, "failed to read %s", expectedAllRolesResultFileName)
		require.Truef(t, cmp.Equal(resultRoles, expectedResultRoles, cmpopts.SortSlices(sortFunc)),
			"result does not match %s\n%s\n%s", expectedAllRolesResultFileName, string(bs), string(rawExpectedResult))
	} else {
		t.Logf("No expected result file found at '%s', skipping comparison", expectedResultFilePath)
	}
	t.Logf("Result is:\n%s", string(bs))
	return resultRoles, bs
}

func evalAndGetResult(t *testing.T, rawData, rawInput string, entry os.DirEntry, isLegacy bool) (types.ResultTuple, []byte) {
	rs, err := eval(t, rawData, rawInput, isLegacy)
	_, bs := unwrapResultSet(t, rs, err)
	var resultTuple types.ResultTuple
	err = json.Unmarshal(bs, &resultTuple)
	require.NoErrorf(t, err, "error %s ,result does not match ResultTuple struct: \n%s", err, string(bs))
	if expectedResultFilePath := filepath.Join(examplesDir, entry.Name(), expectedResultFileName); fileExists(expectedResultFilePath) {
		rawExpectedResult, err := os.ReadFile(expectedResultFilePath)
		var expectedResultTuple types.ResultTuple
		if err := json.Unmarshal(bs, &expectedResultTuple); err != nil {
			require.NoErrorf(t, err, "error %s ,expected result does not match ResultTuple struct: \n%s", err, string(bs))
		}
		require.NoErrorf(t, err, "failed to read %s", expectedResultFileName)
		require.Truef(t, cmp.Equal(resultTuple, expectedResultTuple, cmp.AllowUnexported(types.ResultTuple{}),
			cmpopts.SortSlices(sortFunc), cmpopts.SortMaps(sortFunc)),
			"result does not match %s\n%s\n%s", expectedResultFileName, string(bs), string(rawExpectedResult))
	} else {
		t.Logf("No expected result file found at '%s', skipping comparison", expectedResultFilePath)
		t.Logf("Result is:\n%s", string(bs))
	}
	return resultTuple, bs
}

func evalLinkedUsersAndGetResult(t *testing.T, rawData, rawInput string, entry os.DirEntry) (map[string]types.LinkedUsersResultTuple, []byte) {
	rs, err := evalLinkedUsers(t, rawData, rawInput)
	_, bs := unwrapResultSet(t, rs, err)
	var resultUsersAndRoles map[string]types.LinkedUsersResultTuple
	err = json.Unmarshal(bs, &resultUsersAndRoles)
	require.NoErrorf(t, err, "error %s ,result does not match map[string]types.LinkedUsersResultTuple : \n%s", err, string(bs))

	if expectedResultFilePath := filepath.Join(examplesDir, entry.Name(), expectedLinkedUsersResultFileName); fileExists(expectedResultFilePath) {
		rawExpectedResult, err := os.ReadFile(expectedResultFilePath)
		var expectedResultLinkedUsers map[string]types.LinkedUsersResultTuple
		if err := json.Unmarshal(rawExpectedResult, &expectedResultLinkedUsers); err != nil {
			require.NoErrorf(t, err, "error %s ,expected result does not match map[string]types.LinkedUsersResultTuple : \n%s", err, string(bs))
		}
		require.NoErrorf(t, err, "failed to read %s", expectedLinkedUsersResultFileName)
		if !cmp.Equal(resultUsersAndRoles, expectedResultLinkedUsers) {
			require.FailNowf(t, "result does not match expected file %s\nresult:\n%s\n\nexpected:\n%s", expectedLinkedUsersResultFileName, string(bs), string(rawExpectedResult))
		}
	} else {
		t.Logf("No expected result file found at '%s', skipping comparison", expectedResultFilePath)
	}
	t.Logf("Result is:\n%s", string(bs))
	return resultUsersAndRoles, bs
}

func evalInlineLinkedUsersAndGetResult(t *testing.T, rawData, rawInput string, entry os.DirEntry) (map[string]types.LinkedUsersResultTuple, []byte) {
	rs, err := evalInlineLinkedUsers(t, rawData, rawInput)
	_, bs := unwrapResultSet(t, rs, err)
	var resultUsersAndRoles map[string]types.LinkedUsersResultTuple
	err = json.Unmarshal(bs, &resultUsersAndRoles)
	require.NoErrorf(t, err, "error %s ,result does not match map[string]types.LinkedUsersResultTuple : \n%s", err, string(bs))

	if expectedResultFilePath := filepath.Join(examplesDir, entry.Name(), expectedLinkedUsersResultFileName); fileExists(expectedResultFilePath) {
		rawExpectedResult, err := os.ReadFile(expectedResultFilePath)
		var expectedResultLinkedUsers map[string]types.LinkedUsersResultTuple
		if err := json.Unmarshal(rawExpectedResult, &expectedResultLinkedUsers); err != nil {
			require.NoErrorf(t, err, "error %s ,expected result does not match map[string]types.LinkedUsersResultTuple : \n%s", err, string(bs))
		}
		require.NoErrorf(t, err, "failed to read %s", expectedLinkedUsersResultFileName)
		require.Truef(t, cmp.Equal(resultUsersAndRoles, expectedResultLinkedUsers),
			"result does not match %s\nresult:\n%s\nexpected:\n%s", expectedLinkedUsersResultFileName, string(bs), string(rawExpectedResult))
	} else {
		t.Logf("No expected result file found at '%s', skipping comparison", expectedResultFilePath)
	}
	t.Logf("Result is:\n%s", string(bs))
	return resultUsersAndRoles, bs
}

var profileEnabled = false

func doProfile(t *testing.T) {
	if profileEnabled {
		return
	}
	profileEnabled = true
	var cpuprofile = flag.String("cpuprofile", "", "write cpu profile to file")
	flag.Parse()
	if *cpuprofile != "" {
		t.Logf("writing cpu profile to %s", *cpuprofile)
		f, err := os.Create(*cpuprofile)
		if err != nil {
			log.Fatal(err)
		}
		err = pprof.StartCPUProfile(f)
		if err != nil {
			log.Fatal(err)
		}
		defer pprof.StopCPUProfile()
	}
}

func TestPermitReBACLinkedUsers(t *testing.T) {
	doProfile(t)
	entries, err := os.ReadDir(examplesDir)
	require.NoError(t, err, "failed to read examples dir")
	for i, entry := range entries {
		t.Run(entry.Name(), func(t *testing.T) {
			t.Logf("running example %d: %s", i, entry.Name())
			if !entry.IsDir() {
				t.Logf("skipping non-dir entry %d: %s", i, entry.Name())
				t.SkipNow()
			} else if strings.HasPrefix(entry.Name(), "_") {
				t.Log("skipping example with underscore")
				t.SkipNow()
			}
			rawData, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), dataFileName))
			require.NoError(t, err, "failed to read data.json")
			rawInput, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), inputFileName))
			require.NoError(t, err, "failed to read input.json")
			var parsedInput input.InputObj
			err = json.Unmarshal(rawInput, &parsedInput)
			require.NoError(t, err, "failed to parse input.json")
			rawInputResource, err := json.Marshal(parsedInput.Resource)
			require.NoError(t, err, "failed to marshal input resource")
			linkedUsersResult, _ := evalLinkedUsersAndGetResult(t, string(rawData), string(rawInputResource), entry)
			if linkedUsersResult != nil {
				require.True(t, len(linkedUsersResult) > 0, "no users returned")
			}
			linkedUsersResultInline, _ := evalInlineLinkedUsersAndGetResult(t, string(rawData), string(rawInputResource), entry)
			if linkedUsersResultInline != nil {
				require.True(t, len(linkedUsersResultInline) > 0, "no users returned")
			}
			require.True(t, cmp.Equal(linkedUsersResult, linkedUsersResultInline, cmpopts.SortSlices(sortFunc), cmpopts.SortMaps(sortFunc)))
		})
	}
}

func TestPermitReBACAllRolesFunc(t *testing.T) {
	doProfile(t)
	entries, err := os.ReadDir(examplesDir)
	require.NoError(t, err, "failed to read examples dir")
	for i, entry := range entries {
		t.Logf("running example %d: %s", i, entry.Name())
		if !entry.IsDir() {
			t.Logf("skipping non-dir entry %d: %s", i, entry.Name())
			continue
		} else if strings.HasPrefix(entry.Name(), "_") {
			t.Log("skipping example with underscore")
			continue
		}
		rawData, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), dataFileName))
		require.NoError(t, err, "failed to read data.json")
		rawInput, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), inputFileName))
		require.NoError(t, err, "failed to read input.json")

		allRolesResult, _ := evalAllRolesAndGetResult(t, string(rawData), string(rawInput), entry)
		require.True(t, len(lo.Flatten(lo.Values(allRolesResult))) > 0, "no roles returned")
	}
}

func TestPermitReBACRolesFunc(t *testing.T) {
	doProfile(t)
	entries, err := os.ReadDir(examplesDir)
	require.NoError(t, err, "failed to read examples dir")
	for i, entry := range entries {
		t.Logf("running example %d: %s", i, entry.Name())
		if !entry.IsDir() {
			t.Logf("skipping non-dir entry %d: %s", i, entry.Name())
			continue
		} else if strings.HasPrefix(entry.Name(), "_") {
			t.Log("skipping example with underscore")
			continue
		}
		rawData, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), dataFileName))
		require.NoError(t, err, "failed to read data.json")
		rawInput, err := os.ReadFile(filepath.Join(examplesDir, entry.Name(), inputFileName))
		require.NoError(t, err, "failed to read input.json")

		legacyResult, legacyResultB := evalAndGetResult(t, string(rawData), string(rawInput), entry, true)
		optimizedResult, optimizedResultB := evalAndGetResult(t, string(rawData), string(rawInput), entry, false)

		require.Truef(t, cmp.Equal(legacyResult, optimizedResult, cmpopts.SortSlices(sortFunc), cmpopts.SortMaps(sortFunc)),
			"optimized result does not match legacy result\n%s\n%s", string(legacyResultB), string(optimizedResultB))
	}
}
