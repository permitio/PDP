package main

// Most of the code is taken from https://github.com/open-policy-agent/opa/topdown/cache/cache.go
// only modification is the use of RWMutex instead of Mutex in the InterQueryCache implementation interCache

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/open-policy-agent/opa/ast"
	"github.com/open-policy-agent/opa/cmd"
	"github.com/open-policy-agent/opa/rego"
	"github.com/open-policy-agent/opa/runtime"
	opacache "github.com/open-policy-agent/opa/topdown/cache"
	"github.com/open-policy-agent/opa/types"
	"github.com/permitio/permit-opa/graph"
	"github.com/permitio/permit-opa/graph/graphy"
	"github.com/permitio/permit-opa/graph/new_walker"
	"github.com/permitio/permit-opa/plugin"
	ptypes "github.com/permitio/permit-opa/types"
	pdata "github.com/permitio/permit-opa/types/data"
	pinput "github.com/permitio/permit-opa/types/input"
	"github.com/permitio/permit-opa/types/ocache"
	"github.com/samber/lo"
	"go.uber.org/zap"
)

const (
	rebacUpdateCacheFuncName       = "permit_rebac.update_cache"
	rebacRolesFuncName             = "permit_rebac.roles"
	rebacAllRolesFuncName          = "permit_rebac.all_roles"
	rebacInlineAllRolesFuncName    = "permit_rebac.inline_all_roles"
	rebacLinkedUsersFuncName       = "permit_rebac.linked_users"
	rebacInlineLinkedUsersFuncName = "permit_rebac.inline_linked_users"
	legacyRebacRolesFuncName       = "permit_rebac_roles"
)

// Global data cache for handling the latest data updates with delay
var interQueryCache opacache.InterQueryCache
var cacheManager *ocache.CacheManager

func init() {
	interQueryCache = ocache.NewInterQueryCache(nil)
	cacheManager = ocache.NewCacheManager(interQueryCache)
	// configure zap to use the global logger
	zap.ReplaceGlobals(zap.Must(zap.NewProduction()))
}

func getReBACRoles(ctx context.Context, data *pdata.DataObj, input *pinput.InputObj) (*ast.Term, error) {
	walker := graph.NewWalker(data, input)
	ctx = graph.NewChildContext(ctx)
	totalRoles := lo.Uniq(walker.GetRoles(ctx))
	if v, err := ast.InterfaceToValue(ptypes.ResultTuple{
		Roles:    totalRoles,
		Debugger: walker.GetDebuggerMap(),
	}); err != nil {
		return nil, err
	} else {
		return ast.NewTerm(v), nil
	}
}

func getReBACAllRoles(ctx context.Context, data *pdata.DataObj, input *pinput.InputObj, tuples pdata.ReverseRelationshipTuples, derivations pdata.DerivationSchemaMap) (*ast.Term, error) {
	totalRoles := make([]string, 0)
	roleAssignments, found := data.RoleAssignments[input.User.Full()]
	if !found {
		return ast.NewTerm(ast.MustInterfaceToValue(totalRoles)), nil
	}
	ctx = graph.NewChildContext(ctx)
	for resourceString := range roleAssignments {
		if strings.HasPrefix(resourceString, "__tenant:") {
			continue
		}
		subject := pinput.NewResourceFromString(resourceString)
		walker := graph.NewTopToBottomWalker(data, &pinput.InputObj{
			User:     input.User,
			Resource: subject,
		}, tuples, derivations)
		roles := walker.GetRoles(ctx)
		totalRoles = append(totalRoles, roles...)
	}
	totalRolesMap := lo.GroupBy(lo.Uniq(totalRoles), func(role string) string {
		return pdata.NewResourceRoleFromString(role).ResourceString()
	})
	return ast.NewTerm(ast.MustInterfaceToValue(totalRolesMap)), nil
}

func getReBACLinkedUsers(ctx context.Context, dataObj *pdata.DataObj, graphObj *graphy.Graph, input *pinput.InputResource) (*ast.Term, error) {
	lookUpManager := new_walker.NewLookUpManagerFromGraph(dataObj, graphObj)
	linkedUsersWithRoles := lookUpManager.LookUpResourceIncludeDerivedRoles(
		ctx,
		input,
	)

	return ast.NewTerm(ast.MustInterfaceToValue(linkedUsersWithRoles)), nil
}

func builtinPermitReBACRoles(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error) {
	var input pinput.InputObj
	cache := ocache.NewCacheManager(interQueryCache)
	dataPtr, err := cache.GetData()
	if err != nil {
		return nil, err
	}
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	return getReBACRoles(bctx.Context, dataPtr, &input)
}

func builtinLegacyPermitReBACRoles(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error) {
	var data pdata.DataObj
	if err := ast.As(dataTerm.Value, &data); err != nil {
		return nil, err
	}
	var input pinput.InputObj
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	return getReBACRoles(bctx.Context, &data, &input)
}

func builtinPermitUpdateData(bctx rego.BuiltinContext, dataTerm *ast.Term) (*ast.Term, error) {
	// Instead of immediately updating the cache, put it in the OverridingCache
	// which will process it with a delay and override any pending updates
	if err := cacheManager.SetDataFromTermCascade(dataTerm); err != nil {
		return nil, err
	}
	return ast.BooleanTerm(true), nil
}

func builtinPermitReBACAllRoles(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error) {
	var input pinput.InputObj
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	cache := ocache.NewCacheManager(interQueryCache)
	dataPtr, err := cache.GetData()
	if err != nil {
		return nil, err
	}

	topToBottomPtr, err := cache.GetTopToBottomData()
	if err != nil {
		return nil, err
	}
	return getReBACAllRoles(bctx.Context, dataPtr, &input, topToBottomPtr.Tuples, topToBottomPtr.Derivations)
}

func builtinPermitReBACInlineAllRoles(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error) {
	var data pdata.DataObj
	if err := ast.As(dataTerm.Value, &data); err != nil {
		return nil, err
	}
	var input pinput.InputObj
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	topToBottomPtr := pdata.NewTopToBottomFromData(&data)
	return getReBACAllRoles(bctx.Context, &data, &input, topToBottomPtr.Tuples, topToBottomPtr.Derivations)
}

func builtinPermitReBACInlineLinkedUsers(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error) {
	var data pdata.DataObj
	if err := ast.As(dataTerm.Value, &data); err != nil {
		return nil, err
	}
	var input pinput.InputResource
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	if input.Key == "" {
		return nil, fmt.Errorf("resource key is empty")
	}
	graphBuilder := graphy.NewGraphBuilder().
		FromDataObj(&data).
		WithCacheSize(new_walker.CacheSize)
	graphObj := graphBuilder.Build()
	return getReBACLinkedUsers(bctx.Context, &data, graphObj, &input)
}

func builtinPermitReBACLinkedUsers(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error) {
	var input pinput.InputResource
	if err := ast.As(inputTerm.Value, &input); err != nil {
		return nil, err
	}
	if input.Key == "" {
		return nil, fmt.Errorf("resource key is empty")
	}
	cache := ocache.NewCacheManager(interQueryCache)
	cachedData, err := cache.GetData()
	if err != nil {
		return nil, err
	}
	cachedGraph, err := cache.GetGraph()
	if err != nil {
		return nil, err
	}
	return getReBACLinkedUsers(bctx.Context, cachedData, cachedGraph, &input)
}

func permitLegacyReBACRolesFunc() (*rego.Function, func(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             legacyRebacRolesFuncName,
			Decl:             types.NewFunction(types.Args(types.A, types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinLegacyPermitReBACRoles
}

func permitReBACRolesFunc() (*rego.Function, func(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacRolesFuncName,
			Decl:             types.NewFunction(types.Args(types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitReBACRoles
}

func permitUpdateDataFunc() (*rego.Function, func(bctx rego.BuiltinContext, dataTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacUpdateCacheFuncName,
			Decl:             types.NewFunction(types.Args(types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitUpdateData
}

func permitReBACAllRolesFunc() (*rego.Function, func(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacAllRolesFuncName,
			Decl:             types.NewFunction(types.Args(types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitReBACAllRoles
}

func permitReBACInlineAllRolesFunc() (*rego.Function, func(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacInlineAllRolesFuncName,
			Decl:             types.NewFunction(types.Args(types.A, types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitReBACInlineAllRoles
}

func permitReBACLinkedUsersFunc() (*rego.Function, func(bctx rego.BuiltinContext, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacLinkedUsersFuncName,
			Decl:             types.NewFunction(types.Args(types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitReBACLinkedUsers
}

func permitReBACInlineLinkedUsersFunc() (*rego.Function, func(bctx rego.BuiltinContext, dataTerm, inputTerm *ast.Term) (*ast.Term, error)) {
	return &rego.Function{
			Name:             rebacInlineLinkedUsersFuncName,
			Decl:             types.NewFunction(types.Args(types.A, types.A), types.A),
			Memoize:          true,
			Nondeterministic: true,
		},
		builtinPermitReBACInlineLinkedUsers
}

func main() {
	updaterFactory := plugin.NewUpdaterFactory(cacheManager)
	runtime.RegisterPlugin(plugin.PluginName, updaterFactory)
	rego.RegisterBuiltin1(
		permitUpdateDataFunc(),
	)
	rego.RegisterBuiltin1(
		permitReBACRolesFunc(),
	)
	rego.RegisterBuiltin1(
		permitReBACAllRolesFunc(),
	)
	rego.RegisterBuiltin2(
		permitLegacyReBACRolesFunc(),
	)
	rego.RegisterBuiltin1(
		permitReBACLinkedUsersFunc(),
	)
	rego.RegisterBuiltin2(
		permitReBACInlineAllRolesFunc(),
	)
	rego.RegisterBuiltin2(
		permitReBACInlineLinkedUsersFunc(),
	)

	if err := cmd.RootCommand.Execute(); err != nil {
		zap.S().Errorf("Error executing root command: %v", err)
		os.Exit(1)
	}
}
