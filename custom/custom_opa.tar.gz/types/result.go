package types

import (
	"github.com/permitio/permit-opa/types/debug"
	"github.com/samber/lo"
)

type LinkedUserRoleTuple struct {
	Role       string                    `json:"role"`
	RootGrants []debug.RootGrantingBlock `json:"root_grants"`
}

func (l *LinkedUserRoleTuple) GetRole() string {
	return l.Role
}

type LinkedUserRolesWithRootGrants map[string][]debug.RootGrantingBlock

type LinkedUsersResultTuple struct {
	Roles    LinkedUserRolesWithRootGrants   `json:"roles"`
	Debugger map[string]*debug.GrantingBlock `json:"debugger,omitempty"`
}

func (l *LinkedUsersResultTuple) GetRoles() []string {
	return lo.Keys(l.Roles)
}

type ResultTuple struct {
	Roles    []string                        `json:"roles"`
	Debugger map[string]*debug.GrantingBlock `json:"debugger,omitempty"`
}
