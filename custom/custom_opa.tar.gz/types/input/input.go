package input

import (
	"fmt"
	"strings"
)

type User struct {
	Key string `json:"key"`
}

func NewUserFromString(user string) User {
	formattedUser, _ := strings.CutPrefix(user, "user:")
	return User{Key: formattedUser}
}

func (u *User) Full() string {
	return fmt.Sprintf("user:%s", u.Key)
}

type InputObj struct {
	User     User          `json:"user"`
	Resource InputResource `json:"resource"`
}
