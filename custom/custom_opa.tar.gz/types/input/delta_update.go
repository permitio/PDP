package input

import "encoding/json"

type DeltaUpdate struct {
	Path  string          `json:"path"`
	Value json.RawMessage `json:"value"`
}
