package input

import (
	"fmt"
	"strings"
)

type InputResource struct {
	Key  string `json:"key"`
	Type string `json:"type"`
}

func NewResourceFromString(resource string) InputResource {
	parts := strings.SplitN(resource, ":", 2)
	var resourceType, resourceKey string
	if len(parts) == 1 {
		resourceType = "__tenant"
		resourceKey = parts[0]
	} else {
		resourceType = parts[0]
		resourceKey = parts[1]
	}
	return InputResource{
		Key:  resourceKey,
		Type: resourceType,
	}
}

func NewResource(resourceKey, resourceType string) InputResource {
	return InputResource{
		Key:  resourceKey,
		Type: resourceType,
	}
}

func (r *InputResource) String() string {
	return fmt.Sprintf("%s:%s", r.Type, r.Key)
}
