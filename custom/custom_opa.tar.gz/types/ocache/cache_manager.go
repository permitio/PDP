package ocache

import (
	"context"
	"fmt"
	"sync"
	"time"

	e "errors"
	"github.com/open-policy-agent/opa/ast"
	"github.com/open-policy-agent/opa/topdown/cache"
	"github.com/permitio/permit-opa/graph/graphy"
	"github.com/permitio/permit-opa/graph/new_walker"
	pdata "github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/input"
	"github.com/pkg/errors"
)

const (
	dataCacheKeyName        = "data"
	topToBottomCacheKeyName = "top-to-bottom"
	graphCacheKeyName       = "graph"
)

var defaultInterQueryCacheConfig, _ = cache.ParseCachingConfig(nil)
var defaultInterQueryCache = cache.NewInterQueryCache(defaultInterQueryCacheConfig)
var dataCacheKey = ast.MustInterfaceToValue(dataCacheKeyName)
var topToBottomCacheKey = ast.MustInterfaceToValue(topToBottomCacheKeyName)
var graphCacheKey = ast.MustInterfaceToValue(graphCacheKeyName)

type CacheManager struct {
	InterQueryBuiltinCache cache.InterQueryCache
	lock                   sync.Mutex
}

func NewCacheManager(interQueryCache cache.InterQueryCache) *CacheManager {
	if interQueryCache == nil {
		interQueryCache = defaultInterQueryCache
	}
	return &CacheManager{
		InterQueryBuiltinCache: interQueryCache,
	}
}

func (c *CacheManager) SetDataFromTerm(dataTerm *ast.Term) error {
	var data pdata.DataObj
	if err := ast.As(dataTerm.Value, &data); err != nil {
		return err
	}
	c.SetData(&data)
	// clear the tree because when a data is updated the tree is no longer valid
	// and should be recreated lazy on the next call to use it
	c.ClearTopToBottom()
	c.ClearGraph()
	return nil
}

func (c *CacheManager) SetDataFromTermCascade(dataTerm *ast.Term) error {
	var data pdata.DataObj
	if err := ast.As(dataTerm.Value, &data); err != nil {
		return err
	}
	c.SetData(&data)
	c.SetGraphFromData(&data)
	c.SetTopToBottomFromData(&data)
	return nil
}

func (c *CacheManager) SetData(data *pdata.DataObj) {
	c.setData(data)
}

func (c *CacheManager) ClearData() {
	c.InterQueryBuiltinCache.Delete(dataCacheKey)
}

func (c *CacheManager) ClearTopToBottom() {
	c.InterQueryBuiltinCache.Delete(topToBottomCacheKey)
}

func (c *CacheManager) ClearGraph() {
	c.InterQueryBuiltinCache.Delete(graphCacheKey)
}

// GetData returns the current data object, creating it if it doesn't exist
func (c *CacheManager) GetData() (*pdata.DataObj, error) {
	dataValue, found := c.InterQueryBuiltinCache.Get(dataCacheKey)
	if !found {
		dataPtr := pdata.NewDataObj()
		c.SetData(dataPtr)
		return dataPtr, nil
	} else {
		dataPtr, ok := dataValue.(*pdata.DataObj)
		if !ok {
			return nil, fmt.Errorf("data stored is not of type pdata.DataObj")
		}
		return dataPtr, nil
	}
}

func (c *CacheManager) setData(data *pdata.DataObj) {
	c.InterQueryBuiltinCache.Insert(dataCacheKey, data)
}

func (c *CacheManager) setGraph(graph *graphy.Graph) {
	c.InterQueryBuiltinCache.Insert(graphCacheKey, graph)
}

func (c *CacheManager) setTopToBottom(topToBottom *pdata.TopToBottom) {
	c.InterQueryBuiltinCache.Insert(topToBottomCacheKey, topToBottom)
}

func (c *CacheManager) SetGraphFromData(data *pdata.DataObj) *graphy.Graph {
	graph := graphy.NewGraphBuilder().
		FromDataObj(data).
		WithCacheSize(new_walker.CacheSize).
		Build()
	c.setGraph(graph)
	return graph
}

func (c *CacheManager) SetTopToBottomFromData(data *pdata.DataObj) *pdata.TopToBottom {
	topToBottom := pdata.NewTopToBottomFromData(data)
	c.setTopToBottom(topToBottom)
	return topToBottom
}

func (c *CacheManager) GetGraph() (*graphy.Graph, error) {
	graphValue, found := c.InterQueryBuiltinCache.Get(graphCacheKey)
	if !found {
		data, err := c.GetData()
		if err != nil {
			return nil, fmt.Errorf("graph not found and %s", err)
		}
		graphPtr := c.SetGraphFromData(data)
		return graphPtr, nil
	}
	graphPtr, ok := graphValue.(*graphy.Graph)
	if !ok {
		return nil, fmt.Errorf("graph stored is not of type pdata.Graph")
	}
	return graphPtr, nil
}

func (c *CacheManager) GetTopToBottomData() (*pdata.TopToBottom, error) {
	var topToBottomPtr *pdata.TopToBottom
	topToBottomValue, found := c.InterQueryBuiltinCache.Get(topToBottomCacheKey)
	if !found {
		data, err := c.GetData()
		if err != nil {
			return nil, fmt.Errorf("top to bottom not found and %s", err)
		}
		topToBottomPtr = c.SetTopToBottomFromData(data)
	} else {
		var ok bool
		topToBottomPtr, ok = topToBottomValue.(*pdata.TopToBottom)
		if !ok {
			return nil, fmt.Errorf("top to bottom is not of type TopToBottom")
		}
	}
	return topToBottomPtr, nil
}

func (c *CacheManager) getAllDataObjects() (*pdata.DataObj, *pdata.TopToBottom, *graphy.Graph, error) {
	data, err := c.GetData()
	if err != nil {
		return nil, nil, nil, errors.Wrap(err, "failed to get data")
	}
	topToBottom, err := c.GetTopToBottomData()
	if err != nil {
		return nil, nil, nil, errors.Wrap(err, "failed to get top to bottom data")
	}
	graph, err := c.GetGraph()
	if err != nil {
		return nil, nil, nil, errors.Wrap(err, "failed to get graph")
	}
	return data, topToBottom, graph, nil
}

func (c *CacheManager) tryUpdateDelta(ctx context.Context, deltaUpdate *input.DeltaUpdate) (cache.InterQueryCache, error) {
	c.lock.Lock()
	defer c.lock.Unlock()
	var data *pdata.DataObj
	var topToBottom *pdata.TopToBottom
	var graph *graphy.Graph
	var err error
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
		data, topToBottom, graph, err = c.getAllDataObjects()
		if err != nil {
			return nil, errors.Wrap(err, "failed to get all data objects")
		}
	}
	data, err = data.ApplyDeltaUpdate(deltaUpdate)
	if err != nil {
		return nil, NewDeltaUpdateFailure(err, deltaUpdate.Path, "data")
	}
	topToBottom, err = topToBottom.ApplyDeltaUpdate(deltaUpdate)
	if err != nil {
		return nil, NewDeltaUpdateFailure(err, deltaUpdate.Path, "topToBottom")
	}
	graph, err = graph.ApplyDeltaUpdate(deltaUpdate)
	if err != nil {
		return nil, NewDeltaUpdateFailure(err, deltaUpdate.Path, "graph")
	}
	c.setData(data)
	c.setTopToBottom(topToBottom)
	c.setGraph(graph)
	return c.InterQueryBuiltinCache, nil
}

func (c *CacheManager) tryUpdateDeltaWithTimeout(ctx context.Context, deltaUpdate *input.DeltaUpdate, timeout time.Duration) (cache.InterQueryCache, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	return c.tryUpdateDelta(ctx, deltaUpdate)
}

func (c *CacheManager) UpdateDelta(ctx context.Context, deltaUpdate *input.DeltaUpdate, maxRetries int, backoff time.Duration, maxBackoff time.Duration) (cache.InterQueryCache, error) {
	var err error
	for retry := 0; retry < maxRetries; retry++ {
		cache, tryErr := c.tryUpdateDeltaWithTimeout(ctx, deltaUpdate, backoff)
		if tryErr == nil {
			return cache, nil
		} else if e.As(tryErr, &DeltaUpdateFailure{}) {
			// if we got DeltaUpdateFailure, we don't want to retry because we have a corrupted state due to
			// missing of atomicity in the ApplyDeltaUpdate methods
			return nil, tryErr
		}
		err = e.Join(tryErr, err)
		if retry != maxRetries-1 {
			backoff = min(backoff*2, maxBackoff)
			time.Sleep(backoff)
		} else {
			err = e.Join(err, NewRetriesExhaustedError(tryErr, maxRetries, deltaUpdate.Path))
		}
	}
	return nil, err
}
