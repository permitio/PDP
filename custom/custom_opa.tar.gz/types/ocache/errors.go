package ocache

import "fmt"

type RetriesExhaustedError struct {
	Err        error
	MaxRetries int
	Path       string
}

func NewRetriesExhaustedError(err error, maxRetries int, path string) *RetriesExhaustedError {
	return &RetriesExhaustedError{
		Err:        err,
		MaxRetries: maxRetries,
		Path:       path,
	}
}

func (r RetriesExhaustedError) Error() string {
	return fmt.Sprintf("exhausted retries of %d trying to update delta for path %s due to %s", r.MaxRetries, r.Path, r.Err)
}

type DeltaUpdateFailure struct {
	Err       error
	Path      string
	FailedObj string
}

func NewDeltaUpdateFailure(err error, path string, failedObj string) *DeltaUpdateFailure {
	return &DeltaUpdateFailure{
		Err:       err,
		Path:      path,
		FailedObj: failedObj,
	}
}

func (d DeltaUpdateFailure) Error() string {
	return fmt.Sprintf("failed to update delta for path %s due to %s, failed object: %s", d.Path, d.Err, d.FailedObj)
}
