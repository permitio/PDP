package debug

import (
	"encoding/json"
	"fmt"
	"strings"
)

const roleDelimiter = "#"

type Role struct {
	Resource string
	Role     string
}

func NewRole(resource, role string) *Role {
	return &Role{
		Resource: resource,
		Role:     role,
	}
}

func (r *Role) String() string {
	return fmt.Sprintf("%s%s%s", r.Resource, roleDelimiter, r.Role)
}

func (r *Role) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`"%s"`, r.String())), nil
}

func (r *Role) UnmarshalJSON(b []byte) error {
	var roleStr string
	err := json.Unmarshal(b, &roleStr)
	if err != nil {
		return err
	}
	resourceType, roleKey, found := strings.Cut(roleStr, roleDelimiter)
	if !found {
		return fmt.Errorf("invalid role string %s", roleStr)
	}
	r.Role = roleKey
	r.Resource = resourceType
	return nil
}
