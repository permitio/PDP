package debug

import (
	"encoding/json"
	"fmt"
	"strings"
)

const resourceDelimiter = ":"

type Resource struct {
	Key  string `json:"key"`
	Type string `json:"type"`
}

func NewResource(resourceKey, resourceType string) *Resource {
	return &Resource{
		Key:  resourceKey,
		Type: resourceType,
	}
}

func (r *Resource) String() string {
	return fmt.Sprintf("%s%s%s", r.Type, resourceDelimiter, r.Key)
}
func (r *Resource) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(`"%s"`, r.String())), nil
}

func (r *Resource) UnmarshalJSON(b []byte) error {
	var resourceStr string
	err := json.Unmarshal(b, &resourceStr)
	if err != nil {
		return err
	}
	resourceType, resourceKey, found := strings.Cut(resourceStr, resourceDelimiter)
	if !found {
		return fmt.Errorf("invalid resource string %s", resourceStr)
	}
	r.Key = resourceKey
	r.Type = resourceType
	return nil
}
