package debug

import (
	"fmt"
)

type Relation string

func (r Relation) String() string {
	return fmt.Sprintf("relation:%s", string(r))
}

func (r Relation) MarshalJSON() ([]byte, error) {
	return []byte(r.String()), nil
}
