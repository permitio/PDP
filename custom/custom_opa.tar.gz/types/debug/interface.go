package debug

import (
	"encoding/json"
	"fmt"
	"strings"

	"github.com/samber/lo"
	lop "github.com/samber/lo/parallel"
)

type GrantingType string

const (
	RoleAssignment GrantingType = "role_assignment"
	RoleDerivation GrantingType = "role_derivation"
)

type RelationshipTuple struct {
	Subject  *Resource
	Relation Relation
	Object   *Resource
}

func (r *RelationshipTuple) MarshalJSON() ([]byte, error) {
	return []byte(fmt.Sprintf(
		`"(%s, %s, %s)"`,
		r.Subject, r.Relation, r.Object,
	)), nil
}

func (r *RelationshipTuple) UnmarshalJSON(b []byte) error {
	var relationshipTupleStr string
	err := json.Unmarshal(b, &relationshipTupleStr)
	if err != nil {
		return err
	}
	if len(relationshipTupleStr) < 2 {
		return fmt.Errorf("invalid relationship tuple string %s, supposed to have (subject, relation, object) format",
			relationshipTupleStr)
	}
	parts := strings.Split(relationshipTupleStr[1:len(relationshipTupleStr)-1], ", ")
	if len(parts) != 3 {
		return fmt.Errorf("invalid relationship tuple string %s, supposed to have (subject, relation, object) format",
			relationshipTupleStr)
	}
	err = json.Unmarshal(fmt.Appendf(nil, `"%s"`, parts[0]), &r.Subject)
	if err != nil {
		return err
	}
	err = json.Unmarshal(fmt.Appendf(nil, `"%s"`, parts[1]), &r.Relation)
	if err != nil {
		return err
	}
	err = json.Unmarshal(fmt.Appendf(nil, `"%s"`, parts[2]), &r.Object)
	if err != nil {
		return err
	}
	return nil
}

type RootGrantingBlock struct {
	Role     *Role     `json:"role,omitempty"`
	Resource *Resource `json:"resource,omitempty"`
}

type GrantingBlock struct {
	Type         GrantingType       `json:"type,omitempty"`
	Role         *Role              `json:"role,omitempty"`
	Resource     *Resource          `json:"resource,omitempty"`
	Relationship *RelationshipTuple `json:"relationship,omitempty"`
	Sources      []*GrantingBlock   `json:"sources,omitempty"`
	Reason       string             `json:"reason,omitempty"`
}

func NewGrantingBlock(role *Role, resource *Resource) *GrantingBlock {
	return &GrantingBlock{
		Role:     role,
		Resource: resource,
	}
}

func NewRoleAssignmentGrantingBlock() *GrantingBlock {
	return &GrantingBlock{
		Type: RoleAssignment,
	}
}

func (g *GrantingBlock) BuildReasonMessage() string {
	msg := fmt.Sprintf("granted by '%s#%s'", g.Resource.String(), g.Role.Role)
	if len(g.Sources) == 0 {
		return msg
	}
	firstSource := g.Sources[0]
	if firstSource.Type == RoleAssignment {
		return msg
	}
	msg = fmt.Sprintf("%s which is %s", msg, firstSource.BuildReasonMessage())
	return msg
}

func (g *GrantingBlock) getRootGrantingBlock(childGrant *GrantingBlock) []RootGrantingBlock {
	if childGrant == nil {
		if g.Role != nil && g.Resource != nil {
			return []RootGrantingBlock{
				{
					Role:     g.Role,
					Resource: g.Resource,
				},
			}
		}
		return []RootGrantingBlock{}
	}
	switch g.Type {
	case RoleAssignment:
		return []RootGrantingBlock{
			{
				Role:     childGrant.Role,
				Resource: childGrant.Resource,
			},
		}
	case RoleDerivation:
		if g.Sources == nil {
			return []RootGrantingBlock{}
		}
		rootGrantingBlocks := lo.Map(
			g.Sources,
			func(item *GrantingBlock, _ int) []RootGrantingBlock {
				return item.getRootGrantingBlock(g)
			},
		)
		return lo.Flatten(rootGrantingBlocks)
	default:
		return []RootGrantingBlock{}
	}
}

func (g *GrantingBlock) GetRootGrantingBlocks() []RootGrantingBlock {
	if g.Sources == nil {
		return []RootGrantingBlock{}
	}
	return lo.Flatten(
		lop.Map(g.Sources, func(item *GrantingBlock, _ int) []RootGrantingBlock {
			return item.getRootGrantingBlock(g)
		}),
	)
}

func (g *GrantingBlock) WithType(t GrantingType) *GrantingBlock {
	g.Type = t
	return g
}

func (g *GrantingBlock) WithSources(sources []*GrantingBlock) *GrantingBlock {
	g.Sources = sources
	return g
}

func (g *GrantingBlock) WithRelationship(relationship *RelationshipTuple) *GrantingBlock {
	g.Relationship = relationship
	return g
}
