package data

import (
	"encoding/json"
	"github.com/permitio/permit-opa/types/input"
)

// ResourceTypesRelationships The key is the resource type the value is the list of resource instances
type ResourceTypesRelationships map[string][]string

// Relations The key is the relation the value is ResourceTypesRelationships
type Relations map[string]ResourceTypesRelationships

// RelationshipTuples The key is the object resource instance the value is Relations
type RelationshipTuples map[string]Relations

func (r RelationshipTuples) BuildTopToBottom() ReverseRelationshipTuples {
	reversedTuples := make(ReverseRelationshipTuples)
	for object, relationsMap := range r {
		objectResource := input.NewResourceFromString(object)
		for relation, resourceTypesMap := range relationsMap {
			for resourceType, subjects := range resourceTypesMap {
				for _, subject := range subjects {
					subjectResource := input.NewResource(subject, resourceType)
					reversedRelationMap, found := reversedTuples[subjectResource.String()]
					if !found {
						reversedRelationMap = make(Relations)
					}
					reversedResourceTypesMap, found := reversedRelationMap[relation]
					if !found {
						reversedResourceTypesMap = make(ResourceTypesRelationships)
					}
					reversedObjects, found := reversedResourceTypesMap[objectResource.Type]
					if !found {
						reversedObjects = make([]string, 0)
					}
					reversedObjects = append(reversedObjects, objectResource.Key)
					reversedResourceTypesMap[objectResource.Type] = reversedObjects
					reversedRelationMap[relation] = reversedResourceTypesMap
					reversedTuples[subjectResource.String()] = reversedRelationMap
				}
			}
		}
	}
	return reversedTuples
}

// ReverseRelationshipTuples The key is the subject resource instance the value is Relations
type ReverseRelationshipTuples RelationshipTuples

func (d *ReverseRelationshipTuples) SizeInBytes() int64 {
	dataBytes, _ := json.Marshal(d)
	return int64(len(dataBytes))
}
