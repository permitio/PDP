package data

type Assignments map[string][]string

type RoleAssignments map[string]Assignments
