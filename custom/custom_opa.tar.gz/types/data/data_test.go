package data

import (
	"encoding/json"
	"path/filepath"
	"testing"

	"github.com/permitio/permit-opa/types/input"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Test that applying full section replacements works correctly
func TestDataObjIncrementalBuild(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Create an empty DataObj
			emptyDataObj := &DataObj{
				Relationships:   make(RelationshipTuples),
				RoleAssignments: make(RoleAssignments),
				ResourceTypes:   make(ResourceTypes),
			}

			// Test each section replacement individually

			// 1. Apply relationships replacement
			relationshipsData, err := json.Marshal(origDataObj.Relationships)
			require.NoError(t, err, "Failed to marshal relationships")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships",
				Value: relationshipsData,
			}

			result, err := emptyDataObj.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply relationships replacement")
			emptyDataObj = result

			// 2. Apply role assignments replacement
			roleAssignmentsData, err := json.Marshal(origDataObj.RoleAssignments)
			require.NoError(t, err, "Failed to marshal role assignments")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/role_assignments",
				Value: roleAssignmentsData,
			}

			result, err = emptyDataObj.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply role assignments replacement")
			emptyDataObj = result

			// 3. Apply resource types replacement
			resourceTypesData, err := json.Marshal(origDataObj.ResourceTypes)
			require.NoError(t, err, "Failed to marshal resource types")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: resourceTypesData,
			}

			result, err = emptyDataObj.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply resource types replacement")
			emptyDataObj = result

			// Convert both to JSON for comparison
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			resultJSON, err := json.Marshal(emptyDataObj)
			require.NoError(t, err, "Failed to marshal result DataObj")

			assert.JSONEq(t, string(originalJSON), string(resultJSON), "DataObj objects don't match after incremental build")
		})
	}
}

// Test that removing and adding back a relationship works correctly
func TestDataObjRelationshipRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(origDataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Choose a relationship to remove and add back
			var objectToTest string
			var relationsToTest Relations
			for object, relations := range origDataObj.Relationships {
				if len(relations) > 0 {
					objectToTest = object
					relationsToTest = relations
					break
				}
			}

			// Skip if we didn't find a suitable relationship
			if objectToTest == "" {
				t.Skip("No suitable relationship found for testing")
			}

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove the relationship
			emptyRelations := Relations{}
			emptyValue, err := json.Marshal(emptyRelations)
			require.NoError(t, err, "Failed to marshal empty relations")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove relationship")
			workingCopy = afterRemoval

			// Verify the relationship was removed
			assert.Empty(t, workingCopy.Relationships[objectToTest],
				"Relationship should be empty after removal")

			// Add the relationship back
			relationsValue, err := json.Marshal(relationsToTest)
			require.NoError(t, err, "Failed to marshal relations")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: relationsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationship back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back relationship")
		})
	}
}

// Test that removing and adding back a resource type works correctly
func TestDataObjResourceTypeRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types
			if len(origDataObj.ResourceTypes) == 0 {
				t.Skip("No resource types in data, skipping")
			}

			// Choose a resource type to remove and add back
			var resourceTypeToTest string
			var resourceTypeObjToTest ResourceType
			for rt, rtObj := range origDataObj.ResourceTypes {
				resourceTypeToTest = rt
				resourceTypeObjToTest = rtObj
				break
			}

			// Skip if we didn't find a suitable resource type
			if resourceTypeToTest == "" {
				t.Skip("No suitable resource type found for testing")
			}

			t.Logf("Selected resource type for testing: %s", resourceTypeToTest)

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove the resource type by replacing it with an empty one
			emptyResourceType := ResourceType{
				Actions:      []string{},
				DerivedRoles: make(map[string]RoleDerivation),
			}
			emptyValue, err := json.Marshal(emptyResourceType)
			require.NoError(t, err, "Failed to marshal empty resource type")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types/" + resourceTypeToTest,
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove resource type")
			workingCopy = afterRemoval

			// Verify the resource type was modified (empty derivations)
			assert.Empty(t, workingCopy.ResourceTypes[resourceTypeToTest].DerivedRoles,
				"Resource type should have empty derived roles after removal")

			// Add the resource type back
			resourceTypeValue, err := json.Marshal(resourceTypeObjToTest)
			require.NoError(t, err, "Failed to marshal resource type")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types/" + resourceTypeToTest,
				Value: resourceTypeValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource type back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back resource type")
		})
	}
}

// Test that removing and adding back a role assignment works correctly
func TestDataObjRoleAssignmentRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no role assignments
			if len(origDataObj.RoleAssignments) == 0 {
				t.Skip("No role assignments in data, skipping")
			}

			// Choose a role assignment to remove and add back
			var objectToTest string
			var assignmentsToTest Assignments
			for object, assignments := range origDataObj.RoleAssignments {
				if len(assignments) > 0 {
					objectToTest = object
					assignmentsToTest = assignments
					break
				}
			}

			// Skip if we didn't find a suitable role assignment
			if objectToTest == "" {
				t.Skip("No suitable role assignment found for testing")
			}

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove the role assignment
			emptyAssignments := Assignments{}
			emptyValue, err := json.Marshal(emptyAssignments)
			require.NoError(t, err, "Failed to marshal empty assignments")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/role_assignments/" + objectToTest,
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove role assignment")
			workingCopy = afterRemoval

			// Verify the role assignment was removed
			assert.Empty(t, workingCopy.RoleAssignments[objectToTest],
				"Role assignment should be empty after removal")

			// Add the role assignment back
			assignmentsValue, err := json.Marshal(assignmentsToTest)
			require.NoError(t, err, "Failed to marshal assignments")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/role_assignments/" + objectToTest,
				Value: assignmentsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add role assignment back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back role assignment")
		})
	}
}

// Test that removing and adding back all relationships works correctly
func TestDataObjRelationshipsMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(origDataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove all relationships by replacing with empty map
			emptyRelationships := RelationshipTuples{}
			emptyValue, err := json.Marshal(emptyRelationships)
			require.NoError(t, err, "Failed to marshal empty relationships")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships",
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all relationships")
			workingCopy = afterRemoval

			// Verify all relationships were removed
			assert.Empty(t, workingCopy.Relationships, "All relationships should be removed")

			// Add all relationships back
			relationshipsValue, err := json.Marshal(origDataObj.Relationships)
			require.NoError(t, err, "Failed to marshal relationships")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships",
				Value: relationshipsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationships back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back all relationships")
		})
	}
}

// Test that removing and adding back all role assignments works correctly
func TestDataObjRoleAssignmentsMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no role assignments
			if len(origDataObj.RoleAssignments) == 0 {
				t.Skip("No role assignments in data, skipping")
			}

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove all role assignments by replacing with empty map
			emptyRoleAssignments := RoleAssignments{}
			emptyValue, err := json.Marshal(emptyRoleAssignments)
			require.NoError(t, err, "Failed to marshal empty role assignments")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/role_assignments",
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all role assignments")
			workingCopy = afterRemoval

			// Verify all role assignments were removed
			assert.Empty(t, workingCopy.RoleAssignments, "All role assignments should be removed")

			// Add all role assignments back
			roleAssignmentsValue, err := json.Marshal(origDataObj.RoleAssignments)
			require.NoError(t, err, "Failed to marshal role assignments")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/role_assignments",
				Value: roleAssignmentsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add role assignments back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back all role assignments")
		})
	}
}

// Test that removing and adding back all resource types works correctly
func TestDataObjResourceTypesMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types
			if len(origDataObj.ResourceTypes) == 0 {
				t.Skip("No resource types in data, skipping")
			}

			// Create a deep copy of the original
			copyBeforeRemoval, err := origDataObj.Clone()
			require.NoError(t, err, "Failed to clone original DataObj")
			workingCopy := copyBeforeRemoval.(*DataObj)

			// Remove all resource types by replacing with empty map
			emptyResourceTypes := ResourceTypes{}
			emptyValue, err := json.Marshal(emptyResourceTypes)
			require.NoError(t, err, "Failed to marshal empty resource types")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all resource types")
			workingCopy = afterRemoval

			// Verify all resource types were removed
			assert.Empty(t, workingCopy.ResourceTypes, "All resource types should be removed")

			// Add all resource types back
			resourceTypesValue, err := json.Marshal(origDataObj.ResourceTypes)
			require.NoError(t, err, "Failed to marshal resource types")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: resourceTypesValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource types back")
			workingCopy = afterAddingBack

			// Verify that the final state matches the original
			originalJSON, err := json.Marshal(origDataObj)
			require.NoError(t, err, "Failed to marshal original DataObj")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final DataObj")

			assert.JSONEq(t, string(originalJSON), string(finalJSON),
				"DataObj objects don't match after removing and adding back all resource types")
		})
	}
}
