package data

import (
	"encoding/json"
	"strings"
	"sync"

	"github.com/open-policy-agent/opa/topdown/cache"
	"github.com/permitio/permit-opa/types/input"
	"go.uber.org/zap"
)

type DataObj struct {
	Relationships   RelationshipTuples `json:"relationships"`
	RoleAssignments RoleAssignments    `json:"role_assignments"`
	ResourceTypes   ResourceTypes      `json:"resource_types"`
	lock            sync.RWMutex
}

func NewDataObj() *DataObj {
	return &DataObj{
		Relationships:   make(RelationshipTuples),
		RoleAssignments: make(RoleAssignments),
		ResourceTypes:   make(ResourceTypes),
	}
}

func (d *DataObj) RLock() {
	d.lock.RLock()
}

func (d *DataObj) RUnlock() {
	d.lock.RUnlock()
}

func (d *DataObj) Lock() {
	d.lock.Lock()
}

func (d *DataObj) Unlock() {
	d.lock.Unlock()
}

func (d *DataObj) SizeInBytes() int64 {
	d.lock.RLock()
	defer d.lock.RUnlock()
	dataBytes, _ := json.Marshal(d)
	return int64(len(dataBytes))
}

func (d *DataObj) Clone() (cache.InterQueryCacheValue, error) {
	d.RLock()
	defer d.RUnlock()
	copyObj := DataObj{}
	dataBytes, err := json.Marshal(d)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(dataBytes, &copyObj)
	if err != nil {
		return nil, err
	}
	return &copyObj, nil
}

func (d *DataObj) applyFullReplacement(deltaUpdate *input.DeltaUpdate) error {
	var dataObj DataObj
	if err := json.Unmarshal(deltaUpdate.Value, &dataObj); err != nil {
		return err
	}
	d.Relationships = dataObj.Relationships
	d.RoleAssignments = dataObj.RoleAssignments
	d.ResourceTypes = dataObj.ResourceTypes
	return nil
}

func (d *DataObj) applyFullRelationshipsReplacement(deltaUpdate *input.DeltaUpdate) error {
	var relationships RelationshipTuples
	if err := json.Unmarshal(deltaUpdate.Value, &relationships); err != nil {
		return err
	}
	d.Relationships = relationships
	return nil
}

func (d *DataObj) applyFullRoleAssignmentsReplacement(deltaUpdate *input.DeltaUpdate) error {
	var roleAssignments RoleAssignments
	if err := json.Unmarshal(deltaUpdate.Value, &roleAssignments); err != nil {
		return err
	}
	d.RoleAssignments = roleAssignments
	return nil
}

func (d *DataObj) applyFullResourceTypesReplacement(deltaUpdate *input.DeltaUpdate) error {
	var resourceTypes ResourceTypes
	if err := json.Unmarshal(deltaUpdate.Value, &resourceTypes); err != nil {
		return err
	}
	d.ResourceTypes = resourceTypes
	return nil
}

func (d *DataObj) applyRelationshipReplacement(deltaUpdate *input.DeltaUpdate, key string) error {
	var relationships Relations
	if err := json.Unmarshal(deltaUpdate.Value, &relationships); err != nil {
		return err
	}
	d.Relationships[key] = relationships
	return nil
}

func (d *DataObj) applyRoleAssignmentReplacement(deltaUpdate *input.DeltaUpdate, key string) error {
	var assignments Assignments
	if err := json.Unmarshal(deltaUpdate.Value, &assignments); err != nil {
		return err
	}
	d.RoleAssignments[key] = assignments
	return nil
}

func (d *DataObj) applyResourceTypeReplacement(deltaUpdate *input.DeltaUpdate, key string) error {
	var resourceType ResourceType
	if err := json.Unmarshal(deltaUpdate.Value, &resourceType); err != nil {
		return err
	}
	d.ResourceTypes[key] = resourceType
	return nil
}

func (d *DataObj) ApplyDeltaUpdate(deltaUpdate *input.DeltaUpdate) (*DataObj, error) {
	d.Lock()
	defer d.Unlock()
	deltaUpdatePath := strings.Split(
		strings.TrimPrefix(deltaUpdate.Path, "/"),
		"/",
	)
	switch len(deltaUpdatePath) {
	case 1:
		switch deltaUpdatePath[0] {
		case "":
			return d, d.applyFullReplacement(deltaUpdate)
		case "relationships":
			return d, d.applyFullRelationshipsReplacement(deltaUpdate)
		case "role_assignments":
			return d, d.applyFullRoleAssignmentsReplacement(deltaUpdate)
		case "resource_types":
			return d, d.applyFullResourceTypesReplacement(deltaUpdate)
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw DataObj", deltaUpdate.Path)
			return d, nil
		}
	case 2:
		switch deltaUpdatePath[0] {
		case "relationships":
			return d, d.applyRelationshipReplacement(deltaUpdate, deltaUpdatePath[1])
		case "role_assignments":
			return d, d.applyRoleAssignmentReplacement(deltaUpdate, deltaUpdatePath[1])
		case "resource_types":
			return d, d.applyResourceTypeReplacement(deltaUpdate, deltaUpdatePath[1])
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw DataObj", deltaUpdate.Path)
			return d, nil
		}
	default:
		zap.S().Debugf("ignoring delta update for path: %s for raw DataObj", deltaUpdate.Path)
		return d, nil
	}
}
