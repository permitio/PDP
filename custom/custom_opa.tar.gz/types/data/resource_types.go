package data

import (
	"encoding/json"
	"fmt"
)

type derivedObjectMap map[string]bool

type derivationRelationMap map[string]derivedObjectMap

type DerivationSchemaMap map[string]derivationRelationMap

func (d DerivationSchemaMap) SizeInBytes() int64 {
	dataBytes, _ := json.Marshal(d)
	return int64(len(dataBytes))
}

func (d DerivationSchemaMap) AddDerivation(subjectResourceType, relation, objectResourceType string) {
	relationDerivations, found := d[subjectResourceType]
	if !found {
		relationDerivations = make(derivationRelationMap)
	}
	derivedObjects, found := relationDerivations[relation]
	if !found {
		derivedObjects = make(derivedObjectMap)
	}
	derivedObjects[objectResourceType] = true
	relationDerivations[relation] = derivedObjects
	d[subjectResourceType] = relationDerivations
}

func (d DerivationSchemaMap) CanDeriveViaRelation(subjectResourceType, relation string) bool {
	relationDerivations, found := d[subjectResourceType]
	if !found {
		return false
	}

	_, found = relationDerivations[relation]
	return found
}

func (d DerivationSchemaMap) CanDeriveToResourceViaRelation(subjectResourceType, relation, objectResourceType string) bool {
	relationDerivations, found := d[subjectResourceType]
	if !found {
		return false
	}

	derivedObjects, found := relationDerivations[relation]
	if !found {
		return false
	}
	_, found = derivedObjects[objectResourceType]
	return found
}

type ResourceTypes map[string]ResourceType

func (r ResourceTypes) BuildDerivations() DerivationSchemaMap {
	derivations := make(DerivationSchemaMap)
	for resourceType, resourceTypeObj := range r {
		for _, roleDerivation := range resourceTypeObj.DerivedRoles {
			for _, rule := range roleDerivation.Rules {
				derivations.AddDerivation(rule.RelatedResource, rule.Relation.Full(), resourceType)
			}
		}
	}

	return derivations
}

type ResourceType struct {
	Actions      []string                  `json:"actions"`
	DerivedRoles map[string]RoleDerivation `json:"derived_roles"`
}

type RoleDerivation struct {
	Conditions string               `json:"conditions"`
	Settings   SettingsBlock        `json:"settings"`
	Rules      []RoleDerivationRule `json:"rules"`
}

type SettingsBlock struct {
	SupersededByDirectRole bool `json:"superseded_by_direct_role"`
}

type RoleDerivationRule struct {
	Relation        Relation      `json:"relation"`
	RelatedResource string        `json:"related_resource"`
	RelatedRole     string        `json:"related_role"`
	Settings        SettingsBlock `json:"settings"`
}

type Relation string

func (r Relation) Full() string {
	return fmt.Sprintf("relation:%s", r)
}
