package data

import (
	"encoding/json"
	"slices"
	"strings"
	"sync"

	"github.com/open-policy-agent/opa/topdown/cache"
	"github.com/permitio/permit-opa/types/input"
	"go.uber.org/zap"
)

type TopToBottom struct {
	Derivations DerivationSchemaMap
	Tuples      ReverseRelationshipTuples
	lock        sync.RWMutex
}

func NewTopToBottomFromData(data *DataObj) *TopToBottom {
	tuples := data.Relationships.BuildTopToBottom()
	derivations := data.ResourceTypes.BuildDerivations()
	return &TopToBottom{
		Derivations: derivations,
		Tuples:      tuples,
	}
}

func (d *TopToBottom) RLock() {
	d.lock.RLock()
}

func (d *TopToBottom) RUnlock() {
	d.lock.RUnlock()
}

func (d *TopToBottom) Lock() {
	d.lock.Lock()
}

func (d *TopToBottom) Unlock() {
	d.lock.Unlock()
}

func (d *TopToBottom) SizeInBytes() int64 {
	d.RLock()
	defer d.RUnlock()
	dataBytes, _ := json.Marshal(d)
	return int64(len(dataBytes))
}

func (d *TopToBottom) Clone() (cache.InterQueryCacheValue, error) {
	d.RLock()
	defer d.RUnlock()
	copy := TopToBottom{}
	dataBytes, err := json.Marshal(d)
	if err != nil {
		return nil, err
	}
	err = json.Unmarshal(dataBytes, &copy)
	if err != nil {
		return nil, err
	}
	return &copy, nil
}

func (d *TopToBottom) applyFullReplacement(deltaUpdate *input.DeltaUpdate) (*TopToBottom, error) {
	var tempData DataObj
	if err := json.Unmarshal(deltaUpdate.Value, &tempData); err != nil {
		return nil, err
	}

	// Create a new TopToBottom instance
	return NewTopToBottomFromData(&tempData), nil
}

func (d *TopToBottom) applyFullRelationshipsReplacement(deltaUpdate *input.DeltaUpdate) error {
	var relationships RelationshipTuples
	if err := json.Unmarshal(deltaUpdate.Value, &relationships); err != nil {
		return err
	}

	// For a full replacement, we can safely use BuildTopToBottom
	d.Tuples = relationships.BuildTopToBottom()
	return nil
}

func (d *TopToBottom) applyFullResourceTypesReplacement(deltaUpdate *input.DeltaUpdate) error {
	var resourceTypes ResourceTypes
	if err := json.Unmarshal(deltaUpdate.Value, &resourceTypes); err != nil {
		return err
	}

	// For a full replacement, we can safely use BuildDerivations
	d.Derivations = resourceTypes.BuildDerivations()
	return nil
}

func (d *TopToBottom) applyRelationshipReplacement(deltaUpdate *input.DeltaUpdate, key string) error {
	var relations Relations
	if err := json.Unmarshal(deltaUpdate.Value, &relations); err != nil {
		return err
	}

	// Parse the object from the key
	objectResource := input.NewResourceFromString(key)

	// 1. First, remove any tuples where this object is referenced
	for subject, relationMap := range d.Tuples {
		relationsToDelete := []string{}

		for relation, resourceTypeMap := range relationMap {
			// Find all references to our target object and remove them
			objects, exists := resourceTypeMap[objectResource.Type]
			if exists {
				// Filter out the object we're updating
				filteredObjects := []string{}
				for _, obj := range objects {
					if obj != objectResource.Key {
						filteredObjects = append(filteredObjects, obj)
					}
				}

				if len(filteredObjects) > 0 {
					resourceTypeMap[objectResource.Type] = filteredObjects
				} else {
					delete(resourceTypeMap, objectResource.Type)
				}
			}

			// If no resource types left, mark relation for deletion
			if len(resourceTypeMap) == 0 {
				relationsToDelete = append(relationsToDelete, relation)
			}
		}

		// Delete marked relations
		for _, relation := range relationsToDelete {
			delete(relationMap, relation)
		}

		// If no relations left, mark subject for deletion
		if len(relationMap) == 0 {
			delete(d.Tuples, subject)
		}
	}

	// 2. Now add all the new relationships for this object
	// For each relation in the updated object's relations
	for relation, resourceTypesMap := range relations {
		// For each resource type in the relation
		for resourceType, subjects := range resourceTypesMap {
			// For each subject in the resource type
			for _, subject := range subjects {
				subjectResource := input.NewResource(subject, resourceType)
				subjectKey := subjectResource.String()

				// Get or create relation map for this subject
				relationMap, found := d.Tuples[subjectKey]
				if !found {
					relationMap = make(Relations)
					d.Tuples[subjectKey] = relationMap
				}

				// Get or create resource type map for this relation
				resourceTypeMap, found := relationMap[relation]
				if !found {
					resourceTypeMap = make(ResourceTypesRelationships)
					relationMap[relation] = resourceTypeMap
				}

				// Get or create objects slice for this resource type
				objects, found := resourceTypeMap[objectResource.Type]
				if !found {
					objects = []string{}
				}

				// Check if the object already exists in the slice
				exists := slices.Contains(objects, objectResource.Key)

				// Add the object if it doesn't already exist
				if !exists {
					objects = append(objects, objectResource.Key)
					resourceTypeMap[objectResource.Type] = objects
				}
			}
		}
	}

	return nil
}

func (d *TopToBottom) applyResourceTypeReplacement(deltaUpdate *input.DeltaUpdate, key string) error {
	var resourceType ResourceType
	if err := json.Unmarshal(deltaUpdate.Value, &resourceType); err != nil {
		return err
	}

	// When a resource type is updated or added, we need to ensure all dependencies are correctly handled

	// If this is effectively a removal (empty derived roles)
	if len(resourceType.DerivedRoles) == 0 {
		// Remove it as a subject
		delete(d.Derivations, key)

		// Remove it as an object
		for subjectType, relationMap := range d.Derivations {
			relationsToDelete := []string{}

			for relation, objectTypeMap := range relationMap {
				// Delete this resource type from all object maps
				delete(objectTypeMap, key)

				// If the object map is now empty, mark the relation for deletion
				if len(objectTypeMap) == 0 {
					relationsToDelete = append(relationsToDelete, relation)
				}
			}

			// Remove marked relations
			for _, relation := range relationsToDelete {
				delete(relationMap, relation)
			}

			// If all relations are empty, remove the subject type
			if len(relationMap) == 0 {
				delete(d.Derivations, subjectType)
			}
		}

		return nil
	}

	// For complex derivation rules, we need a full context of the resource types
	// to rebuild derivations correctly. However, we don't have direct access to
	// the complete ResourceTypes map. We'll need to:

	// 1. Extract resource type dependencies from the updated resourceType
	resourceTypeDependencies := make(map[string]bool)
	resourceTypeDependencies[key] = true // Include our updated type

	// Extract dependencies from the derived roles
	for _, derivedRole := range resourceType.DerivedRoles {
		for _, rule := range derivedRole.Rules {
			relatedResource := rule.RelatedResource
			if relatedResource != "" {
				resourceTypeDependencies[relatedResource] = true
			}
		}
	}

	// 2. Check if any of the current derivations involve the updated resource type
	// Either as subject or object
	for subjectType, relationMap := range d.Derivations {
		// If our updated type is related to any existing derivation, we'll need it
		resourceTypeDependencies[subjectType] = true

		for _, objectTypeMap := range relationMap {
			for objectType := range objectTypeMap {
				resourceTypeDependencies[objectType] = true
			}
		}
	}

	// 3. Create a filter to keep only the derivations that involve our identified resource types
	newDerivations := make(DerivationSchemaMap)

	// 3a. First, remove any existing derivation for the updated resource type
	// This ensures we don't have stale derivations
	delete(d.Derivations, key)

	// 3b. Remove it as an object in other derivations
	for _, relationMap := range d.Derivations {
		for _, objectTypeMap := range relationMap {
			delete(objectTypeMap, key)
		}
	}

	// 4. Create a complete new derivation map by adding our resource type
	// Keep existing derivations that don't involve our key, and add new ones
	// based on the updated resource type

	// 4a. Add derivations from the updated resource type
	for _, derivedRole := range resourceType.DerivedRoles {
		for _, rule := range derivedRole.Rules {
			// Each rule establishes a relationship from relatedResource -> key via relation
			relationName := rule.Relation.Full()
			relatedResource := rule.RelatedResource

			// Add this derivation
			if _, exists := newDerivations[relatedResource]; !exists {
				newDerivations[relatedResource] = make(derivationRelationMap)
			}

			if _, exists := newDerivations[relatedResource][relationName]; !exists {
				newDerivations[relatedResource][relationName] = make(derivedObjectMap)
			}

			newDerivations[relatedResource][relationName][key] = true
		}
	}

	// 4b. Merge existing derivations
	for subjectType, relationMap := range d.Derivations {
		if _, exists := newDerivations[subjectType]; !exists {
			newDerivations[subjectType] = make(derivationRelationMap)
		}

		for relation, objectTypeMap := range relationMap {
			if _, exists := newDerivations[subjectType][relation]; !exists {
				newDerivations[subjectType][relation] = make(derivedObjectMap)
			}

			// Merge object types
			for objectType, value := range objectTypeMap {
				newDerivations[subjectType][relation][objectType] = value
			}
		}
	}

	// 5. Update the derivation map
	d.Derivations = newDerivations

	return nil
}

// ApplyDeltaUpdate applies incremental updates to the TopToBottom structure without rebuilding it completely.
func (d *TopToBottom) ApplyDeltaUpdate(deltaUpdate *input.DeltaUpdate) (*TopToBottom, error) {
	d.Lock()
	defer d.Unlock()
	if deltaUpdate == nil {
		return d, nil
	}

	// Parse the update path
	deltaUpdatePath := strings.Split(
		strings.TrimPrefix(deltaUpdate.Path, "/"),
		"/",
	)

	// Apply the delta update based on the path
	switch len(deltaUpdatePath) {
	case 1:
		switch deltaUpdatePath[0] {
		case "":
			return d.applyFullReplacement(deltaUpdate)
		case "relationships":
			if err := d.applyFullRelationshipsReplacement(deltaUpdate); err != nil {
				return nil, err
			}
			return d, nil
		case "resource_types":
			if err := d.applyFullResourceTypesReplacement(deltaUpdate); err != nil {
				return nil, err
			}
			return d, nil
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw TopToBottom", deltaUpdate.Path)
			return d, nil
		}
	case 2:
		switch deltaUpdatePath[0] {
		case "relationships":
			if err := d.applyRelationshipReplacement(deltaUpdate, deltaUpdatePath[1]); err != nil {
				return nil, err
			}
			return d, nil
		case "resource_types":
			if err := d.applyResourceTypeReplacement(deltaUpdate, deltaUpdatePath[1]); err != nil {
				return nil, err
			}
			return d, nil
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw TopToBottom", deltaUpdate.Path)
			return d, nil
		}
	default:
		zap.S().Debugf("ignoring delta update for path: %s for raw TopToBottom", deltaUpdate.Path)
		return d, nil
	}
}
