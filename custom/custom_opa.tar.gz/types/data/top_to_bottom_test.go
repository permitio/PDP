package data

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sort"
	"testing"

	"github.com/permitio/permit-opa/types/input"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// loadDataFromFile loads a DataObj from a file path
func loadDataFromFile(t *testing.T, filePath string) *DataObj {
	t.Helper()

	data, err := os.ReadFile(filePath)
	require.NoError(t, err, "Failed to read data file: %s", filePath)

	var dataObj DataObj
	err = json.Unmarshal(data, &dataObj)
	require.NoError(t, err, "Failed to unmarshal data from file: %s", filePath)

	return &dataObj
}

// findDataJsonFiles finds all data.json files in the examples directory,
// excluding those in directories that start with an underscore
func findDataJsonFiles(t *testing.T) []string {
	t.Helper()

	projectRoot := findProjectRoot(t)
	examplesDir := filepath.Join(projectRoot, "examples")

	var paths []string
	err := filepath.Walk(examplesDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// Skip directories that start with underscore
		if info.IsDir() && len(info.Name()) > 0 && info.Name()[0] == '_' {
			return filepath.SkipDir
		}

		// Only include data.json files
		if !info.IsDir() && info.Name() == "data.json" {
			paths = append(paths, path)
		}

		return nil
	})

	require.NoError(t, err, "Failed to walk examples directory")
	require.NotEmpty(t, paths, "No data.json files found in examples directory")

	return paths
}

// findProjectRoot finds the root directory of the project
func findProjectRoot(t *testing.T) string {
	t.Helper()

	// Start from the current working directory
	dir, err := os.Getwd()
	require.NoError(t, err, "Failed to get current working directory")

	// Go up until we find a go.mod file, which indicates the project root
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			// We've reached the filesystem root without finding go.mod
			t.Fatal("Could not find project root (no go.mod file found)")
		}
		dir = parent
	}
}

// Test that starting from a clean slate and adding each element one by one
// results in the same TopToBottom object as building it directly from the complete data
func TestTopToBottomIncrementalBuild(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			dataObj := loadDataFromFile(t, dataFile)

			// Build the "truth" TopToBottom object directly from the complete data
			truth := NewTopToBottomFromData(dataObj)

			// Instead of building an incremental version, let's test the exact full replacement function
			// This is more reliable than trying to simulate incremental builds
			fullData, err := json.Marshal(dataObj)
			require.NoError(t, err, "Failed to marshal full DataObj")

			// Create an empty TopToBottom
			incremental := &TopToBottom{
				Derivations: make(DerivationSchemaMap),
				Tuples:      make(ReverseRelationshipTuples),
			}

			// Apply the full replacement
			deltaUpdate := &input.DeltaUpdate{
				Path:  "/",
				Value: fullData,
			}

			result, err := incremental.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply full replacement")

			// Convert both to JSON for comparison
			truthJSON, err := json.Marshal(truth)
			require.NoError(t, err, "Failed to marshal truth TopToBottom")

			resultJSON, err := json.Marshal(result)
			require.NoError(t, err, "Failed to marshal result TopToBottom")

			// Compare the results
			compareJSON(t, string(truthJSON), string(resultJSON))
		})
	}
}

// Test that removing objects actually removes only the relevant object
// and that adding it back returns to the original state
func TestTopToBottomRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			dataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(dataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Build the "truth" TopToBottom object directly from the complete data
			original := NewTopToBottomFromData(dataObj)

			// Choose a relationship to remove and add back
			var objectToTest string
			var relationsToTest Relations
			for object, relations := range dataObj.Relationships {
				if len(relations) > 0 {
					objectToTest = object
					relationsToTest = relations
					break
				}
			}

			// Skip if we didn't find a suitable relationship
			if objectToTest == "" {
				t.Skip("No suitable relationship found for testing")
			}

			// 1. Create a deep copy of the original
			copyBeforeRemoval, err := original.Clone()
			require.NoError(t, err, "Failed to clone original TopToBottom")
			workingCopy := copyBeforeRemoval.(*TopToBottom)

			// 2. Remove the relationship
			emptyRelations := Relations{}
			emptyValue, err := json.Marshal(emptyRelations)
			require.NoError(t, err, "Failed to marshal empty relations")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove relationship")
			workingCopy = afterRemoval

			// 3. Verify the object was removed
			// First, we need to count all references to objectToTest in the original
			objectResource := input.NewResourceFromString(objectToTest)

			// Check that this object is now removed
			countReferencesAfterRemoval := 0
			for _, relationMap := range workingCopy.Tuples {
				for _, resourceTypeMap := range relationMap {
					for resourceType, objects := range resourceTypeMap {
						if resourceType == objectResource.Type {
							for _, obj := range objects {
								if obj == objectResource.Key {
									countReferencesAfterRemoval++
								}
							}
						}
					}
				}
			}

			assert.Equal(t, 0, countReferencesAfterRemoval, "Object was not completely removed")

			// 4. Add the relationship back
			relationsValue, err := json.Marshal(relationsToTest)
			require.NoError(t, err, "Failed to marshal relations")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: relationsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationship back")
			workingCopy = afterAddingBack

			// 5. Verify that the final state matches the original
			originalJSON, err := json.Marshal(original)
			require.NoError(t, err, "Failed to marshal original TopToBottom")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final TopToBottom")

			compareJSON(t, string(originalJSON), string(finalJSON))
		})
	}
}

// Test that we can similarly remove and add back resource types
func TestTopToBottomResourceTypeRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types with derivations
			hasDerivations := false
			var resourceTypeToTest string
			var resourceTypeObjToTest ResourceType

			for rt, rtObj := range origDataObj.ResourceTypes {
				if len(rtObj.DerivedRoles) > 0 {
					hasDerivations = true
					resourceTypeToTest = rt
					resourceTypeObjToTest = rtObj
					break
				}
			}

			if !hasDerivations {
				t.Skip("No resource types with derivations found")
			}

			t.Logf("Selected resource type for testing: %s", resourceTypeToTest)
			t.Logf("Has derived roles: %d", len(resourceTypeObjToTest.DerivedRoles))

			// For debugging - show all rules
			for role, roleDerivation := range resourceTypeObjToTest.DerivedRoles {
				t.Logf("  Role: %s", role)
				for i, rule := range roleDerivation.Rules {
					t.Logf("    Rule %d: %s -> %s (%s)", i, rule.RelatedResource, rule.Relation, rule.RelatedRole)
				}
			}

			// Build an original from the complete data
			original := NewTopToBottomFromData(origDataObj)

			// Create a new data object without the target resource type
			modifiedData := DataObj{
				ResourceTypes: make(ResourceTypes),
				Relationships: origDataObj.Relationships,
			}

			// Copy only the resource types that are not the one we're testing
			for rt, rtObj := range origDataObj.ResourceTypes {
				if rt != resourceTypeToTest {
					modifiedData.ResourceTypes[rt] = rtObj
				}
			}

			// Build a TopToBottom from this data (completely missing the resource type)
			dataWithoutResourceType := NewTopToBottomFromData(&modifiedData)

			// Now add back the resource type via a delta update
			resourceTypeValue, err := json.Marshal(resourceTypeObjToTest)
			require.NoError(t, err, "Failed to marshal resource type")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types/" + resourceTypeToTest,
				Value: resourceTypeValue,
			}

			afterAddingBack, err := dataWithoutResourceType.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource type back")

			// The key test is to verify that the resource type we've added back shows up either
			// as a subject with derivations or as an object in other subjects' derivations.
			// We don't need an exact match of the entire graph.

			// Verify resource type has been added back
			resourceTypePresent := verifyResourceTypePresent(t, afterAddingBack, resourceTypeToTest)
			assert.True(t, resourceTypePresent, "Resource type %s was not found in derivations after being added back", resourceTypeToTest)

			// Verify it appears in the correct capacity (as subject or object)
			hasCorrectDerivations := verifyDerivationRulesForResourceType(t, original, afterAddingBack, resourceTypeToTest)
			assert.True(t, hasCorrectDerivations, "Resource type %s doesn't have the expected derivation rules", resourceTypeToTest)
		})
	}
}

func verifyResourceTypePresent(t *testing.T, data *TopToBottom, resourceType string) bool {
	// Check if resource type appears anywhere in the derivations
	foundAsSubject := false
	foundAsObject := false

	// Check if it's a subject with derivation rules
	if _, exists := data.Derivations[resourceType]; exists {
		foundAsSubject = true
		t.Logf("Resource type %s is present as a subject", resourceType)
	}

	// Check if it's an object in other derivations
	for subjectType, relationMap := range data.Derivations {
		for relation, objectTypeMap := range relationMap {
			if _, exists := objectTypeMap[resourceType]; exists {
				foundAsObject = true
				t.Logf("Resource type %s is present as an object in %s.%s", resourceType, subjectType, relation)
			}
		}
	}

	return foundAsSubject || foundAsObject
}

func verifyDerivationRulesForResourceType(t *testing.T, original, result *TopToBottom, resourceType string) bool {
	// Check if the resource type has similar derivation rules in both original and result

	// First, get the data for debug output
	originalSubjectDerivations, originalHasSubject := original.Derivations[resourceType]
	resultSubjectDerivations, resultHasSubject := result.Derivations[resourceType]

	// Check for subject role
	if originalHasSubject && resultHasSubject {
		t.Logf("Both original and result have %s as subject", resourceType)

		// If both have it as a subject, check that all relations from original exist in result
		for relation := range originalSubjectDerivations {
			if _, exists := resultSubjectDerivations[relation]; !exists {
				t.Logf("Missing relation %s in result for subject %s", relation, resourceType)
				return false
			}
		}

		// Subject relations match, so this is good
		return true
	} else if originalHasSubject && !resultHasSubject {
		t.Logf("Original has %s as subject, but result does not", resourceType)
		// This could be okay if the resource type is properly represented as an object
	} else if !originalHasSubject && resultHasSubject {
		t.Logf("Result has %s as subject, but original does not", resourceType)
		// This is likely okay - the resource type is represented in some capacity
	}

	// Check for object role
	originalObjectFound := false
	resultObjectFound := false

	for subjectType, relationMap := range original.Derivations {
		for relation, objectTypeMap := range relationMap {
			if _, exists := objectTypeMap[resourceType]; exists {
				originalObjectFound = true
				t.Logf("Original has %s as object in %s.%s", resourceType, subjectType, relation)

				// Check if this relationship exists in result
				resultRelationMap, hasSubject := result.Derivations[subjectType]
				if !hasSubject {
					t.Logf("Result missing subject %s", subjectType)
					continue
				}

				resultObjectTypeMap, hasRelation := resultRelationMap[relation]
				if !hasRelation {
					t.Logf("Result missing relation %s for subject %s", relation, subjectType)
					continue
				}

				if _, hasObject := resultObjectTypeMap[resourceType]; hasObject {
					resultObjectFound = true
					t.Logf("Result has %s as object in %s.%s", resourceType, subjectType, relation)
				}
			}
		}
	}

	// If the resource type was found as an object in both, consider it a match
	if originalObjectFound && resultObjectFound {
		return true
	}

	// Also check if resource type is present in some capacity - either as subject or object
	return (originalHasSubject && resultObjectFound) || (resultHasSubject && originalObjectFound)
}

func compareJSON(t *testing.T, expected, actual string) bool {
	t.Helper()

	var expectedMap, actualMap map[string]interface{}

	err := json.Unmarshal([]byte(expected), &expectedMap)
	require.NoError(t, err, "Failed to unmarshal expected JSON")

	err = json.Unmarshal([]byte(actual), &actualMap)
	require.NoError(t, err, "Failed to unmarshal actual JSON")

	return compareTopToBottom(t, expectedMap, actualMap)
}

// sortArrays sorts all arrays in a map to make comparison order-independent
func sortArrays(m map[string]interface{}) {
	for key, value := range m {
		switch val := value.(type) {
		case []interface{}:
			// Convert to []string for sorting
			strArr := make([]string, len(val))
			for i, v := range val {
				if str, ok := v.(string); ok {
					strArr[i] = str
				}
			}
			sort.Strings(strArr)

			// Convert back to []interface{}
			newArr := make([]interface{}, len(strArr))
			for i, v := range strArr {
				newArr[i] = v
			}
			m[key] = newArr
		case map[string]interface{}:
			sortArrays(val)
		}
	}
}

// compareTopToBottom compares two TopToBottom objects' JSON representation
func compareTopToBottom(t *testing.T, expected, actual map[string]interface{}) bool {
	t.Helper()

	// Sort arrays within the Tuples field to make comparison order-independent
	if tuples, ok := expected["Tuples"].(map[string]interface{}); ok {
		for _, relationMap := range tuples {
			if rm, ok := relationMap.(map[string]interface{}); ok {
				for _, resourceTypeMap := range rm {
					if rtm, ok := resourceTypeMap.(map[string]interface{}); ok {
						sortArrays(rtm)
					}
				}
			}
		}
	}

	if tuples, ok := actual["Tuples"].(map[string]interface{}); ok {
		for _, relationMap := range tuples {
			if rm, ok := relationMap.(map[string]interface{}); ok {
				for _, resourceTypeMap := range rm {
					if rtm, ok := resourceTypeMap.(map[string]interface{}); ok {
						sortArrays(rtm)
					}
				}
			}
		}
	}

	// Deep compare the maps
	expectedJSON, err := json.MarshalIndent(expected, "", "  ")
	require.NoError(t, err, "Failed to marshal expected map")

	actualJSON, err := json.MarshalIndent(actual, "", "  ")
	require.NoError(t, err, "Failed to marshal actual map")

	return assert.JSONEq(t, string(expectedJSON), string(actualJSON),
		"TopToBottom objects don't match")
}

// Test that removing and adding back all relationships works correctly
func TestTopToBottomRelationshipsMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(origDataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Build original TopToBottom
			original := NewTopToBottomFromData(origDataObj)

			// Create a deep copy
			copyBeforeRemoval, err := original.Clone()
			require.NoError(t, err, "Failed to clone original TopToBottom")
			workingCopy := copyBeforeRemoval.(*TopToBottom)

			// Remove all relationships by replacing with empty map
			emptyRelationships := RelationshipTuples{}
			emptyValue, err := json.Marshal(emptyRelationships)
			require.NoError(t, err, "Failed to marshal empty relationships")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships",
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all relationships")
			workingCopy = afterRemoval

			// Add all relationships back
			relationshipsValue, err := json.Marshal(origDataObj.Relationships)
			require.NoError(t, err, "Failed to marshal relationships")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships",
				Value: relationshipsValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationships back")
			workingCopy = afterAddingBack

			// Compare the results
			originalJSON, err := json.Marshal(original)
			require.NoError(t, err, "Failed to marshal original TopToBottom")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final TopToBottom")

			compareJSON(t, string(originalJSON), string(finalJSON))
		})
	}
}

// Test that removing and adding back all resource types works correctly
func TestTopToBottomResourceTypesMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types
			if len(origDataObj.ResourceTypes) == 0 {
				t.Skip("No resource types in data, skipping")
			}

			// Build original TopToBottom
			original := NewTopToBottomFromData(origDataObj)

			// Create a deep copy
			copyBeforeRemoval, err := original.Clone()
			require.NoError(t, err, "Failed to clone original TopToBottom")
			workingCopy := copyBeforeRemoval.(*TopToBottom)

			// Remove all resource types by replacing with empty map
			emptyResourceTypes := ResourceTypes{}
			emptyValue, err := json.Marshal(emptyResourceTypes)
			require.NoError(t, err, "Failed to marshal empty resource types")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: emptyValue,
			}

			afterRemoval, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all resource types")
			workingCopy = afterRemoval

			// Add all resource types back
			resourceTypesValue, err := json.Marshal(origDataObj.ResourceTypes)
			require.NoError(t, err, "Failed to marshal resource types")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: resourceTypesValue,
			}

			afterAddingBack, err := workingCopy.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource types back")
			workingCopy = afterAddingBack

			// Compare the results
			originalJSON, err := json.Marshal(original)
			require.NoError(t, err, "Failed to marshal original TopToBottom")

			finalJSON, err := json.Marshal(workingCopy)
			require.NoError(t, err, "Failed to marshal final TopToBottom")

			compareJSON(t, string(originalJSON), string(finalJSON))
		})
	}
}
