package data

import (
	"fmt"
	"github.com/samber/lo"
	"strings"
)

type ResourceRole struct {
	ResourceType string
	ResourceKey  string
	Role         string
}

func NewResourceRole(resourceType, resourceKey, role string) ResourceRole {
	return ResourceRole{
		ResourceType: resourceType,
		ResourceKey:  resourceKey,
		Role:         role,
	}
}

func NewResourceRoleFromString(resourceRoleString string) ResourceRole {
	resourceString, roleString, _ := strings.Cut(resourceRoleString, "#")
	resourceType, resourceKey, _ := strings.Cut(resourceString, ":")
	return NewResourceRole(resourceType, resourceKey, roleString)
}

func (r ResourceRole) String() string {
	return fmt.Sprintf("%s:%s#%s", r.ResourceType, r.ResourceKey, r.Role)
}

func (r ResourceRole) ResourceString() string {
	return fmt.Sprintf("%s:%s", r.ResourceType, r.ResourceKey)
}

func FormatResourceRoles(roles []string, resourceType, resourceInstance string) []string {
	return lo.Map(roles, func(role string, _ int) string {
		return NewResourceRole(resourceType, resourceInstance, role).String()
	})
}
