package main

import (
	_ "embed"
	"fmt"
	"github.com/google/licenseclassifier"
	"github.com/google/licenseclassifier/v2/assets"
	"github.com/open-policy-agent/opa/cmd"
	"github.com/open-policy-agent/opa/version"
	"github.com/spf13/cobra"
	"io"
	"os"
)

var (
	licenseShort string
	//go:embed LICENSE.md
	licenseLong string
)

func setUnlicensed() {
	licenseShort = licenseclassifier.Unlicense
	licenseLong = licenseclassifier.Unlicense
}

func initLicense() {
	if licenseLong == "" {
		setUnlicensed()
		return
	}
	classifier, err := assets.DefaultClassifier()
	if err != nil {
		setUnlicensed()
		return
	}
	result := classifier.Match([]byte(licenseLong))
	if len(result.Matches) == 0 {
		setUnlicensed()
	} else {
		licenseShort = result.Matches[0].Name
	}
}

func init() {
	initLicense()
	var licenseCommand = &cobra.Command{
		Use:   "license",
		Short: "Print the version & license of this built OPA",
		Long:  "Show license and information for this built OPA.",
		Run: func(cmd *cobra.Command, args []string) {
			generateCmdOutput(os.Stdout)
		},
	}

	cmd.RootCommand.AddCommand(licenseCommand)
}

func generateCmdOutput(out io.Writer) {
	fmt.Fprintln(out, "Version: "+version.Version)
	fmt.Fprintln(out, "Build Commit: "+version.Vcs)
	fmt.Fprintln(out, "Build Timestamp: "+version.Timestamp)
	fmt.Fprintln(out, "Build Hostname: "+version.Hostname)
	fmt.Fprintln(out, "Go Version: "+version.GoVersion)
	fmt.Fprintln(out, "Platform: "+version.Platform)

	var wasmAvailable string

	if version.WasmRuntimeAvailable() {
		wasmAvailable = "available"
	} else {
		wasmAvailable = "unavailable"
	}

	fmt.Fprintln(out, "WebAssembly: "+wasmAvailable)

	//
	fmt.Fprintf(out, "License: %s\n%s\n", licenseShort, licenseLong)
}
