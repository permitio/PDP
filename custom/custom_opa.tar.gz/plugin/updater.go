package plugin

import (
	"context"
	"encoding/json"
	"errors"
	"log"
	"strings"
	"time"

	"github.com/open-policy-agent/opa/plugins"
	"github.com/open-policy-agent/opa/storage"
	"github.com/permitio/permit-opa/types/input"
	"github.com/permitio/permit-opa/types/ocache"
	"go.uber.org/zap"
)

const (
	PluginName = "permit_graph"
)

const (
	defaultMaxRetries = 1
	defaultBackoff    = 10 * time.Millisecond
	defaultMaxBackoff = 1 * time.Second
)

// Duration embeds time.Duration and makes it more JSON-friendly.
// Instead of marshaling and unmarshaling as int64 it uses strings, like "5m" or "0.5s".
type Duration time.Duration

func (d Duration) MarshalJSON() ([]byte, error) {
	return json.Marshal(d.String())
}

func (d *Duration) UnmarshalJSON(data []byte) error {
	var str string
	if err := json.Unmarshal(data, &str); err != nil {
		return err
	}
	val, err := time.ParseDuration(str)
	*d = Duration(val)
	return err
}

func (d Duration) String() string {
	return time.Duration(d).String()
}

type pluginConfig struct {
	Backoff      Duration `json:"backoff"`
	MaxRetries   int      `json:"max_retries,omitempty"`
	MaxBackoff   Duration `json:"max_backoff"`
	cacheManager *ocache.CacheManager
}

type UpdaterFactory struct {
	cacheManager *ocache.CacheManager
}

func NewUpdaterFactory(cacheManager *ocache.CacheManager) *UpdaterFactory {
	return &UpdaterFactory{
		cacheManager: cacheManager,
	}
}

func (u *UpdaterFactory) Validate(manager *plugins.Manager, config []byte) (any, error) {
	if u.cacheManager == nil {
		return nil, errors.New("cache manager is not set")
	}
	if u.cacheManager.InterQueryBuiltinCache == nil {
		return nil, errors.New("inter query builtin cache is not set")
	}
	pluginConfig := pluginConfig{
		cacheManager: u.cacheManager,
		MaxRetries:   defaultMaxRetries,
		Backoff:      Duration(defaultBackoff),
		MaxBackoff:   Duration(defaultMaxBackoff),
	}
	if err := json.Unmarshal(config, &pluginConfig); err != nil {
		return nil, errors.New("failed to unmarshal plugin config")
	}
	return &pluginConfig, nil
}

func (u *UpdaterFactory) New(manager *plugins.Manager, config any) plugins.Plugin {
	pluginConfig, _ := config.(*pluginConfig)
	return &Updater{
		cacheManager: pluginConfig.cacheManager,
		manager:      manager,
		backoff:      time.Duration(pluginConfig.Backoff),
		maxRetries:   pluginConfig.MaxRetries,
		maxBackoff:   time.Duration(pluginConfig.MaxBackoff),
	}
}

type Updater struct {
	cacheManager *ocache.CacheManager
	manager      *plugins.Manager
	handle       storage.TriggerHandle
	backoff      time.Duration
	maxRetries   int
	maxBackoff   time.Duration
}

func (u *Updater) Start(ctx context.Context) error {
	if u.cacheManager == nil {
		zap.S().Error("cache manager is not set")
		return errors.New("cache manager is not set")
	}
	txn, err := u.manager.Store.NewTransaction(ctx, storage.WriteParams)
	if err != nil {
		zap.S().Errorf("Error creating transaction: %v", err)
		return err
	}
	u.handle, err = u.manager.Store.Register(ctx, txn, storage.TriggerConfig{
		OnCommit: u.onCommit,
	})
	if err != nil {
		zap.S().Errorf("Error registering trigger: %v", err)
		return err
	}
	err = u.manager.Store.Commit(ctx, txn)
	if err != nil {
		zap.S().Errorf("Error committing transaction: %v", err)
		return err
	}
	zap.S().Info("Permit Graph plugin started")
	return nil

}

func (u *Updater) onCommit(ctx context.Context, txn storage.Transaction, event storage.TriggerEvent) {
	for _, dataEvent := range event.Data {
		path := strings.Join(dataEvent.Path, "/")
		zap.S().Debugf(
			"Recieved data event for path %s", path,
		)
		var jsonData json.RawMessage
		if dataEvent.Removed {
			jsonData = json.RawMessage("{}")
		} else {
			var err error
			jsonData, err = json.Marshal(dataEvent.Data)
			if err != nil {
				zap.S().Errorf("Error marshalling data for path %s: %v", strings.Join(dataEvent.Path, "/"), err)
				panic(err)
			}
		}
		_, err := u.cacheManager.UpdateDelta(ctx, &input.DeltaUpdate{
			Path:  path,
			Value: jsonData,
		}, u.maxRetries, u.backoff, u.maxBackoff)
		if err != nil {
			zap.S().Errorf("Error updating delta for path %s due to %v, panicing to prevnet invalid state", path, err)
			panic(err)
		}
	}
}

func (u *Updater) Stop(ctx context.Context) {
	txn, err := u.manager.Store.NewTransaction(ctx, storage.WriteParams)
	if err != nil {
		log.Println("error creating transaction", err)
	}
	if u.handle != nil {
		u.handle.Unregister(ctx, txn)
	}
	if err = u.manager.Store.Commit(ctx, txn); err != nil {
		zap.S().Errorf("Error committing transaction: %v", err)
	}
}

func (u *Updater) Reconfigure(ctx context.Context, config any) {
	cacheManager, _ := config.(*ocache.CacheManager)
	u.cacheManager = cacheManager
}
