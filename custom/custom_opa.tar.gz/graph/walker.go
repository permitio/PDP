package graph

import (
	"context"
	"fmt"
	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/debug"
	"github.com/samber/lo"
)
import "github.com/permitio/permit-opa/types/input"

type Walker struct {
	topToBottom bool
	tuples      data.ReverseRelationshipTuples
	derivations data.DerivationSchemaMap
	dataObj     *data.DataObj
	inputObj    *input.InputObj
	debugger    []*debug.GrantingBlock
	debuggerMap map[string]*debug.GrantingBlock
}

func NewWalker(dataObj *data.DataObj, inputObj *input.InputObj) *Walker {
	return &Walker{
		dataObj:  dataObj,
		inputObj: inputObj,
	}
}

func NewTopToBottomWalker(dataObj *data.DataObj, inputObj *input.InputObj, tuples data.ReverseRelationshipTuples, derivations data.DerivationSchemaMap) *Walker {
	return &Walker{
		topToBottom: true,
		tuples:      tuples,
		derivations: derivations,
		dataObj:     dataObj,
		inputObj:    inputObj,
	}
}

func (w *Walker) importDebugger(cw *Walker) {
	w.debugger = cw.debugger
	w.debuggerMap = cw.debuggerMap
}

func (w *Walker) newTopToBottomChildWalker(resource input.InputResource) *Walker {
	return &Walker{
		topToBottom: true,
		tuples:      w.tuples,
		derivations: w.derivations,
		dataObj:     w.dataObj,
		inputObj: &input.InputObj{
			User:     w.inputObj.User,
			Resource: resource,
		},
	}
}

func (w *Walker) newChildWalker(resource input.InputResource) *Walker {
	return &Walker{
		tuples:      w.tuples,
		derivations: w.derivations,
		dataObj:     w.dataObj,
		inputObj: &input.InputObj{
			User:     w.inputObj.User,
			Resource: resource,
		},
	}
}

func (w *Walker) initDebugger(directRoles []string) {
	w.debugger = make([]*debug.GrantingBlock, len(directRoles))
	w.debuggerMap = make(map[string]*debug.GrantingBlock)
	for i, role := range directRoles {
		grantingBlock := debug.NewGrantingBlock(
			debug.NewRole(w.inputObj.Resource.Type, role),
			debug.NewResource(w.inputObj.Resource.Key, w.inputObj.Resource.Type),
		).WithSources([]*debug.GrantingBlock{debug.NewRoleAssignmentGrantingBlock()})
		w.debugger[i] = grantingBlock
		w.debuggerMap[role] = grantingBlock
	}
}

func (w *Walker) MergeChildDebugger(
	cw *Walker,
	grantedRole, grantingRole string,
	relationship *debug.RelationshipTuple,
) {
	if len(cw.debugger) == 0 {
		return
	}
	grantingBlock := cw.debuggerMap[grantingRole].WithRelationship(relationship).WithType(debug.RoleDerivation)
	w.debugger = append(w.debugger, grantingBlock)
	if roleGrantingBlock, exists := w.debuggerMap[grantedRole]; exists {
		roleGrantingBlock.Sources = append(roleGrantingBlock.Sources, grantingBlock)
	} else {
		w.debuggerMap[grantedRole] = debug.NewGrantingBlock(
			debug.NewRole(w.inputObj.Resource.Type, grantedRole),
			debug.NewResource(w.inputObj.Resource.Key, w.inputObj.Resource.Type),
		).WithSources([]*debug.GrantingBlock{grantingBlock})
	}
}

func (w *Walker) getRolesBottomToTop(ctx context.Context) []string {
	ctx, cachedWalkers := getCacheFromContext(ctx)
	cachedResult, isVisitedResource := cachedWalkers.Get(w.inputObj.Resource.String())
	if isVisitedResource && cachedResult != nil {
		w.importDebugger(cachedResult.walker)
		return cachedResult.roles
	}
	directRoles := w.GetDirectRoles()
	w.initDebugger(directRoles)
	var totalRoles []string
	if isVisitedResource {
		// to prevent infinite loop if we've already tried to get the roles for this resource in the execution of the recursion
		// return only the direct roles
		totalRoles = directRoles
	} else {
		cachedWalkers.SetIfAbsent(w.inputObj.Resource.String(), nil)
		derivedRoles := w.GetDerivedRoles(ctx)
		totalRoles = append(directRoles, derivedRoles...)
	}
	cachedWalkers.Set(w.inputObj.Resource.String(), &cachedWalker{
		roles:  totalRoles,
		walker: w,
	})
	return totalRoles
}

func (w *Walker) getRolesTopToBottom(ctx context.Context, includeDirectRoles bool) []string {
	ctx, cachedWalkers := getTopToBottomCacheFromContext(ctx)
	cachedResult, isVisitedResource := cachedWalkers.Get(w.inputObj.Resource.String())
	if isVisitedResource && cachedResult != nil {
		w.importDebugger(cachedResult.walker)
		return cachedResult.roles
	}
	var directRoles []string
	if includeDirectRoles {
		directRoles = data.FormatResourceRoles(w.GetDirectRoles(), w.inputObj.Resource.Type, w.inputObj.Resource.Key)
	} else {
		directRoles = []string{}
	}
	w.initDebugger(directRoles)
	var totalRoles []string
	if isVisitedResource {
		totalRoles = directRoles
	} else {
		cachedWalkers.SetIfAbsent(w.inputObj.Resource.String(), nil)
		derivingRoles := w.GetDerivingRoles(ctx)
		totalRoles = append(directRoles, derivingRoles...)
	}
	cachedWalkers.Set(w.inputObj.Resource.String(), &cachedWalker{
		roles:  totalRoles,
		walker: w,
	})
	return totalRoles
}

func (w *Walker) GetRoles(ctx context.Context) []string {
	w.dataObj.RLock()
	defer w.dataObj.RUnlock()
	if !w.topToBottom {
		return w.getRolesBottomToTop(ctx)
	} else {
		return w.getRolesTopToBottom(ctx, true)
	}
}

func (w *Walker) GetDirectRoles() []string {
	assignments, exists := w.dataObj.RoleAssignments[w.inputObj.User.Full()]
	if !exists {
		return []string{}
	}
	roles, exists := assignments[w.inputObj.Resource.String()]
	if !exists {
		return []string{}
	}
	return roles
}

func (w *Walker) GetDerivingRoles(ctx context.Context) []string {
	var roles []string
	currentResourceRoles := w.getRolesBottomToTop(ctx)
	resourceRelationships, exists := w.tuples[w.inputObj.Resource.String()]
	if !exists {
		// return because the resource does not have any relationships
		// so it can't derive any roles
		return []string{}
	}
	for relation, relationships := range resourceRelationships {
		// check if the subject can derive to resources via this relation
		if !w.derivations.CanDeriveViaRelation(w.inputObj.Resource.Type, relation) {
			continue
		}
		for resource, instances := range relationships {
			// check if the subject can derive to this resource via this relation
			if !w.derivations.CanDeriveToResourceViaRelation(w.inputObj.Resource.Type, relation, resource) {
				continue
			}
			for _, instance := range instances {
				derivingResource := input.NewResource(instance, resource)

				childWalker := w.newTopToBottomChildWalker(derivingResource)
				derivingResourceRoles := childWalker.getRolesBottomToTop(ctx)
				if len(derivingResourceRoles) != 0 {
					formattedDerivingResourceRoles := data.FormatResourceRoles(derivingResourceRoles, resource, instance)
					roles = append(roles, formattedDerivingResourceRoles...)
					derivingResourceDerivingRoles := childWalker.getRolesTopToBottom(
						NewChildContextWithInjectedCache(ctx, w.inputObj.Resource.String(), currentResourceRoles, w),
						false,
					)
					roles = append(roles, derivingResourceDerivingRoles...)
				}
			}
		}
	}
	return roles
}

func (w *Walker) GetDerivedRoles(ctx context.Context) []string {
	var roles []string
	resourceRelationships, exists := w.dataObj.Relationships[w.inputObj.Resource.String()]
	if !exists {
		// return because the resource does not have any relationships
		// so it can't derive any roles
		return []string{}
	}
	for role, roleDerivation := range w.dataObj.ResourceTypes[w.inputObj.Resource.Type].DerivedRoles {
		if newDerivationChecker(roleDerivation, role).IsDeriving(ctx, w, resourceRelationships) {
			roles = append(roles, role)
		}

	}
	return roles
}

func (w *Walker) GetDebugger() []*debug.GrantingBlock {
	return w.debugger
}

func (w *Walker) GetDebuggerMap() map[string]*debug.GrantingBlock {
	for _, grantingBlock := range w.debuggerMap {
		grantingBlock.Reason = grantingBlock.BuildReasonMessage()
	}
	return w.debuggerMap
}

func (w *Walker) GetRootGrants(role string) []debug.RootGrantingBlock {
	grantingBlock, exists := w.debuggerMap[role]
	if !exists {
		return []debug.RootGrantingBlock{}
	}
	return lo.UniqBy(grantingBlock.GetRootGrantingBlocks(), func(grant debug.RootGrantingBlock) string {
		return fmt.Sprintf("%s#%s", grant.Resource.String(), grant.Role.Role)
	})
}
