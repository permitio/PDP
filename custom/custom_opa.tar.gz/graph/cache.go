package graph

import (
	"context"
	cmap "github.com/orcaman/concurrent-map/v2"
)

type contextKey int

const (
	cacheKey contextKey = iota
	topToBottomCacheKey
)

type cachedWalker struct {
	roles  []string
	walker *Walker
}

func newCache() cmap.ConcurrentMap[string, *cachedWalker] {
	return cmap.New[*cachedWalker]()
}
func getTopToBottomCacheFromContext(ctx context.Context) (context.Context, cmap.ConcurrentMap[string, *cachedWalker]) {
	cacheValue, found := ctx.Value(topToBottomCacheKey).(cmap.ConcurrentMap[string, *cachedWalker])
	if !found {
		cacheValue := newCache()
		return context.WithValue(ctx, topToBottomCacheKey, cacheValue), cacheValue
	}
	return ctx, cacheValue
}

func getCacheFromContext(ctx context.Context) (context.Context, cmap.ConcurrentMap[string, *cachedWalker]) {
	cacheValue, found := ctx.Value(cacheKey).(cmap.ConcurrentMap[string, *cachedWalker])
	if !found {
		cacheValue := newCache()
		return context.WithValue(ctx, cacheKey, cacheValue), cacheValue
	}
	return ctx, cacheValue
}

func NewChildContextWithInjectedCache(ctx context.Context, resource string, roles []string, walker *Walker) context.Context {
	ctx, parentCache := getCacheFromContext(ctx)

	resourceCachedWalker, found := parentCache.Get(resource)
	if !found || resourceCachedWalker == nil {
		resourceCachedWalker = &cachedWalker{
			roles:  roles,
			walker: walker,
		}
	}
	resourceCachedWalker.roles = append(resourceCachedWalker.roles, roles...)
	return ctx
}

func NewChildContext(ctx context.Context) context.Context {
	childContext := context.WithValue(ctx, topToBottomCacheKey, newCache())
	childContext = context.WithValue(childContext, cacheKey, newCache())
	return childContext
}
