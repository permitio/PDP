package new_walker

import (
	"context"
	"encoding/json"
	"github.com/permitio/permit-opa/graph/graphy"
	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/input"
	"github.com/stretchr/testify/assert"
	"testing"
)

const (
	ExampleData = `{
  "condition_set_rules": {},
  "condition_sets": {
    "resourceset__5f_5fautogen_5forganization": {
      "key": "__autogen_organization",
      "type": "resourceset"
    },
    "resourceset__5f_5fautogen_5frepo": {
      "key": "__autogen_repo",
      "type": "resourceset"
    }
  },
  "mapping_rules": {
    "all": []
  },
  "relationships": {
    "repo:permit-backend": {
      "relation:parent": {
        "organization": [
          "permitio"
        ]
      }
    }
  },
  "resource_instances": {
    "organization:permitio": {
      "attributes": {}
    },
    "repo:permit-backend": {
      "attributes": {}
    }
  },
  "resource_types": {
    "__tenant": {
      "actions": [],
      "derived_roles": {}
    },
    "__user": {
      "actions": [],
      "derived_roles": {}
    },
    "organization": {
      "actions": [
        "create",
        "read",
        "update",
        "delete"
      ],
      "derived_roles": {}
    },
    "repo": {
      "actions": [
        "create",
        "read",
        "update",
        "delete"
      ],
      "derived_roles": {
        "maintainer": {
          "rules": [
            {
              "related_resource": "organization",
              "related_role": "admin",
              "relation": "parent",
              "settings": {
                "superseded_by_direct_role": false
              }
            }
          ],
          "settings": {
            "superseded_by_direct_role": false
          }
        }
      }
    }
  },
  "role_assignments": {
    "user:omer@permit.io": {
      "organization:permitio": [
        "admin"
      ]
    },
	"user:dan@permit.io": {
	  "repo:permit-backend": [
		"maintainer"
	  ]
	}
  },
  "role_permissions": {
    "organization": {
      "admin": {
        "grants": {
          "organization": [
            "create",
            "delete"
          ]
        }
      }
    },
    "repo": {
      "maintainer": {
        "grants": {
          "repo": [
            "delete",
            "create",
            "update",
            "read"
          ]
        }
      }
    }
  },
  "roles": {
    "admin": {},
    "maintainer": {}
  },
  "tenants": {
    "default": {
      "attributes": {}
    }
  },
  "users": {
    "omer@permit.io": {
      "attributes": {
        "key": "omer@permit.io"
      },
      "roleAssignments": {}
    }
  }
}`
)

func LoadData(t *testing.T) *data.DataObj {
	var d data.DataObj
	assert.NoError(t, json.Unmarshal([]byte(ExampleData), &d))
	return &d
}

func assertGraphWithClone[T graphy.GraphNodeI](
	t *testing.T, graph *graphy.GraphPointer[T],
	clonedGraph *graphy.GraphPointer[T],
) {
	assert.Greater(t, graph.NodesCount(), 0,
		"Loaded graph does not have any nodes")
	assert.Equal(t, graph.NodesCount(), clonedGraph.NodesCount())
}

func TestGraph_SizeInBytes(t *testing.T) {
	dataObj := LoadData(t)
	graphObj := graphy.NewGraphBuilder().
		FromDataObj(dataObj).
		Build()
	factsGraph := graphObj.GetFactsGraph()
	schemaGraph := graphObj.GetSchemaGraph()
	factsNodesCount := factsGraph.NodesCount()
	assert.Greater(t, factsNodesCount, 0,
		"Loaded graph does not have any facts nodes")
	schemaNodesCount := schemaGraph.NodesCount()
	assert.Greater(t, schemaNodesCount, 0,
		"Loaded graph does not have any schema nodes")

	assert.Equal(t, graphObj.SizeInBytes(), int64(factsNodesCount+schemaNodesCount))
}

func TestGraph_Clone(t *testing.T) {
	dataObj := LoadData(t)
	graph := graphy.NewGraphBuilder().
		FromDataObj(dataObj).
		Build()
	assert.Greater(t, graph.GetFactsGraph().NodesCount(), 0,
		"Loaded graph does not have any nodes")
	clonedGraphI, err := graph.Clone()
	assert.NoError(t, err, "Error trying to clone the graph")
	clonedGraph, ok := clonedGraphI.(*graphy.Graph)
	assert.True(t, ok, "Clone value is not of type *Graph")
	assertGraphWithClone[graphy.GraphNodeI](t, graph.GetFactsGraph(), clonedGraph.GetFactsGraph())
	assertGraphWithClone[graphy.GraphNodeI](t, graph.GetSchemaGraph(), clonedGraph.GetSchemaGraph())
}

func TestLookUpManager_LookUpResource(t *testing.T) {
	dataObj := LoadData(t)
	lookUpManager := NewLookUpManager(dataObj)
	organizationResource := input.InputResource{
		Type: "organization",
		Key:  "permitio",
	}
	possibleAuthorizedUsers := lookUpManager.LookUpResource(context.Background(), &organizationResource)
	assert.Len(t, possibleAuthorizedUsers, 1)
	assignments := possibleAuthorizedUsers["user:omer@permit.io"]
	assert.Len(t, assignments, 1)
	assert.NotNil(t, assignments)
	if assignments != nil {
		assert.Equal(t, "organization#admin", assignments[0].Role)
		assert.Equal(t, "organization:permitio", assignments[0].Resource)
		assert.Equal(t, "user:omer@permit.io", assignments[0].User)
	}

	repoResource := input.InputResource{
		Type: "repo",
		Key:  "permit-backend",
	}
	possibleAuthorizedUsers = lookUpManager.LookUpResource(context.Background(), &repoResource)
	assert.Len(t, possibleAuthorizedUsers, 2)
	userOneAssignments := possibleAuthorizedUsers["user:omer@permit.io"]
	assert.Len(t, userOneAssignments, 1)
	assert.Equal(t, "organization#admin", userOneAssignments[0].Role)
	assert.Equal(t, "organization:permitio", userOneAssignments[0].Resource)
	assert.Equal(t, "user:omer@permit.io", userOneAssignments[0].User)
	userTwoAssignments := possibleAuthorizedUsers["user:dan@permit.io"]
	assert.Len(t, userTwoAssignments, 1)
	assert.Equal(t, "repo#maintainer", userTwoAssignments[0].Role)
	assert.Equal(t, "repo:permit-backend", userTwoAssignments[0].Resource)
	assert.Equal(t, "user:dan@permit.io", userTwoAssignments[0].User)

	usersWithDerivedRoles := lookUpManager.LookUpResourceIncludeDerivedRoles(context.Background(), &repoResource)
	assert.Len(t, usersWithDerivedRoles, 2)
	omerUserAssignments := usersWithDerivedRoles["user:omer@permit.io"]
	assert.Len(t, omerUserAssignments.GetRoles(), 1)
	assert.Equal(t, "maintainer", omerUserAssignments.GetRoles()[0])

	danUserAssignments := usersWithDerivedRoles["user:dan@permit.io"]
	assert.Len(t, danUserAssignments.GetRoles(), 1)
	assert.Equal(t, "maintainer", danUserAssignments.GetRoles()[0])
}
