package new_walker

import (
	"context"
	"os"
	"strconv"
	"strings"
	"sync"

	lru "github.com/hashicorp/golang-lru/v2"
	"github.com/permitio/permit-opa/graph"
	"github.com/permitio/permit-opa/graph/graphy"
	"github.com/permitio/permit-opa/types"
	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/debug"
	"github.com/permitio/permit-opa/types/input"
	"github.com/samber/lo"
	lop "github.com/samber/lo/parallel"
)

var (
	CacheSize = getCacheSize()
)

func getCacheSize() int {
	cacheSizeStr := os.Getenv("PDP_OPA_REBAC_LINKED_USERS_CACHE_SIZE")
	if cacheSizeStr == "" {
		return 0
	}
	cacheSize, err := strconv.Atoi(cacheSizeStr)
	if err != nil {
		return 0
	}
	return cacheSize
}

// LookUpManager is responsible to hold e2e state of the graphs and
// have the ability to walk on the graph using private functions
type LookUpManager struct {
	dataObj     *data.DataObj
	factsGraph  *graphy.GraphPointer[graphy.GraphNodeI]
	schemaGraph *graphy.GraphPointer[graphy.GraphNodeI]
	cache       *lru.Cache[string, map[string]types.LinkedUsersResultTuple]
	graphLock   *sync.RWMutex
}

// NewLookUpManagerFromGraph initializes a LookUpManager from a raw data.DataObj and a Graph pointers
func NewLookUpManagerFromGraph(dataObj *data.DataObj, graph *graphy.Graph) *LookUpManager {
	return &LookUpManager{
		dataObj:     dataObj,
		factsGraph:  graph.GetFactsGraph(),
		schemaGraph: graph.GetSchemaGraph(),
		cache:       graph.GetCache(),
		graphLock:   graph.GetLock(),
	}
}

// NewLookUpManager initializes a LookUpManager from a raw data.DataObj,
// behind the scene it builds the graphs objects using the adapters.NewGraphFromDataObj
func NewLookUpManager(dataObj *data.DataObj) *LookUpManager {
	graphBuilder := graphy.NewGraphBuilder().
		FromDataObj(dataObj).
		WithCacheSize(CacheSize)
	graphObj := graphBuilder.Build()
	return &LookUpManager{
		dataObj:     dataObj,
		factsGraph:  graphObj.GetFactsGraph(),
		schemaGraph: graphObj.GetSchemaGraph(),
		cache:       graphObj.GetCache(),
		graphLock:   graphObj.GetLock(),
	}
}

func (l *LookUpManager) lock() {
	l.graphLock.RLock()
	l.dataObj.RLock()
}

func (l *LookUpManager) unlock() {
	l.graphLock.RUnlock()
	l.dataObj.RUnlock()
}

// getPossibleResourceDerivers is responsible for getting all the possible derivers for a given
// resource.
// It does so by checking the schema graph for any edges to the given resource type
// It checks if there is any derivation rule set to any one of the roles of the given resource type
func (l *LookUpManager) getPossibleResourceDerivers(resource *input.InputResource) ([]string, []string) {
	resourceTypeNode := l.schemaGraph.GetNodeByString(resource.Type)
	relevantRelations := make([]string, 0)
	relevantRoles := make([]string, 0)
	if resourceTypeNode == nil {
		return relevantRelations, relevantRoles
	}
	resourceRoles := resourceTypeNode.GetObjectRelationships(graphy.RoleToResourceRelation)
	for _, roleNode := range resourceRoles {
		possibleDerivers := roleNode.GetObjectRelationshipsByFilter("relation:", graphy.PrefixFilter)
		for possibleDerivingRelation, possibleDeriversRoles := range possibleDerivers {
			relevantRelations = append(relevantRelations, possibleDerivingRelation)
			relevantRoles = append(relevantRoles, lo.MapToSlice(possibleDeriversRoles, func(key string, value *graphy.Node[graphy.GraphNodeI]) string {
				return key
			})...)
		}
	}
	return relevantRelations, relevantRoles
}

// getInDirectRoleAssignments is responsible for getting all the roles that are
// assigned to any subject that can implicitly grant a role on the given object.
// it returns mapping of every user and the roles they are assigned on the linked subject
func (l *LookUpManager) getInDirectRoleAssignments(ctx context.Context, resource *input.InputResource) UserAssignments {
	inDirectRoleAssignments := NewUserAssignments()
	ctx, isVisited := isVisitedFromContext(ctx, resource.String())
	if isVisited {
		return inDirectRoleAssignments
	}
	ctx = setVisitedInContext(ctx, resource.String())
	possibleDeriversRelations, possibleDeriversRoles := l.getPossibleResourceDerivers(resource)
	if len(possibleDeriversRelations) == 0 {
		return inDirectRoleAssignments
	} else if len(possibleDeriversRoles) == 0 {
		return inDirectRoleAssignments
	}
	resourceInstanceNode := l.factsGraph.GetNodeByString(resource.String())
	if resourceInstanceNode == nil {
		return inDirectRoleAssignments
	}
	possibleDeriversInstancesByRelation := resourceInstanceNode.GetObjectRelationshipsAnyOf(possibleDeriversRelations)
	for _, possibleDeriverInstances := range possibleDeriversInstancesByRelation {
		for possibleDeriverInstance, possibleDeriverInstanceNode := range possibleDeriverInstances {
			relevantRoleAssignmentsByRole := possibleDeriverInstanceNode.GetObjectRelationshipsAnyOf(possibleDeriversRoles)
			for role, usersMap := range relevantRoleAssignmentsByRole {
				for user := range usersMap {
					inDirectRoleAssignments.AddUserAssignment(user, role, possibleDeriverInstance)
				}
			}
			recursionResource := input.NewResourceFromString(possibleDeriverInstance)
			inDirectRoleAssignments.Merge(l.getInDirectRoleAssignments(ctx, &recursionResource))
		}
	}

	return inDirectRoleAssignments
}

// getDirectRoleAssignments is responsible for getting all the roles that are directly assigned
// to the given resource excluding any implicit role granted by role derivations
func (l *LookUpManager) getDirectRoleAssignments(resource *input.InputResource) UserAssignments {
	resourceNode := l.factsGraph.GetNodeByString(resource.String())
	if resourceNode == nil {
		return NewUserAssignments()
	}
	directRoleAssignmentsRaw := resourceNode.GetObjectRelationshipsByFilter("#", graphy.ContainsFilter)
	directRoleAssignments := NewUserAssignmentsFromRaw(directRoleAssignmentsRaw, resource.String())
	return directRoleAssignments
}

// LookUpResource is responsible for getting all the roles assigned to the given resource,
// including direct & in-direct roles.
func (l *LookUpManager) LookUpResource(ctx context.Context, resource *input.InputResource) UserAssignments {
	directRoleAssignments := l.getDirectRoleAssignments(resource)
	inDirectRoleAssignments := l.getInDirectRoleAssignments(ctx, resource)

	return directRoleAssignments.Merge(inDirectRoleAssignments)
}

func (l *LookUpManager) lookUpResourceIncludeDerivedRoles(ctx context.Context, resource *input.InputResource) map[string]types.LinkedUsersResultTuple {
	linkedUsersWithRoles := l.LookUpResource(ctx, resource)
	assignments := make(map[string]types.LinkedUsersResultTuple)
	linkedUsers := lo.Keys(linkedUsersWithRoles)
	linkedUsersRolesOnResource := lop.Map(linkedUsers, func(linkedUser string, _ int) types.LinkedUsersResultTuple {
		currentInput := input.InputObj{
			User:     input.NewUserFromString(linkedUser),
			Resource: *resource,
		}
		walker := graph.NewWalker(l.dataObj, &currentInput)
		roles := lo.SliceToMap(lo.Uniq(walker.GetRoles(graph.NewChildContext(ctx))), func(role string) (string, []debug.RootGrantingBlock) {
			return role, walker.GetRootGrants(role)
		})
		return types.LinkedUsersResultTuple{
			Roles:    roles,
			Debugger: walker.GetDebuggerMap(),
		}
	})
	lo.ForEach(linkedUsers, func(linkedUser string, i int) {
		assignments[linkedUser] = linkedUsersRolesOnResource[i]
	})
	return assignments
}

// LookUpResourceIncludeDerivedRoles is responsible for returning all the roles
// assigned only to the **given resource**, including roles granted using role derivations.
// unlike the getInDirectRoleAssignments private function which returns the role assigned to
// the linked resources, this function takes into account the derivations and returns
// only the roles granted to the given resource with the debugger output.
func (l *LookUpManager) LookUpResourceIncludeDerivedRoles(ctx context.Context, resource *input.InputResource) map[string]types.LinkedUsersResultTuple {
	l.lock()
	defer l.unlock()
	cacheKey := resource.String()
	if l.cache == nil || CacheSize == 0 {
		return l.lookUpResourceIncludeDerivedRoles(ctx, resource)
	}
	cacheValue, found := l.cache.Peek(cacheKey)
	if found {
		return cacheValue
	}
	cacheValue = l.lookUpResourceIncludeDerivedRoles(ctx, resource)
	l.cache.Add(cacheKey, cacheValue)
	return cacheValue
}

// UserAssignments a map of user key to role assignments assigned to that user
type UserAssignments map[string][]RoleAssignment

// NewUserAssignments returns a new empty UserAssignment
func NewUserAssignments() UserAssignments {
	return make(UserAssignments)
}

// NewUserAssignmentsFromRaw accepts a raw representation of role assignments
// on a given resource as we store them in the data and returns a UserAssignments.
func NewUserAssignmentsFromRaw[T graphy.GraphNodeI](rawAssignments graphy.Relationships[T], resource string) UserAssignments {
	directRoleAssignments := make(UserAssignments)
	for role, users := range rawAssignments {
		for user := range users {
			if !strings.HasPrefix(user, "user:") {
				// this should never happen because role assignments are only to users ( as subjects )
				continue
			}
			directRoleAssignments.AddUserAssignment(user, role, resource)
		}
	}
	return directRoleAssignments
}

// Merge merges any given number of UserAssignments into the current UserAssignments.
// For ease of use it also returns the current UserAssignments
func (ua UserAssignments) Merge(userAssignments ...UserAssignments) UserAssignments {
	for _, userAssignment := range userAssignments {
		if len(userAssignment) == 0 {
			continue
		}
		for user, assignments := range userAssignment {
			for _, assignment := range assignments {
				ua.AddUserAssignment(user, assignment.Role, assignment.Resource)
			}
		}
	}
	return ua
}

// AddUserAssignment add a RoleAssignment to the current UserAssignments
func (ua UserAssignments) AddUserAssignment(user, role, resource string) {
	roleAssignmentToAdd := RoleAssignment{
		User:     user,
		Role:     role,
		Resource: resource,
	}
	currentAssignments, found := ua[user]
	if !found {
		ua[user] = []RoleAssignment{
			roleAssignmentToAdd,
		}
	} else {
		currentAssignments = append(currentAssignments, roleAssignmentToAdd)
		ua[user] = currentAssignments
	}
}

// RoleAssignment is a representation of a role assignment between a user and a resource
type RoleAssignment struct {
	// User is the user that the role is assigned to
	User string
	// Role is the role the user is assigned with
	Role string
	// Resource is the resource the role is assigned on
	Resource string
}
