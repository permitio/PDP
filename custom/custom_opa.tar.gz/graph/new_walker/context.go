package new_walker

import "context"

type contextKey string

const (
	isVisitedContextKey contextKey = "isVisited"
)

type visitedMap map[string]bool

func getVisitedMapFromContext(ctx context.Context) (context.Context, visitedMap) {
	contextVisitedMapI := ctx.Value(isVisitedContextKey)
	if contextVisitedMapI == nil {
		value := make(visitedMap)
		return context.WithValue(ctx, isVisitedContextKey, value), value
	}
	contextVisitedMap, ok := contextVisitedMapI.(visitedMap)
	if !ok {
		// this should never happen
		value := make(visitedMap)
		return context.WithValue(ctx, isVisitedContextKey, value), value
	}
	return ctx, contextVisitedMap
}

func (vm visitedMap) get(key string) bool {
	if isVisitedValue, exists := vm[key]; !exists {
		// in case the value does not exist in the map, we return false
		return false
	} else {
		return isVisitedValue
	}
}

func (vm visitedMap) setVisited(key string) {
	vm[key] = true
}

func isVisitedFromContext(ctx context.Context, key string) (context.Context, bool) {
	ctx, isVisitedMap := getVisitedMapFromContext(ctx)
	return ctx, isVisitedMap.get(key)
}

func setVisitedInContext(ctx context.Context, key string) context.Context {
	ctx, isVisitedMap := getVisitedMapFromContext(ctx)
	isVisitedMap.setVisited(key)
	return ctx
}
