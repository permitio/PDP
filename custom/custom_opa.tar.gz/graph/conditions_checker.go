package graph

import "github.com/permitio/permit-opa/types/data"

type conditionsChecker struct {
	settings data.SettingsBlock
}

func newConditionsChecker(settings data.SettingsBlock) *conditionsChecker {
	return &conditionsChecker{
		settings: settings,
	}
}

func (c *conditionsChecker) CheckConditions(walker *Walker) bool {
	if c.settings.SupersededByDirectRole && len(walker.GetDirectRoles()) > 0 {
		return false
	}
	return true
}
