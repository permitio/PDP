package graph

import (
	"context"
	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/debug"
	"github.com/permitio/permit-opa/types/input"
	"golang.org/x/exp/slices"
)

type derivationChecker struct {
	data.RoleDerivation
	role string
}

func newDerivationChecker(roleDerivation data.RoleDerivation, role string) *derivationChecker {
	return &derivationChecker{
		RoleDerivation: roleDerivation,
		role:           role,
	}
}

func (d *derivationChecker) IsDeriving(ctx context.Context, walker *Walker, relations data.Relations) bool {
	if !newConditionsChecker(d.Settings).CheckConditions(walker) {
		return false
	}
	for _, rule := range d.Rules {
		ruleChecker := newRuleChecker(rule, d.role)
		if ruleChecker.CheckRule(ctx, walker, relations) {
			return true
		}
	}
	return false
}

type ruleChecker struct {
	data.RoleDerivationRule
	role string
}

func newRuleChecker(roleDerivationRule data.RoleDerivationRule, role string) *ruleChecker {
	return &ruleChecker{
		RoleDerivationRule: roleDerivationRule,
		role:               role,
	}
}

func (r *ruleChecker) CheckRule(ctx context.Context, walker *Walker, relations data.Relations) bool {
	if !newConditionsChecker(r.Settings).CheckConditions(walker) {
		return false
	}
	// Check the schema matches to the rule
	relationships, exists := relations[r.Relation.Full()]
	if !exists {
		// continue because this rule cant be applied to this resource
		// since it doesn't have the required relation
		return false
	}
	relatedResources, exists := relationships[r.RelatedResource]
	if !exists {
		// continue because this rule cant be applied to this resource
		// since it doesn't have the required relation to the related resource
		return false
	}
	for _, relatedResourceId := range relatedResources {
		resource := input.NewResource(relatedResourceId, r.RelatedResource)
		childWalker := walker.newChildWalker(resource)
		relatedRoles := childWalker.GetRoles(ctx)
		if slices.Contains(relatedRoles, r.RelatedRole) {
			walker.MergeChildDebugger(childWalker, r.role, r.RelatedRole, &debug.RelationshipTuple{
				Subject:  debug.NewResource(relatedResourceId, r.RelatedResource),
				Relation: debug.Relation(r.Relation),
				Object:   debug.NewResource(walker.inputObj.Resource.Key, walker.inputObj.Resource.Type),
			})
			return true
		}
	}
	return false
}
