package graphy

import (
	"encoding/json"
	"strings"
	"sync"

	lru "github.com/hashicorp/golang-lru/v2"
	"github.com/open-policy-agent/opa/topdown/cache"
	"github.com/permitio/permit-opa/types"
	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/input"
	"go.uber.org/zap"
)

// Graph is a representation of all the data in two graphs
// this struct is later stored in the cache.InterQueryCache of OPA
type Graph struct {
	// factsGraph is a graph of the facts
	factsGraph *GraphPointer[GraphNodeI]

	// schemaGraph is a graph of the schema
	schemaGraph *GraphPointer[GraphNodeI]
	// cache is a cache of the nodes
	cache *lru.Cache[string, map[string]types.LinkedUsersResultTuple]
	// lock is a mutex for the graph
	lock sync.RWMutex
}

// NewGraph adapts the raw data.DataObj into a full Graph representation
// using the adapters.NewGraphFromDataObj function
func NewGraph(cacheSize int) *Graph {
	factsGraph := NewGraphPointer[GraphNodeI]()
	schemaGraph := NewGraphPointer[GraphNodeI]()
	var cache *lru.Cache[string, map[string]types.LinkedUsersResultTuple]
	if cacheSize > 0 {
		_cache, err := lru.New[string, map[string]types.LinkedUsersResultTuple](cacheSize)
		if err == nil {
			cache = _cache
		}
	}
	return &Graph{
		factsGraph:  factsGraph,
		schemaGraph: schemaGraph,
		cache:       cache,
	}
}

func (g *Graph) purgeCache() {
	if g.cache != nil {
		cacheSize := g.cache.Len()
		g.cache.Purge()

		// Log cache purge events with size information
		zap.S().Debugf("Purged graph cache with %d entries", cacheSize)
	}
}

func (g *Graph) wLock() {
	g.lock.Lock()
}

func (g *Graph) wUnlock() {
	g.lock.Unlock()
}

func (g *Graph) rLock() {
	g.lock.RLock()
}

func (g *Graph) rUnlock() {
	g.lock.RUnlock()
}

func (g *Graph) GetFactsGraph() *GraphPointer[GraphNodeI] {
	g.rLock()
	defer g.rUnlock()
	return g.factsGraph
}

func (g *Graph) GetSchemaGraph() *GraphPointer[GraphNodeI] {
	g.rLock()
	defer g.rUnlock()
	return g.schemaGraph
}

func (g *Graph) GetLock() *sync.RWMutex {
	return &g.lock
}

func (g *Graph) GetCache() *lru.Cache[string, map[string]types.LinkedUsersResultTuple] {
	g.rLock()
	defer g.rUnlock()
	return g.cache
}

// Function implementing the cache.InterQueryCacheValue interface in OPA
func (g *Graph) SizeInBytes() int64 {
	g.rLock()
	defer g.rUnlock()
	// This isn't the "real" size in bytes of the graph, but we already saw OPA not doing too much effort
	// to calculate the size here, so we considered this as a "nice to have" feature.
	return int64(g.factsGraph.NodesCount() + g.schemaGraph.NodesCount())
}

// Function implementing the cache.InterQueryCacheValue interface in OPA
func (g *Graph) Clone() (cache.InterQueryCacheValue, error) {
	g.rLock()
	defer g.rUnlock()
	return &Graph{
		factsGraph:  g.factsGraph.Clone(),
		schemaGraph: g.schemaGraph.Clone(),
		cache:       g.cache,
	}, nil
}

// ApplyDeltaUpdate applies incremental updates to the graph without rebuilding it completely
// This follows a similar approach to DataObj.ApplyDeltaUpdate but operates directly on the graph
func (g *Graph) ApplyDeltaUpdate(deltaUpdate *input.DeltaUpdate) (*Graph, error) {
	// Clear the cache as it might contain stale data
	g.wLock()
	defer g.wUnlock()
	g.purgeCache()

	deltaUpdatePath := strings.Split(
		strings.TrimPrefix(deltaUpdate.Path, "/"),
		"/",
	)

	switch len(deltaUpdatePath) {
	case 1:
		switch deltaUpdatePath[0] {
		// Full replacement - rebuild both graphs
		case "":
			return g.applyFullReplacement(deltaUpdate)
		// Major section replacement
		case "relationships":
			return g.applyRelationshipsReplacement(deltaUpdate)
		case "role_assignments":
			return g.applyRoleAssignmentsReplacement(deltaUpdate)
		case "resource_types":
			return g.applyResourceTypesReplacement(deltaUpdate)
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw Graph", deltaUpdate.Path)
			return g, nil
		}
	case 2:
		// Specific item replacement
		switch deltaUpdatePath[0] {
		case "relationships":
			return g.applyRelationshipItemReplacement(deltaUpdate, deltaUpdatePath[1])
		case "role_assignments":
			return g.applyRoleAssignmentItemReplacement(deltaUpdate, deltaUpdatePath[1])
		case "resource_types":
			return g.applyResourceTypeItemReplacement(deltaUpdate, deltaUpdatePath[1])
		default:
			zap.S().Debugf("ignoring delta update for path: %s for raw Graph", deltaUpdate.Path)
			return g, nil
		}
	default:
		zap.S().Debugf("ignoring delta update for path: %s for raw Graph", deltaUpdate.Path)
		return g, nil
	}
}

// applyFullReplacement rebuilds both graphs from the dataObj
func (g *Graph) applyFullReplacement(deltaUpdate *input.DeltaUpdate) (*Graph, error) {
	var dataObj data.DataObj
	err := json.Unmarshal(deltaUpdate.Value, &dataObj)
	if err != nil {
		return nil, err
	}
	graphBuilder := NewGraphBuilder().
		FromDataObj(&dataObj).
		WithCache(g.cache)

	newGraph := graphBuilder.Build()
	g.factsGraph = newGraph.GetFactsGraph()
	g.schemaGraph = newGraph.GetSchemaGraph()
	return g, nil
}

// applyRelationshipsReplacement updates just the relationships part of the facts graph
func (g *Graph) applyRelationshipsReplacement(deltaUpdate *input.DeltaUpdate) (*Graph, error) {
	var relationships data.RelationshipTuples
	err := json.Unmarshal(deltaUpdate.Value, &relationships)
	if err != nil {
		return nil, err
	}
	g.factsGraph.CleanRelationships()
	addRelationshipsGraphFromDataObj(relationships, g.factsGraph)
	return g, nil
}

// applyRoleAssignmentsReplacement updates just the role assignments part of the facts graph
func (g *Graph) applyRoleAssignmentsReplacement(deltaUpdate *input.DeltaUpdate) (*Graph, error) {
	var roleAssignments data.RoleAssignments
	err := json.Unmarshal(deltaUpdate.Value, &roleAssignments)
	if err != nil {
		return nil, err
	}
	g.factsGraph.CleanAssignments()
	// if the role assignments are empty, we don't need to do anything besides cleaning the assignments
	if len(roleAssignments) == 0 {
		return g, nil
	}
	addRoleAssignmentsGraphFromDataObj(roleAssignments, g.factsGraph)
	return g, nil
}

// applyResourceTypesReplacement updates just the resource types part of the schema graph
func (g *Graph) applyResourceTypesReplacement(deltaUpdate *input.DeltaUpdate) (*Graph, error) {
	var resourceTypes data.ResourceTypes
	err := json.Unmarshal(deltaUpdate.Value, &resourceTypes)
	if err != nil {
		return nil, err
	}
	g.schemaGraph.Purge()

	g.schemaGraph = newSchemaGraph(resourceTypes, g.schemaGraph)
	return g, nil
}

// "branch:3ad14f0d-991f-e711-8100-fc15b428467c" -> relation:company_branch->"company:8749ed4f-a31f-e711-8100-fc15b428467c"
// applyRelationshipItemReplacement updates a specific relationship in the facts graph
func (g *Graph) applyRelationshipItemReplacement(deltaUpdate *input.DeltaUpdate, key string) (*Graph, error) {
	var relations data.Relations
	err := json.Unmarshal(deltaUpdate.Value, &relations)
	if err != nil {
		return nil, err
	}
	node := g.factsGraph.GetNodeByString(key)
	if len(relations) == 0 {
		// this means it's a delete
		if node == nil {
			// the node is already deleted, which shouldn't happen but it's the same end result
			return g, nil
		}
		// for delete we remove all the relationships that related to this node as an object
		// by using the relation prefix
		remainingRelationships := node.RemoveObjectRelationshipsByFilter("relation:", PrefixFilter)
		if remainingRelationships == 0 {
			// if there are no relationships left, we delete this node
			g.factsGraph.RemoveNode(node)
		}
	} else {
		// this means it's an update
		if node != nil {
			// first we remove all the relationships that related to this node as an object
			// by using the relation prefix
			node.RemoveObjectRelationshipsByFilter("relation:", PrefixFilter)
		}
		// then we add the new relationships
		addRelationshipsGraphFromDataObj(data.RelationshipTuples{
			key: relations,
		}, g.factsGraph)
	}
	return g, nil
}

// applyRoleAssignmentItemReplacement updates a specific role assignment in the facts graph
func (g *Graph) applyRoleAssignmentItemReplacement(deltaUpdate *input.DeltaUpdate, key string) (*Graph, error) {
	var assignments data.Assignments

	err := json.Unmarshal(deltaUpdate.Value, &assignments)
	if err != nil {
		return nil, err
	}
	user := strings.TrimPrefix(key, "user:")
	node := g.factsGraph.GetNodeByString(user)
	if len(assignments) == 0 {
		// this means it's a delete
		if node == nil {
			// the node is already deleted, which shouldn't happen but it's the same end result
			return g, nil
		}
		// we first remove all the subject relationships
		// when talking about role assignments, the subject is ALWAYS a user
		// and the object is ALWAYS a resource
		// therefore the subject relationships are always a role assignment between a user and a resource
		node.RemoveAllSubjectRelationships()
		// user can't have any relationships that are not role assignments
		// it is NEVER the object in the relationship,
		// meaning we can saf
		g.factsGraph.RemoveNode(node)
	} else {
		if node != nil {
			// we first remove all the subject relationships if the node exists
			// when talking about role assignments, the subject is ALWAYS a user
			// and the object is ALWAYS a resource
			// therefore the subject relationships are always a role assignment between a user and a resource
			node.RemoveAllSubjectRelationships()
		}
		// then we add the new role assignments
		addRoleAssignmentsGraphFromDataObj(data.RoleAssignments{
			key: assignments,
		}, g.factsGraph)
	}

	return g, nil
}

// applyResourceTypeItemReplacement updates a specific resource type in the schema graph
func (g *Graph) applyResourceTypeItemReplacement(deltaUpdate *input.DeltaUpdate, key string) (*Graph, error) {
	var resourceType data.ResourceType
	err := json.Unmarshal(deltaUpdate.Value, &resourceType)
	if err != nil {
		return nil, err
	}

	resourceTypeNode := g.schemaGraph.GetNodeByString(key)
	if resourceType.Actions == nil && len(resourceType.DerivedRoles) == 0 {
		// this means it's a delete
		if resourceTypeNode == nil {
			// the node is already deleted, which shouldn't happen but it's the same end result
			return g, nil
		}
		// we only remove the object relationships because we don't know if the resource type
		// is deleted or just emptied out from the derived roles
		// if it's deleted, we should also get a delta update for the resource type referencing it
		// and we will remove the node then if no relationships are left
		remainingRelationships := resourceTypeNode.GetObjectRelationshipsByFilter(RoleToResourceRelation, NoFilter)
		// if there are no relationships left, we delete the node
		if remainingRelationships.IsEmpty() {
			g.schemaGraph.RemoveNode(resourceTypeNode)
			return g, nil
		}
		for _, roleNode := range remainingRelationships[RoleToResourceRelation] {
			roleNode.RemoveObjectRelationshipsByFilter("relation:", PrefixFilter)
		}
	} else {
		if resourceTypeNode != nil {
			// we first remove all the object relationships if the node exists
			// when talking about resource types, the object is ALWAYS a resource type
			// therefore the object relationships are always a resource type between a role ( subject ) and a resource type ( object )
			remainingRelationships := resourceTypeNode.GetObjectRelationshipsByFilter(RoleToResourceRelation, ExactMatchFilter)
			// if there are no relationships left, we delete the node
			if remainingRelationships.IsEmpty() {
				g.schemaGraph.RemoveNode(resourceTypeNode)
				return g, nil
			}
			for _, roleNode := range remainingRelationships[RoleToResourceRelation] {
				roleNode.RemoveObjectRelationshipsByFilter("relation:", PrefixFilter)
			}
		}
		g.schemaGraph = newSchemaGraph(data.ResourceTypes{
			key: resourceType,
		}, g.schemaGraph)
	}
	return g, nil
}
