package graphy

import (
	"github.com/permitio/permit-opa/types/data"
)

const (
	RoleToResourceRelation string = "role"
)

// newRelationshipsGraphFromDataObj accept a raw data.DataObj and returns a graph of UserOrResource
// containing all the relationships between resource instances in the data
// by iterating all the relationships in the data
func addRelationshipsGraphFromDataObj(relationships data.RelationshipTuples, graphPointer *GraphPointer[GraphNodeI]) *GraphPointer[GraphNodeI] {
	for object, relationsMap := range relationships {
		if len(relationsMap) == 0 {
			// if there are no relations, we don't need to add the node
			// we can just skip it, because it's a redundant node in the graph
			// a resource with no relationships is the same as a resource that doesn't exist
			// in terms of the graph
			continue
		}
		objectResource := NewResourceFromString(object)
		objectResourceNode := graphPointer.NewNodeInGraph(objectResource)
		for relation, resourceTypesMap := range relationsMap {
			for resourceType, subjects := range resourceTypesMap {
				for _, subject := range subjects {
					subjectResource := NewResource(resourceType, subject)
					subjectResourceNode := graphPointer.NewNodeInGraph(subjectResource)
					subjectResourceNode.AddSubjectRelationship(relation, objectResourceNode)
				}
			}
		}
	}
	return graphPointer
}

// newRoleAssignmentsGraphFromDataObj accepts a raw data.DataObj and in initial graph with the relationships between
// resource instances set already, and adds the role assignments between the users to the resource
// instance to the initial graph it got in the relationshipsGraph argument.
// for ease of use, it also returns the updated graph
func addRoleAssignmentsGraphFromDataObj(roleAssignments data.RoleAssignments, relationshipsGraph *GraphPointer[GraphNodeI]) *GraphPointer[GraphNodeI] {
	for user, assignments := range roleAssignments {
		if len(assignments) == 0 {
			// if there are no assignments, we don't need to add the node
			// we can just skip it, because it's a redundant node in the graph
			// a user with no role assignments is the same as a user that doesn't exist
			// in terms of the graph
			continue
		}
		userNode := relationshipsGraph.NewNodeInGraph(NewUserFromString(user))
		for assignedResource, roles := range assignments {
			resource := NewResourceFromString(assignedResource)
			assignedResourceNode := relationshipsGraph.NewNodeInGraph(resource)
			for _, role := range roles {
				assignedResourceNode.AddObjectRelationship(
					NewRole(
						resource.Type,
						role,
					).String(),
					userNode,
				)
			}
		}
	}
	return relationshipsGraph
}

// newFactsGraph accepts a raw data.DataObj and created a graph based on the relationships
// between the users, resource instances using newRelationshipsGraphFromDataObj and newRoleAssignmentsGraphFromDataObj
func newFactsGraph(dataObj *data.DataObj) *GraphPointer[GraphNodeI] {
	factsGraph := NewGraphPointer[GraphNodeI]()
	factsGraph = addRelationshipsGraphFromDataObj(dataObj.Relationships, factsGraph)
	return addRoleAssignmentsGraphFromDataObj(dataObj.RoleAssignments, factsGraph)
}

// newSchemaGraph accepts a raw data.DataObj and returns a graph of SchemaNodeI
// it iterates all resource types, roles, and role derivations and returns
// a graph with the relevant edges between each one of the objects mentioned
func newSchemaGraph(resourceTypes data.ResourceTypes, schemaGraph *GraphPointer[GraphNodeI]) *GraphPointer[GraphNodeI] {
	for resourceType, resourceTypeObj := range resourceTypes {
		resourceTypeNode := schemaGraph.NewNodeInGraph(NewSchemaNodeFromString(resourceType))
		for derivedRole, roleDerivation := range resourceTypeObj.DerivedRoles {
			derivedRoleNode := schemaGraph.NewNodeInGraph(
				NewRole(
					resourceType,
					derivedRole,
				),
			)
			derivedRoleNode.AddSubjectRelationship(RoleToResourceRelation, resourceTypeNode)
			for _, rule := range roleDerivation.Rules {
				relatedResourceTypeNode := schemaGraph.NewNodeInGraph(NewSchemaNodeFromString(rule.RelatedResource))
				deriverRoleNode := schemaGraph.NewNodeInGraph(
					NewRole(
						rule.RelatedResource,
						rule.RelatedRole,
					),
				)
				deriverRoleNode.AddSubjectRelationship(RoleToResourceRelation, relatedResourceTypeNode)
				derivedRoleNode.AddObjectRelationship(rule.Relation.Full(), deriverRoleNode)
			}
		}
	}
	return schemaGraph
}
