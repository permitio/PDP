package graphy

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/permitio/permit-opa/types/data"
	"github.com/permitio/permit-opa/types/input"
	"github.com/samber/lo"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// Helper functions to load test data
// loadDataFromFile loads a DataObj from a file path
func loadDataFromFile(t *testing.T, filePath string) *data.DataObj {
	t.Helper()

	raw, err := os.ReadFile(filePath)
	require.NoError(t, err, "Failed to read data file: %s", filePath)

	var dataObj data.DataObj
	err = json.Unmarshal(raw, &dataObj)
	require.NoError(t, err, "Failed to unmarshal data from file: %s", filePath)

	return &dataObj
}

// findDataJsonFiles finds all data.json files in the examples directory,
// excluding those in directories that start with an underscore
func findDataJsonFiles(t *testing.T) []string {
	t.Helper()

	projectRoot := findProjectRoot(t)
	examplesDir := filepath.Join(projectRoot, "examples")

	var paths []string
	err := filepath.Walk(examplesDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}

		// Skip directories that start with underscore
		if info.IsDir() && len(info.Name()) > 0 && info.Name()[0] == '_' {
			return filepath.SkipDir
		}

		// Only include data.json files
		if !info.IsDir() && info.Name() == "data.json" {
			paths = append(paths, path)
		}

		return nil
	})

	require.NoError(t, err, "Failed to walk examples directory")
	require.NotEmpty(t, paths, "No data.json files found in examples directory")

	return paths
}

// findProjectRoot finds the root directory of the project
func findProjectRoot(t *testing.T) string {
	t.Helper()

	// Start from the current working directory
	dir, err := os.Getwd()
	require.NoError(t, err, "Failed to get current working directory")

	// Go up until we find a go.mod file, which indicates the project root
	for {
		if _, err := os.Stat(filepath.Join(dir, "go.mod")); err == nil {
			return dir
		}

		parent := filepath.Dir(dir)
		if parent == dir {
			// We've reached the filesystem root without finding go.mod
			t.Fatal("Could not find project root (no go.mod file found)")
		}
		dir = parent
	}
}

// Test that building a graph incrementally produces the same result as building it all at once
func TestGraphIncrementalBuild(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Create a graph from the full DataObj
			fullyBuiltGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()

			incrementallyBuiltGraph := NewGraphBuilder().Build()
			for key, relationship := range origDataObj.Relationships {
				relationshipValue, err := json.Marshal(relationship)
				require.NoError(t, err, "Failed to marshal relationship")
				incrementallyBuiltGraph, err = incrementallyBuiltGraph.ApplyDeltaUpdate(&input.DeltaUpdate{
					Path:  "/relationships/" + key,
					Value: relationshipValue,
				})
				assert.NoError(t, err, "Failed to apply delta update to relationship")
			}
			for key, roleAssignment := range origDataObj.RoleAssignments {
				roleAssignmentValue, err := json.Marshal(roleAssignment)
				require.NoError(t, err, "Failed to marshal role assignment")
				incrementallyBuiltGraph, err = incrementallyBuiltGraph.ApplyDeltaUpdate(&input.DeltaUpdate{
					Path:  "/role_assignments/" + key,
					Value: roleAssignmentValue,
				})
				assert.NoError(t, err, "Failed to apply delta update to role assignment")
			}
			for key, resourceType := range origDataObj.ResourceTypes {
				resourceTypeValue, err := json.Marshal(resourceType)
				require.NoError(t, err, "Failed to marshal resource type")
				incrementallyBuiltGraph, err = incrementallyBuiltGraph.ApplyDeltaUpdate(&input.DeltaUpdate{
					Path:  "/resource_types/" + key,
					Value: resourceTypeValue,
				})
				assert.NoError(t, err, "Failed to apply delta update to resource type")
			}

			// Compare node counts

			if !assert.Equalf(t,
				fullyBuiltGraph.factsGraph.NodesCount(), incrementallyBuiltGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match",
			) {
				missingInIncrementallyBuiltGraph, missingInFullyBuiltGraph := lo.Difference(
					lo.Keys(fullyBuiltGraph.factsGraph.nodes),
					lo.Keys(incrementallyBuiltGraph.factsGraph.nodes),
				)
				assert.Failf(
					t,
					"Facts graph node counts should match",
					"missing nodes in incrementally built graph: %v, missing nodes in fully built graph: %v",
					missingInIncrementallyBuiltGraph, missingInFullyBuiltGraph,
				)
			}
			if !assert.Equal(t, fullyBuiltGraph.schemaGraph.NodesCount(), incrementallyBuiltGraph.schemaGraph.NodesCount(),
				"Schema graph node counts should match") {
				missingInIncrementallyBuiltGraph, missingInFullyBuiltGraph := lo.Difference(
					lo.Keys(fullyBuiltGraph.schemaGraph.nodes),
					lo.Keys(incrementallyBuiltGraph.schemaGraph.nodes),
				)
				assert.Failf(
					t,
					"Schema graph node counts should match",
					"missing nodes in incrementally built graph: %v, missing nodes in fully built graph: %v",
					missingInIncrementallyBuiltGraph, missingInFullyBuiltGraph,
				)
			}
			// Compare specific nodes (sampling a few)
			compareFactsGraphNodes(t, fullyBuiltGraph.factsGraph, incrementallyBuiltGraph.factsGraph)
			compareSchemaGraphNodes(t, fullyBuiltGraph.schemaGraph, incrementallyBuiltGraph.schemaGraph)
		})
	}
}

// Test that removing and re-adding a relationship produces the same graph
func TestGraphRelationshipRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(origDataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Choose a relationship to remove and add back
			var objectToTest string
			var relationsToTest data.Relations
			for object, relations := range origDataObj.Relationships {
				if len(relations) > 0 {
					objectToTest = object
					relationsToTest = relations
					break
				}
			}

			// Skip if we didn't find a suitable relationship
			if objectToTest == "" {
				t.Skip("No suitable relationship found for testing")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original DataObj")

			// Remove the relationship
			emptyRelations := data.Relations{}
			emptyValue, err := json.Marshal(emptyRelations)
			require.NoError(t, err, "Failed to marshal empty relations")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove relationship")
			// The facts graph should have less relationships
			// (nodes might still exist, but the relationship should be gone)
			verifyRelationshipRemoved(t, originalGraph.factsGraph, newGraph.factsGraph, objectToTest, relationsToTest)

			// Add the relationship back
			relationsValue, err := json.Marshal(relationsToTest)
			require.NoError(t, err, "Failed to marshal relations")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships/" + objectToTest,
				Value: relationsValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationship back")
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding relationship")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding relationship")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
		})
	}
}

func TestGraphRoleAssignmentsRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no role assignments
			if len(origDataObj.RoleAssignments) == 0 {
				t.Skip("No role assignments in data, skipping")
			}

			// Choose a role assignment to remove and add back
			var userToTest string
			var assignmentsToTest data.Assignments
			for user, assignments := range origDataObj.RoleAssignments {
				if len(assignments) > 0 {
					userToTest = user
					assignmentsToTest = assignments
					break
				}
			}

			// Skip if we didn't find a suitable role assignment
			if userToTest == "" {
				t.Skip("No suitable role assignment found for testing")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original graph")

			// Remove the role assignment
			emptyAssignments := data.Assignments{}
			emptyValue, err := json.Marshal(emptyAssignments)
			require.NoError(t, err, "Failed to marshal empty assignments")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/role_assignments/" + userToTest,
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove role assignment")

			// Verify the role assignments were removed
			// For each resource in the assignments, check that the user's role no longer exists
			for resource, roles := range assignmentsToTest {
				resourceNode := newGraph.factsGraph.GetNodeByString(resource)
				if resourceNode == nil {
					continue
				}

				for _, role := range roles {
					roleStr := resource + "#" + role
					roleNode := newGraph.schemaGraph.GetNodeByString(roleStr)
					if roleNode != nil {
						userObjects := roleNode.GetObjectRelationships("role")
						_, exists := userObjects[userToTest]
						assert.False(t, exists, "User %s should not have role %s on resource %s after removal",
							userToTest, role, resource)
					}
				}
			}

			// Add the role assignment back
			assignmentsValue, err := json.Marshal(assignmentsToTest)
			require.NoError(t, err, "Failed to marshal assignments")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/role_assignments/" + userToTest,
				Value: assignmentsValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add role assignment back")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding role assignment")
			assert.Equal(t, originalGraph.schemaGraph.NodesCount(), newGraph.schemaGraph.NodesCount(),
				"Schema graph node counts should match after re-adding role assignment")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
			compareSchemaGraphNodes(t, originalGraph.schemaGraph, newGraph.schemaGraph)
		})
	}
}

func TestGraphResourceTypesRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types
			if len(origDataObj.ResourceTypes) == 0 {
				t.Skip("No resource types in data, skipping")
			}

			// Choose a resource type to remove and add back
			var resourceTypeToTest string
			var resourceTypeObjToTest data.ResourceType
			for resourceType, resourceTypeObj := range origDataObj.ResourceTypes {
				if len(resourceTypeObj.DerivedRoles) > 0 {
					resourceTypeToTest = resourceType
					resourceTypeObjToTest = resourceTypeObj
					break
				}
			}

			// Skip if we didn't find a suitable resource type
			if resourceTypeToTest == "" {
				t.Skip("No suitable resource type found for testing")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original graph")

			// Remove the resource type
			emptyValue, err := json.Marshal(nil)
			require.NoError(t, err, "Failed to marshal empty resource type")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types/" + resourceTypeToTest,
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove resource type")

			// Verify the resource type derivations were removed
			verifyResourceTypeDerivationsRemoved(t, originalGraph.schemaGraph, newGraph.schemaGraph, resourceTypeToTest)

			// Add the resource type back
			resourceTypeValue, err := json.Marshal(resourceTypeObjToTest)
			require.NoError(t, err, "Failed to marshal resource type")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types/" + resourceTypeToTest,
				Value: resourceTypeValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource type back")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding resource type")
			assert.Equal(t, originalGraph.schemaGraph.NodesCount(), newGraph.schemaGraph.NodesCount(),
				"Schema graph node counts should match after re-adding resource type")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
			compareSchemaGraphNodes(t, originalGraph.schemaGraph, newGraph.schemaGraph)
		})
	}
}

func TestGraphRelationshipsMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no relationships
			if len(origDataObj.Relationships) == 0 {
				t.Skip("No relationships in data, skipping")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original graph")

			// Remove all relationships by replacing with empty map
			emptyRelationships := data.RelationshipTuples{}
			emptyValue, err := json.Marshal(emptyRelationships)
			require.NoError(t, err, "Failed to marshal empty relationships")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/relationships",
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all relationships")

			// Verify all relationships were removed
			// The facts graph should have fewer relationships though nodes might still exist
			for objectKey, relations := range origDataObj.Relationships {
				for relation := range relations {
					objectNode := originalGraph.factsGraph.GetNodeByString(objectKey)
					if objectNode != nil {
						subjects := objectNode.GetObjectRelationships(relation)
						for subjectStr := range subjects {
							// Find this subject in the modified graph
							removedSubjectNode := newGraph.factsGraph.GetNodeByString(subjectStr)
							if removedSubjectNode != nil {
								// Relationship should be gone
								removedObjects := removedSubjectNode.GetSubjectRelationships(relation)
								if removedObjects != nil {
									_, exists := removedObjects[objectKey]
									assert.False(t, exists, "Relationship from %s to %s via %s should be removed",
										subjectStr, objectKey, relation)
								}
							}
						}
					}
				}
			}

			// Add all relationships back
			relationshipsValue, err := json.Marshal(origDataObj.Relationships)
			require.NoError(t, err, "Failed to marshal relationships")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/relationships",
				Value: relationshipsValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add relationships back")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding relationships")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
		})
	}
}

func TestGraphRoleAssignmentsMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no role assignments
			if len(origDataObj.RoleAssignments) == 0 {
				t.Skip("No role assignments in data, skipping")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original graph")

			// Remove all role assignments by replacing with empty map
			emptyRoleAssignments := data.RoleAssignments{}
			emptyValue, err := json.Marshal(emptyRoleAssignments)
			require.NoError(t, err, "Failed to marshal empty role assignments")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/role_assignments",
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all role assignments")

			// Verify all role assignments were removed
			// For each user in the role assignments, check that their roles no longer exist
			for user, assignments := range origDataObj.RoleAssignments {
				for resource, roles := range assignments {
					for _, role := range roles {
						roleStr := resource + "#" + role
						roleNode := newGraph.schemaGraph.GetNodeByString(roleStr)
						if roleNode != nil {
							userObjects := roleNode.GetObjectRelationships("role")
							_, exists := userObjects[user]
							assert.False(t, exists, "User %s should not have role %s on resource %s after removal",
								user, role, resource)
						}
					}
				}
			}

			// Add all role assignments back
			roleAssignmentsValue, err := json.Marshal(origDataObj.RoleAssignments)
			require.NoError(t, err, "Failed to marshal role assignments")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/role_assignments",
				Value: roleAssignmentsValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add role assignments back")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding role assignments")
			assert.Equal(t, originalGraph.schemaGraph.NodesCount(), newGraph.schemaGraph.NodesCount(),
				"Schema graph node counts should match after re-adding role assignments")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
			compareSchemaGraphNodes(t, originalGraph.schemaGraph, newGraph.schemaGraph)
		})
	}
}

func TestGraphResourceTypesMajorRemoveAndAddBack(t *testing.T) {
	dataFiles := findDataJsonFiles(t)

	for _, dataFile := range dataFiles {
		t.Run(filepath.Base(filepath.Dir(dataFile)), func(t *testing.T) {
			// Load the data from the file
			origDataObj := loadDataFromFile(t, dataFile)

			// Skip if there are no resource types
			if len(origDataObj.ResourceTypes) == 0 {
				t.Skip("No resource types in data, skipping")
			}

			// Build original graphs
			originalGraph := NewGraphBuilder().
				FromDataObj(origDataObj).
				Build()
			newGraphI, err := originalGraph.Clone()
			newGraph := newGraphI.(*Graph)
			require.NoError(t, err, "Failed to clone original graph")

			// Remove all resource types by replacing with empty map
			emptyResourceTypes := data.ResourceTypes{}
			emptyValue, err := json.Marshal(emptyResourceTypes)
			require.NoError(t, err, "Failed to marshal empty resource types")

			deltaUpdate := &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: emptyValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to remove all resource types")

			// Verify all resource type derivations were removed
			for resourceType := range origDataObj.ResourceTypes {
				verifyResourceTypeDerivationsRemoved(t, originalGraph.schemaGraph, newGraph.schemaGraph, resourceType)
			}

			// Add all resource types back
			resourceTypesValue, err := json.Marshal(origDataObj.ResourceTypes)
			require.NoError(t, err, "Failed to marshal resource types")

			deltaUpdate = &input.DeltaUpdate{
				Path:  "/resource_types",
				Value: resourceTypesValue,
			}

			newGraph, err = newGraph.ApplyDeltaUpdate(deltaUpdate)
			require.NoError(t, err, "Failed to apply delta update to add resource types back")

			// Compare node counts should match the original
			assert.Equal(t, originalGraph.factsGraph.NodesCount(), newGraph.factsGraph.NodesCount(),
				"Facts graph node counts should match after re-adding resource types")
			assert.Equal(t, originalGraph.schemaGraph.NodesCount(), newGraph.schemaGraph.NodesCount(),
				"Schema graph node counts should match after re-adding resource types")

			compareFactsGraphNodes(t, originalGraph.factsGraph, newGraph.factsGraph)
			compareSchemaGraphNodes(t, originalGraph.schemaGraph, newGraph.schemaGraph)
		})
	}
}

// Helper functions for testing

// Compare a sample of nodes between two facts graphs
func compareFactsGraphNodes(t *testing.T, graph1, graph2 *GraphPointer[GraphNodeI]) {
	// Select a few nodes to compare
	nodeCount := 0
	for nodeStr, node1 := range graph1.nodes {
		node2, exists := graph2.nodes[nodeStr]
		require.True(t, exists, "Node %s should exist in both graphs", nodeStr)
		if exists {
			compareFactsNodeRelationships(t, node1, node2)
			nodeCount++
			if nodeCount >= 3 { // limit to 3 nodes for efficiency
				break
			}
		}
	}
}

// Compare a sample of nodes between two schema graphs
func compareSchemaGraphNodes(t *testing.T, graph1, graph2 *GraphPointer[GraphNodeI]) {
	// Select a few nodes to compare
	nodeCount := 0
	for nodeStr, node1 := range graph1.nodes {
		node2, exists := graph2.nodes[nodeStr]
		assert.True(t, exists, "Node %s should exist in both graphs", nodeStr)
		if exists {
			compareSchemaNodeRelationships(t, node1, node2)
			nodeCount++
			if nodeCount >= 3 { // limit to 3 nodes for efficiency
				break
			}
		}
	}
}

// Compare relationships between two facts nodes
func compareFactsNodeRelationships(t *testing.T, node1, node2 *Node[GraphNodeI]) {
	// Compare subject relationships
	for relation, subjects1 := range node1.subjectRelationships {
		subjects2 := node2.GetSubjectRelationships(relation)
		if !assert.Equalf(t, len(subjects1), len(subjects2),
			"Node %s should have same number of subject relationships for relation %s,",
			node1.String(), relation) {
			missingIn2, missingIn1 := lo.Difference(lo.Keys(subjects1), lo.Keys(subjects2))
			assert.Failf(
				t,
				"Mismatch in number of subject relationships",
				"Node %s should have same number of subject relationships for relation %s, missing in 2: %v, missing in 1: %v",
				node1.String(), relation, missingIn2, missingIn1,
			)
		}

		// Compare individual subjects
		for subjectStr := range subjects1 {
			_, exists := subjects2[subjectStr]
			if !assert.Truef(t, exists, "Subject %s should exist in both nodes for relation %s",
				subjectStr, relation) {
				missingIn2, missingIn1 := lo.Difference(lo.Keys(subjects1), lo.Keys(subjects2))
				assert.Failf(
					t,
					"Mismatch in number of subject relationships",
					"Subject %s should exist in both nodes for relation %s, missing in 2: %v, missing in 1: %v",
					subjectStr, relation, missingIn2, missingIn1,
				)
			}
		}
	}

	// Compare object relationships
	for relation := range node1.objectRelationships {
		objects1 := node1.GetObjectRelationships(relation)
		objects2 := node2.GetObjectRelationships(relation)
		if !assert.Equalf(t, len(objects1), len(objects2),
			"Node %s should have same number of object relationships for relation %s",
			node1.String(), relation) {
			missingIn2, missingIn1 := lo.Difference(lo.Keys(objects1), lo.Keys(objects2))
			assert.Failf(
				t,
				"Mismatch in number of object relationships",
				"Node %s should have same number of object relationships for relation %s, missing in 2: %v, missing in 1: %v",
				node1.String(), relation, missingIn2, missingIn1,
			)
		}
		// Compare individual objects
		for objectStr := range objects1 {
			_, exists := objects2[objectStr]
			if !assert.Truef(t, exists, "Object %s should exist in both nodes for relation %s",
				objectStr, relation) {
				missingIn2, missingIn1 := lo.Difference(lo.Keys(objects1), lo.Keys(objects2))
				assert.Failf(
					t,
					"Mismatch in number of object relationships",
					"Object %s should exist in both nodes for relation %s, missing in 2: %v, missing in 1: %v",
					objectStr, relation, missingIn2, missingIn1,
				)
			}
		}
	}
}

// Compare relationships between two schema nodes
func compareSchemaNodeRelationships(t *testing.T, node1, node2 *Node[GraphNodeI]) {
	// Compare subject relationships
	for relation := range node1.subjectRelationships {
		subjects1 := node1.GetSubjectRelationships(relation)
		subjects2 := node2.GetSubjectRelationships(relation)
		assert.Equal(t, len(subjects1), len(subjects2),
			"Node %s should have same number of subject relationships for relation %s",
			node1.String(), relation)

		// Compare individual subjects
		for subjectStr := range subjects1 {
			_, exists := subjects2[subjectStr]
			assert.True(t, exists, "Subject %s should exist in both nodes for relation %s",
				subjectStr, relation)
		}
	}

	// Compare object relationships
	for relation := range node1.objectRelationships {
		objects1 := node1.GetObjectRelationships(relation)
		objects2 := node2.GetObjectRelationships(relation)
		if !assert.Equalf(t, len(objects1), len(objects2),
			"Node %s should have same number of object relationships for relation %s",
			node1.String(), relation) {
			missingIn2, missingIn1 := lo.Difference(lo.Keys(objects1), lo.Keys(objects2))
			assert.Failf(
				t,
				"Mismatch in number of object relationships",
				"Node %s should have same number of object relationships for relation %s, missing in 2: %v, missing in 1: %v",
				node1.String(), relation, missingIn2, missingIn1,
			)
		}
		// Compare individual objects
		for objectStr := range objects1 {
			_, exists := objects2[objectStr]
			if !assert.Truef(t, exists, "Object %s should exist in both nodes for relation %s",
				objectStr, relation) {
				missingIn2, missingIn1 := lo.Difference(lo.Keys(objects1), lo.Keys(objects2))
				assert.Failf(
					t,
					"Mismatch in number of object relationships",
					"Object %s should exist in both nodes for relation %s, missing in 2: %v, missing in 1: %v",
					objectStr, relation, missingIn2, missingIn1,
				)
			}
		}
	}
}

// Verify a relationship was removed from the graph
func verifyRelationshipRemoved(t *testing.T, original, afterRemoval *GraphPointer[GraphNodeI], objectKey string, relations data.Relations) {
	// The object might still be in the graph, but relationships involving it should be removed
	objectNode := original.GetNodeByString(objectKey)
	if objectNode == nil {
		assert.Nilf(t, afterRemoval.GetNodeByString(objectKey), "Object %s should not exist in the afterRemoval graph", objectKey)
		return
	}

	// Check if relationships were removed
	for relation := range relations {
		subjects := objectNode.GetObjectRelationships(relation)
		for subjectStr := range subjects {
			// Find this subject in the afterRemoval graph
			removedSubjectNode := afterRemoval.GetNodeByString(subjectStr)
			if removedSubjectNode != nil {
				// This relationship should be gone
				removedObjects := removedSubjectNode.GetSubjectRelationships(relation)
				if removedObjects != nil {
					_, exists := removedObjects[objectKey]
					assert.False(t, exists, "Relationship from %s to %s via %s should be removed",
						subjectStr, objectKey, relation)
				}
			}
		}
	}
}

// Verify resource type derivations were removed
func verifyResourceTypeDerivationsRemoved(t *testing.T, original, afterRemoval *GraphPointer[GraphNodeI], resourceType string) {
	// Check if the resource type node exists in both graphs
	resourceTypeNode := original.GetNodeByString(resourceType)
	if resourceTypeNode == nil {
		return
	}

	// If the resource type had derivations, they should be gone now
	for _, relation := range []string{RoleToResourceRelation} {
		// Check role to resource type relationships
		roles := resourceTypeNode.GetObjectRelationships(relation)
		for roleStr := range roles {
			// This role should not have derivations in the modified graph
			removedResourceTypeNode := afterRemoval.GetNodeByString(resourceType)
			if removedResourceTypeNode != nil {
				removedDerivationRoles := removedResourceTypeNode.GetObjectRelationships(relation)
				roleNode, exists := removedDerivationRoles[roleStr]
				if !exists {
					continue
				}
				assert.Truef(
					t,
					roleNode.GetObjectRelationshipsByFilter(RoleToResourceRelation, ExactMatchFilter).IsEmpty(),
					"Role %s on resource type %s should not have derivations after removal",
					roleStr, resourceType,
				)
			}
		}
	}
}
