package graphy

import (
	lru "github.com/hashicorp/golang-lru/v2"
	"github.com/permitio/permit-opa/types"
	"github.com/permitio/permit-opa/types/data"
)

// GraphBuilder is a builder for the Graph struct
type GraphBuilder struct {
	graph *Graph
}

// NewGraphBuilder creates a new GraphBuilder
func NewGraphBuilder() *GraphBuilder {
	return &GraphBuilder{
		graph: NewGraph(0),
	}
}

func (g *GraphBuilder) WithCache(cache *lru.Cache[string, map[string]types.LinkedUsersResultTuple]) *GraphBuilder {
	if cache == nil {
		g.graph.cache = nil
		return g
	}
	cache.Purge()
	g.graph.cache = cache
	return g
}

// WithCacheSize sets the cache size for the Graph
func (g *GraphBuilder) WithCacheSize(cacheSize int) *GraphBuilder {
	if cacheSize == 0 {
		g.graph.cache = nil
		return g
	}
	cache, err := lru.New[string, map[string]types.LinkedUsersResultTuple](cacheSize)
	if err != nil {
		g.graph.cache = nil
		return g
	}
	g.graph.cache = cache
	return g
}

// FromDataObj builds the Graph from a data.DataObj
func (g *GraphBuilder) FromDataObj(dataObj *data.DataObj) *GraphBuilder {
	dataObj.RLock()
	defer dataObj.RUnlock()
	factsGraph := newFactsGraph(dataObj)
	schemaGraph := newSchemaGraph(dataObj.ResourceTypes, g.graph.schemaGraph)
	g.graph.factsGraph = factsGraph
	g.graph.schemaGraph = schemaGraph
	return g
}

// WithFactsGraph sets the factsGraph for the Graph
func (g *GraphBuilder) WithFactsGraph(factsGraph *GraphPointer[GraphNodeI]) *GraphBuilder {
	g.graph.factsGraph = factsGraph
	return g
}

// WithSchemaGraph sets the schemaGraph for the Graph
func (g *GraphBuilder) WithSchemaGraph(schemaGraph *GraphPointer[GraphNodeI]) *GraphBuilder {
	g.graph.schemaGraph = schemaGraph
	return g
}

// Build builds the Graph
func (g *GraphBuilder) Build() *Graph {
	return g.graph
}
