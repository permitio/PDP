package graphy

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

type Person struct {
	Name string
}

func (p Person) String() string {
	return p.Name
}

func (p Person) NodeType() GraphNodeType {
	return NodeTypeUser
}

func TestNewNode(t *testing.T) {
	x := Person{
		Name: "John",
	}
	// Create a map to store the tree references
	graphPointer := NewGraphPointer[GraphNodeI]()
	// Create a new node
	node := graphPointer.NewNodeInGraph(x)
	// Check that the node was created
	assert.NotNil(t, node, "Node was not created")
	// Check that the node was added to the tree references
	assert.True(t, graphPointer.IsNodeInGraph(node), "Node was not added to the tree references")
	assert.Same(t, node, graphPointer.GetNodeByString(node.String()), "Node was not added to the tree references")
}

func TestNode_AddObjectRelationship(t *testing.T) {
	x := Person{
		Name: "John",
	}
	// Create a map to store the tree references
	graphPointer := NewGraphPointer[GraphNodeI]()
	// Create a new node
	node := graphPointer.NewNodeInGraph(x)
	// Create a second node
	y := Person{
		Name: "Jane",
	}
	// Create a new node
	node2 := graphPointer.NewNodeInGraph(y)
	// Add a relationship
	node.AddObjectRelationship("friend", node2)
	// Check that the relationship was added
	assert.NotNil(t, node.objectRelationships["friend"], "Relationship was not added, map is nil")
	assert.NotNil(t, node.objectRelationships["friend"][node2.String()], "Relationship was not added, node not found")
	// Check that the relationship was added to the other node
	assert.NotNil(t, node2.subjectRelationships["friend"], "Relationship was not added to the other node, map is nil")
	assert.NotNil(t, node2.subjectRelationships["friend"][node.String()], "Relationship was not added to the other node, node not found")
}

func TestNode_AddSubjectRelationship(t *testing.T) {
	x := Person{
		Name: "John",
	}
	// Create a map to store the tree references
	graphPointer := NewGraphPointer[GraphNodeI]()
	// Create a new node
	node := graphPointer.NewNodeInGraph(x)
	// Create a second node
	y := Person{
		Name: "Jane",
	}
	// Create a new node
	node2 := graphPointer.NewNodeInGraph(y)
	// Add a relationship
	node.AddSubjectRelationship("friend", node2)
	// Check that the relationship was added
	assert.NotNil(t, node.GetSubjectRelationships("friend"), "Relationship was not added, map is nil")
	assert.NotNil(t, node.GetSubjectRelationships("friend")[node2.String()], "Relationship was not added, node not found")
	// Check that the relationship was added to the other node
	assert.NotNil(t, node2.GetObjectRelationships("friend"), "Relationship was not added to the other node, map is nil")
	assert.NotNil(t, node2.GetObjectRelationships("friend")[node.String()], "Relationship was not added to the other node, node not found")
}
