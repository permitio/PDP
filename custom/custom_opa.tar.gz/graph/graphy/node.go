package graphy

import (
	"strings"
)

type FilterType int

const (
	PrefixFilter FilterType = iota
	SuffixFilter
	ContainsFilter
	NotContains
	NoPrefixFilter
	NoFilter
	ExactMatchFilter
)

// Node is a node in a graph
type Node[T GraphNodeI] struct {
	// data is the actual data that this node represents
	data T
	// subjectRelationships are the relationships this node is related to as the subject
	// the key in the map is the relation key that the node is related by
	// and the value is the actual node
	subjectRelationships Relationships[T]
	// objectRelationships are the relationships this node is related to as the object
	// the key in the map is the relation key that the node is related by
	// and the value is the actual node
	objectRelationships Relationships[T]
}

func (n *Node[T]) RelationshipsCount() int {
	return n.subjectRelationships.Count() + n.objectRelationships.Count()
}

func (n *Node[T]) String() string {
	return n.data.String()
}

func (n *Node[T]) NodeType() GraphNodeType {
	return n.data.NodeType()
}

func NewNode[T GraphNodeI](data T) *Node[T] {
	node := &Node[T]{
		data:                 data,
		subjectRelationships: NewRelationships[T](),
		objectRelationships:  NewRelationships[T](),
	}

	return node
}

func (n *Node[T]) AddSubjectRelationship(relation string, node *Node[T]) {
	n.subjectRelationships.AddRelationship(relation, node)
	// We also need to add the relationship to the other node as an object relationship
	// so that we can traverse the graph in both directions
	node.objectRelationships.AddRelationship(relation, n)
}

func (n *Node[T]) AddObjectRelationship(relation string, node *Node[T]) {
	n.objectRelationships.AddRelationship(relation, node)
	// We also need to add the relationship to the other node as an object relationship
	// so that we can traverse the graph in both directions
	node.subjectRelationships.AddRelationship(relation, n)
}

// GetSubjectRelationships returns the relationships that this node is the subject of
func (n *Node[T]) GetSubjectRelationships(relation string) RelationshipsObjects[T] {
	return n.subjectRelationships[relation]
}

// GetObjectRelationships returns the relationships that this node is the object of
func (n *Node[T]) GetObjectRelationships(relation string) RelationshipsObjects[T] {
	return n.objectRelationships[relation]
}

func (n *Node[T]) GetObjectRelationshipsByFilter(relationFilter string, filterType FilterType) Relationships[T] {
	filteredObjectRelationships := make(Relationships[T])
	for relation, objectRelation := range n.objectRelationships {
		switch filterType {
		case PrefixFilter:
			if strings.HasPrefix(relation, relationFilter) {
				filteredObjectRelationships[relation] = objectRelation
			}
		case SuffixFilter:
			if strings.HasSuffix(relation, relationFilter) {
				filteredObjectRelationships[relation] = objectRelation
			}
		case ContainsFilter:
			if strings.Contains(relation, relationFilter) {
				filteredObjectRelationships[relation] = objectRelation
			}
		case NotContains:
			if !strings.Contains(relation, relationFilter) {
				filteredObjectRelationships[relation] = objectRelation
			}
		case ExactMatchFilter:
			if relation == relationFilter {
				filteredObjectRelationships[relation] = objectRelation
			}
		case NoFilter:
			filteredObjectRelationships[relation] = objectRelation
		}
	}
	return filteredObjectRelationships
}

func (n *Node[T]) GetObjectRelationshipsAnyOf(relationFilters []string) Relationships[T] {
	filteredObjectRelationships := make(Relationships[T])
	for _, relation := range relationFilters {
		if relationships, exists := n.objectRelationships[relation]; exists {
			filteredObjectRelationships[relation] = relationships
		}
	}
	return filteredObjectRelationships
}
func (n *Node[T]) Merge(node *Node[T]) {
	for relation, nodes := range node.subjectRelationships {
		for _, subjectNode := range nodes {
			n.AddSubjectRelationship(relation, subjectNode)
		}
	}
	for relation, nodes := range node.objectRelationships {
		for _, objectNode := range nodes {
			n.AddObjectRelationship(relation, objectNode)
		}
	}
	// change the node reference to the one it was merged into
	*node = *n
}

func (n *Node[T]) Clone() *Node[T] {
	clonedNode := NewNode(n.data)
	return clonedNode
}

func (n *Node[T]) removeSubjectRelationship(relation string, node *Node[T], visitedNodes map[string]struct{}) int {
	// remove the node from the subject relationships reference and cascade
	// to remove the same relationship from the other node ( other side )
	n.subjectRelationships.removeRelationship(relation, node, cascadeBackrefTypeObject, n, visitedNodes)
	return n.RelationshipsCount()
}

func (n *Node[T]) removeObjectRelationship(relation string, node *Node[T], visitedNodes map[string]struct{}) int {
	// remove the node from the object relationships reference and cascade
	// to remove the same relationship from the other node ( other side )
	n.objectRelationships.removeRelationship(relation, node, cascadeBackrefTypeSubject, n, visitedNodes)
	return n.RelationshipsCount()
}

func (n *Node[T]) RemoveSubjectRelationship(relation string, node *Node[T]) int {
	return n.removeSubjectRelationship(relation, node, make(map[string]struct{}))
}

func (n *Node[T]) RemoveObjectRelationship(relation string, node *Node[T]) int {
	return n.removeObjectRelationship(relation, node, make(map[string]struct{}))
}

func (n *Node[T]) RemoveAllSubjectRelationships() int {
	for relation, nodes := range n.subjectRelationships {
		for _, node := range nodes {
			n.RemoveSubjectRelationship(relation, node)
		}
	}
	return n.RelationshipsCount()
}

// RemoveAllObjectRelationshipsByFilter removes all relationships that match the filter
// // it returns the number of relationships that are still left on the node
// func (n *Node[T]) RemoveAllObjectRelationshipsByFilter(relationFilter string, filterType FilterType) int {
// 	for relation, nodes := range n.objectRelationships {
// 		for _, node := range nodes {
// 			n.RemoveObjectRelationship(relation, node)
// 		}
// 	}
// 	return n.RelationshipsCount()
// }

// RemoveAllSubjectRelationshipsByFilter removes all relationships that match the filter
// it returns the number of relationships that are still left on the node
func (n *Node[T]) RemoveAllSubjectRelationshipsByFilter(relationFilter string, filterType FilterType) int {
	for relation, nodes := range n.subjectRelationships {
		for _, node := range nodes {
			n.RemoveSubjectRelationship(relation, node)
		}
	}
	return n.RelationshipsCount()
}

// RemoveAllObjectRelationshipsByFilter removes all relationships that match the filter
// it returns the number of relationships that are still left on the node
func (n *Node[T]) RemoveAllObjectRelationshipsByFilter(relationFilter string, filterType FilterType) int {
	for relation, nodes := range n.objectRelationships {
		for _, node := range nodes {
			n.RemoveObjectRelationship(relation, node)
		}
	}
	return n.RelationshipsCount()
}

// RemoveRelationshipsByFilter removes all relationships that match the filter
// it returns the number of relationships that are still left on the node
func (n *Node[T]) RemoveRelationshipsByFilter(relationFilter string, filterType FilterType) int {
	n.RemoveSubjectRelationshipsByFilter(relationFilter, filterType)
	n.RemoveObjectRelationshipsByFilter(relationFilter, filterType)
	return n.RelationshipsCount()
}

// RemoveSubjectRelationshipsByFilter removes all relationships that match the filter
// it returns the number of relationships that are still left on the node
func (n *Node[T]) RemoveSubjectRelationshipsByFilter(relationFilter string, filterType FilterType) int {
	n.subjectRelationships.RemoveRelationshipsByFilter(relationFilter, filterType, cascadeBackrefTypeObject, n)
	return n.RelationshipsCount()
}

// RemoveObjectRelationshipsByFilter removes all relationships that match the filter
// it returns the number of relationships that are still left on the node
func (n *Node[T]) RemoveObjectRelationshipsByFilter(relationFilter string, filterType FilterType) int {
	n.objectRelationships.RemoveRelationshipsByFilter(relationFilter, filterType, cascadeBackrefTypeSubject, n)
	return n.RelationshipsCount()
}
