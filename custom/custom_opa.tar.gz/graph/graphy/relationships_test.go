package graphy

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

func TestNewRelationshipsObjects(t *testing.T) {
	relationshipsObjects := NewRelationshipsObjects[GraphNodeI]()
	assert.NotNil(t, relationshipsObjects, "Relationships objects was not created")
}

func TestRelationships_AddRelationship_Overwrite(t *testing.T) {
	// initialize a Relationships and GraphPointer
	relationships := NewRelationships[GraphNodeI]()
	graphPointer := NewGraphPointer[GraphNodeI]()
	// create a new Node in the graph with repr of `John`
	node := graphPointer.NewNodeInGraph(Person{Name: "John"})
	relationships.AddRelationship("string", node)
	assert.NotNil(t, relationships["string"], "Relationship was not added, no relationships of the relation")
	addedRelationship := relationships["string"][node.String()]
	assert.NotNil(t, addedRelationship, "Relationship was not added")
	relationships.AddRelationship("string", node)
	sameAddedRelationship := relationships["string"][node.String()]
	assert.NotNil(t, sameAddedRelationship, "Relationship was not added")
	assert.Same(t, addedRelationship, sameAddedRelationship, "Relationship was not overwritten")
	// create a new Node in the graph with repr of `John2` - it must be different because otherwise
	// the GraphPointer will be resilient to overrides and return the same Node
	node2 := graphPointer.NewNodeInGraph(Person{Name: "John2"})
	relationships.AddRelationship("string", node2)
	overwrittenRelationship := relationships["string"][node2.String()]
	assert.NotNil(t, overwrittenRelationship, "Relationship was not added")
	assert.NotSame(t, addedRelationship, overwrittenRelationship, "Relationship was not overwritten")
}
