package graphy

import (
	"encoding/json"
	"github.com/permitio/permit-opa/types/data"
	"github.com/stretchr/testify/assert"
	"testing"
)

const (
	ExampleData = `{
  "condition_set_rules": {},
  "condition_sets": {
    "resourceset__5f_5fautogen_5forganization": {
      "key": "__autogen_organization",
      "type": "resourceset"
    },
    "resourceset__5f_5fautogen_5frepo": {
      "key": "__autogen_repo",
      "type": "resourceset"
    }
  },
  "mapping_rules": {
    "all": []
  },
  "relationships": {
    "repo:permit-backend": {
      "relation:parent": {
        "organization": [
          "permitio"
        ]
      }
    }
  },
  "resource_instances": {
    "organization:permitio": {
      "attributes": {}
    },
    "repo:permit-backend": {
      "attributes": {}
    }
  },
  "resource_types": {
    "__tenant": {
      "actions": [],
      "derived_roles": {}
    },
    "__user": {
      "actions": [],
      "derived_roles": {}
    },
    "organization": {
      "actions": [
        "create",
        "read",
        "update",
        "delete"
      ],
      "derived_roles": {}
    },
    "repo": {
      "actions": [
        "create",
        "read",
        "update",
        "delete"
      ],
      "derived_roles": {
        "maintainer": {
          "rules": [
            {
              "related_resource": "organization",
              "related_role": "admin",
              "relation": "parent",
              "settings": {
                "superseded_by_direct_role": false
              }
            }
          ],
          "settings": {
            "superseded_by_direct_role": false
          }
        }
      }
    }
  },
  "role_assignments": {
    "user:omer@permit.io": {
      "organization:permitio": [
        "admin"
      ]
    }
  },
  "role_permissions": {
    "organization": {
      "admin": {
        "grants": {
          "organization": [
            "create",
            "delete"
          ]
        }
      }
    },
    "repo": {
      "maintainer": {
        "grants": {
          "repo": [
            "delete",
            "create",
            "update",
            "read"
          ]
        }
      }
    }
  },
  "roles": {
    "admin": {},
    "maintainer": {}
  },
  "tenants": {
    "default": {
      "attributes": {}
    }
  },
  "users": {
    "omer@permit.io": {
      "attributes": {
        "key": "omer@permit.io"
      },
      "roleAssignments": {}
    }
  }
}`
)

func LoadData(t *testing.T) *data.DataObj {
	var d data.DataObj
	assert.NoError(t, json.Unmarshal([]byte(ExampleData), &d))
	return &d
}

func validateFactsGraph(t *testing.T, factsGraph *GraphPointer[GraphNodeI]) {
	// we have 3 nodes: 2 resources and 1 user
	assert.Equal(t, 3, factsGraph.NodesCount())

	// we have 2 edges: 1 from user to organization and 1 from organization to repo
	userNode := factsGraph.GetNodeByString("user:omer@permit.io")
	organizationNode := factsGraph.GetNodeByString("organization:permitio")
	repoNode := factsGraph.GetNodeByString("repo:permit-backend")
	adminAssignments := userNode.GetSubjectRelationships("organization#admin")
	assert.Len(t, adminAssignments, 1)

	organizationObjects := organizationNode.GetSubjectRelationships("relation:parent")
	assert.Len(t, organizationObjects, 1)
	assert.Same(t, repoNode, organizationObjects[repoNode.String()])
	organizationSubjects := organizationNode.GetObjectRelationships("relation:parent")
	assert.Len(t, organizationSubjects, 0)

	repoSubjects := repoNode.GetObjectRelationships("relation:parent")
	assert.Len(t, repoSubjects, 1)
	assert.Same(t, organizationNode, repoSubjects[organizationNode.String()])
	repoObjects := repoNode.GetSubjectRelationships("relation:parent")
	assert.Len(t, repoObjects, 0)
}

func validateSchemaGraph(t *testing.T, schemaGraph *GraphPointer[GraphNodeI]) {
	// we have 4 nodes: 2 resources and 2 builtin resources ( __user & __tenant )
	assert.Equal(t, 6, schemaGraph.NodesCount())

	// we have 1 edge: 1 from organization#admin -> relation:parent -> repo#maintainer
	organizationAdminNode := schemaGraph.GetNodeByString("organization#admin")
	repoMaintainerNode := schemaGraph.GetNodeByString("repo#maintainer")
	organizationAdminObjects := organizationAdminNode.GetSubjectRelationships("relation:parent")
	assert.Len(t, organizationAdminObjects, 1)
	organizationAdminSubjects := organizationAdminNode.GetObjectRelationships("relation:parent")
	assert.Len(t, organizationAdminSubjects, 0)
	assert.Same(t, repoMaintainerNode, organizationAdminObjects[repoMaintainerNode.String()])

	repoMaintainerSubjects := repoMaintainerNode.GetObjectRelationships("relation:parent")
	assert.Len(t, repoMaintainerSubjects, 1)
	assert.Same(t, organizationAdminNode, repoMaintainerSubjects[organizationAdminNode.String()])
	repoMaintainerObjects := repoMaintainerNode.GetSubjectRelationships("relation:parent")
	assert.Len(t, repoMaintainerObjects, 0)
}

func TestNewGraphFromDataObj(t *testing.T) {
	dataObj := LoadData(t)
	graphObj := NewGraphBuilder().
		FromDataObj(dataObj).
		Build()
	factsGraph := graphObj.GetFactsGraph()
	schemaGraph := graphObj.GetSchemaGraph()
	validateFactsGraph(t, factsGraph)
	validateSchemaGraph(t, schemaGraph)
}
