package graphy

import (
	"strings"

	"github.com/samber/lo"
)

type cascadeBackrefType int

const (
	cascadeBackrefTypeSubject cascadeBackrefType = iota
	cascadeBackrefTypeObject
	cascadeBackrefTypeDone
)

// Relationships is a map of relation keys to a map of node "string representation" to the actual node reference
type Relationships[T GraphNodeI] map[string]RelationshipsObjects[T]

// NewRelationships creates a new relationships map
func NewRelationships[T GraphNodeI]() Relationships[T] {
	return make(map[string]RelationshipsObjects[T])
}

func (r Relationships[T]) IsEmpty() bool {
	return len(r) == 0
}

func (r Relationships[T]) Count() int {
	return len(r)
}

// AddRelationship adds a relationship to the relationships map
func (r Relationships[T]) AddRelationship(relation string, node *Node[T]) {
	relationRelationships, isFound := r[relation]
	if !isFound {
		relationRelationships = NewRelationshipsObjects[T](node)
	} else {
		relationRelationships.AddNode(node)
	}
	r[relation] = relationRelationships
}

func (r Relationships[T]) RemoveRelationshipsByFilter(
	relationFilter string,
	filterType FilterType,
	cascadeBackref cascadeBackrefType,
	backrefNode *Node[T],
) {
	for relation, nodes := range r {
		switch filterType {
		case ExactMatchFilter:
			if relation == relationFilter {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		case NoFilter:
			for _, node := range nodes {
				r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
			}
		case PrefixFilter:
			if strings.HasPrefix(relation, relationFilter) {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		case NoPrefixFilter:
			if !strings.HasPrefix(relation, relationFilter) {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		case SuffixFilter:
			if strings.HasSuffix(relation, relationFilter) {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		case ContainsFilter:
			if strings.Contains(relation, relationFilter) {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		case NotContains:
			if !strings.Contains(relation, relationFilter) {
				for _, node := range nodes {
					r.RemoveRelationship(relation, node, cascadeBackref, backrefNode)
				}
			}
		}
	}
}

// removeRelationship removes a relationship from the relationships map
func (r Relationships[T]) removeRelationship(
	relation string,
	node *Node[T],
	cascadeBackref cascadeBackrefType,
	backrefNode *Node[T],
	visitedNodes map[string]struct{},
) {
	// this request originator is the backrefNode
	visitedNodes[backrefNode.String()] = struct{}{}
	relatedNodes, isFound := r[relation]
	if !isFound {
		return
	}
	relatedNodes.RemoveNode(node)
	if len(relatedNodes) == 0 {
		delete(r, relation)
	}
	if _, exists := visitedNodes[node.String()]; exists {
		visitedNodes[node.String()] = struct{}{}
		return
	}

	switch cascadeBackref {
	case cascadeBackrefTypeSubject:
		node.removeSubjectRelationship(relation, backrefNode, visitedNodes)
	case cascadeBackrefTypeObject:
		node.removeObjectRelationship(relation, backrefNode, visitedNodes)
	}

}

// RemoveRelationship removes a relationship from the relationships map
func (r Relationships[T]) RemoveRelationship(
	relation string,
	node *Node[T],
	cascadeBackref cascadeBackrefType,
	backrefNode *Node[T],
) {
	r.removeRelationship(relation, node, cascadeBackref, backrefNode, make(map[string]struct{}))
}

// RelationshipsObjects is a map of node "string representation" to the actual node reference
type RelationshipsObjects[T GraphNodeI] map[string]*Node[T]

// NewRelationshipsObjects creates a new relationships objects map
func NewRelationshipsObjects[T GraphNodeI](values ...*Node[T]) map[string]*Node[T] {
	if len(values) > 0 {
		return lo.KeyBy(values, func(node *Node[T]) string {
			return node.String()
		})
	}
	return make(map[string]*Node[T])
}

func (r RelationshipsObjects[T]) AddNode(node *Node[T]) {
	r[node.String()] = node
}

func (r RelationshipsObjects[T]) RemoveNode(node *Node[T]) {
	delete(r, node.String())
}
