package graphy

import "github.com/samber/lo"

type GraphPointer[T GraphNodeI] struct {
	nodes          map[string]*Node[T]
	usersIndex     map[string]*Node[T]
	resourcesIndex map[string]*Node[T]
	schemasIndex   map[string]*Node[T]
}

// NewGraphPointer creates a new graph pointer
func NewGraphPointer[T GraphNodeI]() *GraphPointer[T] {
	return &GraphPointer[T]{
		nodes:          make(map[string]*Node[T]),
		usersIndex:     make(map[string]*Node[T]),
		resourcesIndex: make(map[string]*Node[T]),
		schemasIndex:   make(map[string]*Node[T]),
	}
}

func (g *GraphPointer[T]) Purge() {
	g.nodes = make(map[string]*Node[T])
	g.usersIndex = make(map[string]*Node[T])
	g.resourcesIndex = make(map[string]*Node[T])
	g.schemasIndex = make(map[string]*Node[T])
}

func (g *GraphPointer[T]) unindexNode(node *Node[T]) {
	switch node.NodeType() {
	case NodeTypeUser:
		delete(g.usersIndex, node.String())
	case NodeTypeResource:
		delete(g.resourcesIndex, node.String())
	case NodeTypeSchema:
		delete(g.schemasIndex, node.String())
	}
}

func (g *GraphPointer[T]) indexNode(node *Node[T]) {
	switch node.NodeType() {
	case NodeTypeUser:
		g.usersIndex[node.String()] = node
	case NodeTypeResource:
		g.resourcesIndex[node.String()] = node
	case NodeTypeSchema:
		g.schemasIndex[node.String()] = node
	}
}

// AddNode adds a node to the graph pointer
func (g *GraphPointer[T]) AddNode(node *Node[T]) {
	existingNode, exists := g.nodes[node.String()]
	if exists && existingNode.NodeType() == node.NodeType() {
		// Merge the relationships
		existingNode.Merge(node)
	} else if exists {
		// If the node exists but the node type is different, we need to create a new node
		// and add the relationships to the new node
		g.unindexNode(existingNode)
		g.indexNode(node)
	} else {
		g.nodes[node.String()] = node
		g.indexNode(node)
	}
}

func (g *GraphPointer[T]) RemoveNode(node *Node[T]) {
	// remove all the relationships that related to this node
	// by using the relation prefix
	for relation, nodes := range node.objectRelationships {
		for _, targetNode := range nodes {
			node.RemoveSubjectRelationship(relation, targetNode)
		}
	}
	for relation, nodes := range node.subjectRelationships {
		for _, sourceNode := range nodes {
			node.RemoveObjectRelationship(relation, sourceNode)
		}
	}
	g.unindexNode(node)
	delete(g.nodes, node.String())
}

func (g *GraphPointer[T]) IsNodeInGraph(node *Node[T]) bool {
	_, exists := g.nodes[node.String()]
	return exists
}

func (g *GraphPointer[T]) GetNodeByString(nodeString string) *Node[T] {
	return g.nodes[nodeString]
}

func (g *GraphPointer[T]) NewNodeInGraph(data T) *Node[T] {
	if node := g.GetNodeByString(data.String()); node != nil {
		return node
	}
	node := NewNode(data)
	g.AddNode(node)
	return node
}

func (g *GraphPointer[T]) NodesCount() int {
	return len(g.nodes)
}

func (g *GraphPointer[T]) Clone() *GraphPointer[T] {
	clonedGraph := &GraphPointer[T]{
		nodes:          make(map[string]*Node[T], len(g.nodes)),
		usersIndex:     make(map[string]*Node[T], len(g.usersIndex)),
		resourcesIndex: make(map[string]*Node[T], len(g.resourcesIndex)),
		schemasIndex:   make(map[string]*Node[T], len(g.schemasIndex)),
	}
	for _, node := range g.nodes {
		clonedNode := node.Clone()
		clonedGraph.AddNode(clonedNode)
		for relation, subjectNodes := range node.subjectRelationships {
			for _, subjectNode := range subjectNodes {
				clonedSubjectNode := subjectNode.Clone()
				clonedGraph.AddNode(clonedSubjectNode)
				clonedNode.AddSubjectRelationship(relation, clonedSubjectNode)
			}
		}
		for relation, objectNodes := range node.objectRelationships {
			for _, objectNode := range objectNodes {
				clonedObjectNode := objectNode.Clone()
				clonedGraph.AddNode(clonedObjectNode)
				clonedNode.AddObjectRelationship(relation, clonedObjectNode)
			}
		}
	}
	return clonedGraph
}

func (g *GraphPointer[T]) CleanRelationships() {
	for _, node := range g.resourcesIndex {
		if node == nil {
			continue
		}
		if remainingRelationships := node.RemoveRelationshipsByFilter("relation:", PrefixFilter); remainingRelationships == 0 {
			g.RemoveNode(node)
		}
	}
}

func (g *GraphPointer[T]) CleanAssignments() {
	usersToRemove := lo.Keys(g.usersIndex)
	for _, userString := range usersToRemove {
		node := g.usersIndex[userString]
		if node == nil {
			continue
		}
		remainingRelationships := node.RemoveRelationshipsByFilter("relation:", NoPrefixFilter)
		if remainingRelationships == 0 {
			g.RemoveNode(node)
		}
	}
}
