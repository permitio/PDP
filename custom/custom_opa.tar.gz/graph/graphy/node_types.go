package graphy

import (
	"fmt"
	"strings"
)

const roleDelimiter = "#"

const (
	NodeTypeUser GraphNodeType = iota
	NodeTypeResource
	NodeTypeSchema
)

type GraphNodeType int

type GraphNodeI interface {
	fmt.Stringer
	NodeType() GraphNodeType
}

type UserOrResource interface {
}

type SchemaNode string

func NewSchemaNodeFromString(schemaNode string) GraphNodeI {
	return SchemaNode(schemaNode)
}

func (r SchemaNode) String() string {
	return string(r)
}

func (r SchemaNode) NodeType() GraphNodeType {
	return NodeTypeSchema
}

type Resource struct {
	Key  string `json:"key"`
	Type string `json:"type"`
}

func NewResource(resourceType, resourceKey string) Resource {
	return Resource{Key: resourceKey, Type: resourceType}
}

func NewResourceFromString(resource string) Resource {
	parts := strings.SplitN(resource, ":", 2)
	var resourceType, resourceKey string
	if len(parts) == 1 {
		resourceType = "__tenant"
		resourceKey = parts[0]
	} else {
		resourceType = parts[0]
		resourceKey = parts[1]
	}
	return Resource{
		Type: resourceType,
		Key:  resourceKey,
	}
}

func (r Resource) String() string {
	return fmt.Sprintf("%s:%s", r.Type, r.Key)
}

func (r Resource) NodeType() GraphNodeType {
	return NodeTypeResource
}

type User string

func NewUserFromString(user string) User {
	return User(user)
}

func (u User) String() string {
	return string(u)
}

func (u User) NodeType() GraphNodeType {
	return NodeTypeUser
}

type Role struct {
	Resource string
	Role     string
}

func NewRole(resource, role string) Role {
	return Role{
		Resource: resource,
		Role:     role,
	}
}

func (r Role) String() string {
	return fmt.Sprintf("%s%s%s", r.Resource, roleDelimiter, r.Role)
}

func (r Role) NodeType() GraphNodeType {
	return NodeTypeSchema
}
